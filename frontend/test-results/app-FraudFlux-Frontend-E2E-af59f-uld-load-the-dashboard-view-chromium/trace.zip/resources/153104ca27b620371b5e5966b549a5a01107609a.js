import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import Dashboard from "/src/Dashboard.jsx";
import Login from "/src/Login.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import LandingPage from "/src/LandingPage.jsx";
import Register from "/src/Register.jsx";
import MerchantSettings from "/src/MerchantSettings.jsx";
import CheckoutSimulator from "/src/CheckoutSimulator.jsx";
import Pricing from "/src/Pricing.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
export default function App() {
	_s();
	const { user, logout, loading } = useAuth();
	const [authView, setAuthView] = useState("landing");
	const [activeTab, setActiveTab] = useState("dashboard");
	const [transactions, setTransactions] = useState([]);
	// Operations Desk Search, Filter & Inspection Modal State
	const [searchTerm, setSearchTerm] = useState("");
	const [filterDecision, setFilterDecision] = useState("ALL");
	const [selectedTxModal, setSelectedTxModal] = useState(null);
	// Fetch the live database data
	useEffect(() => {
		if (!user) return;
		const fetchTransactions = async () => {
			try {
				const response = await fetch("http://localhost:8000/api/v1/transactions");
				const data = await response.json();
				if (Array.isArray(data)) setTransactions(data);
			} catch (error) {
				console.error("Error fetching live transactions:", error);
			}
		};
		fetchTransactions();
	}, [user]);
	// Filter transactions based on search term & decision selection
	const filteredTransactions = transactions.filter((tx) => {
		const matchesSearch = (tx.transaction_id?.toString().toLowerCase() || "").includes(searchTerm.toLowerCase()) || (tx.customer_email?.toLowerCase() || "").includes(searchTerm.toLowerCase());
		const matchesDecision = filterDecision === "ALL" || tx.decision && tx.decision.toUpperCase() === filterDecision.toUpperCase();
		return matchesSearch && matchesDecision;
	});
	// 1. Show Loading State while Supabase checks session
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "h-screen flex items-center justify-center bg-gray-50 text-[#21005D]",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-lg font-semibold animate-pulse",
				children: "Loading FraudFlux Session..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this);
	}
	// 2. Show Public Pages (Landing, Login, Register, or Pricing) if User is NOT Authenticated
	if (!user) {
		if (authView === "login") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAuthView("landing"),
					className: "absolute top-6 left-6 text-white text-sm hover:underline z-10 bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-md",
					children: "← Back to Home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this);
		}
		if (authView === "register") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAuthView("landing"),
					className: "absolute top-6 left-6 text-white text-sm hover:underline z-10 bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-md",
					children: "← Back to Home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Register, { onSwitchToLogin: () => setAuthView("login") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this);
		}
		// Public Pricing view for non-authenticated visitors
		if (authView === "pricing") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAuthView("landing"),
					className: "absolute top-6 left-6 text-gray-700 hover:text-black font-medium text-sm z-10 bg-white px-3.5 py-1.5 rounded-lg shadow-sm border border-gray-200",
					children: "← Back to Home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Pricing, {
					onNavigate: (view) => setAuthView(view),
					isAuthenticated: false
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 9
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV(LandingPage, { onNavigate: (view) => setAuthView(view) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 106,
			columnNumber: 12
		}, this);
	}
	// 3. Render Main Application if Authenticated
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen flex flex-col bg-gray-50 font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-[#21005D] text-white h-14 flex items-center justify-between px-6 shrink-0 shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => setActiveTab("dashboard"),
					className: "flex items-center space-x-3 cursor-pointer hover:opacity-80 transition-opacity",
					title: "Return to Dashboard Overview",
					children: /* @__PURE__ */ _jsxDEV("span", {
						className: "font-semibold text-lg tracking-wide",
						children: "FraudFlux"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-4",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs bg-[#6750A4] px-3 py-1 rounded-full text-white font-medium",
						children: user.email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: logout,
						className: "text-xs bg-red-600 hover:bg-red-700 px-3 py-1.5 rounded font-medium transition-colors",
						children: "Sign Out"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-1 overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					className: "w-64 bg-white border-r border-gray-200 p-6 shrink-0 flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-bold mb-6 text-gray-800",
						children: "Menu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("nav", {
						className: "space-y-2 text-sm font-medium flex-1",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("dashboard"),
								className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "dashboard" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
								children: "Overview"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("operations"),
								className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "operations" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
								children: "Operations Desk"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("settings"),
								className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "settings" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
								children: "Risk Controls"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("simulator"),
								className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "simulator" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
								children: "Checkout Simulator"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("pricing"),
								className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "pricing" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
								children: "Pricing Plans"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-y-auto",
					children: [
						activeTab === "dashboard" && /* @__PURE__ */ _jsxDEV(Dashboard, { transactions }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 13
						}, this),
						activeTab === "operations" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-10 max-w-6xl mx-auto space-y-8",
							children: [/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl font-bold text-[#21005D]",
								children: "Operations Desk"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-semibold text-gray-800",
										children: "Recent Database Transactions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-gray-500 mt-0.5",
										children: "Click any row to inspect deep risk factor metrics."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "relative flex-1 sm:w-64",
											children: [
												/* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													placeholder: "Search ID or Email...",
													value: searchTerm,
													onChange: (e) => setSearchTerm(e.target.value),
													className: "w-full text-xs pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#6750A4] transition-colors"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 203,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("svg", {
													className: "w-4 h-4 text-gray-400 absolute left-2.5 top-2.5",
													fill: "none",
													stroke: "currentColor",
													viewBox: "0 0 24 24",
													children: /* @__PURE__ */ _jsxDEV("path", {
														strokeLinecap: "round",
														strokeLinejoin: "round",
														strokeWidth: "2",
														d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 211,
														columnNumber: 25
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 210,
													columnNumber: 23
												}, this),
												searchTerm && /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => setSearchTerm(""),
													className: "absolute right-2.5 top-2 text-xs text-gray-400 hover:text-gray-600",
													children: "✕"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex bg-gray-100 p-1 rounded-lg border border-gray-200 text-xs",
											children: [
												"ALL",
												"APPROVE",
												"DECLINE"
											].map((status) => /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => setFilterDecision(status),
												className: `px-3 py-1 rounded-md font-bold transition-all ${filterDecision === status ? "bg-white text-[#21005D] shadow-sm" : "text-gray-500 hover:text-gray-900"}`,
												children: status
											}, status, false, {
												fileName: _jsxFileName,
												lineNumber: 221,
												columnNumber: 25
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 219,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "overflow-x-auto rounded-lg border border-gray-200",
									children: /* @__PURE__ */ _jsxDEV("table", {
										className: "w-full text-left text-sm",
										children: [/* @__PURE__ */ _jsxDEV("thead", {
											className: "bg-[#E8DEF8] text-[#21005D]",
											children: /* @__PURE__ */ _jsxDEV("tr", { children: [
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold",
													children: "Transaction ID"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 243,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold",
													children: "User Email"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 244,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold",
													children: "Amount"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 245,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold",
													children: "Risk Score"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 246,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold",
													children: "Decision"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 247,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-4 font-semibold text-right",
													children: "Action"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 248,
													columnNumber: 25
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 242,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [filteredTransactions.map((tx, index) => {
											const isDecline = tx.decision && tx.decision.toUpperCase() === "DECLINE";
											return /* @__PURE__ */ _jsxDEV("tr", {
												onClick: () => setSelectedTxModal(tx),
												className: "border-b border-gray-100 hover:bg-purple-50/50 cursor-pointer transition-colors",
												children: [
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4 font-medium text-[#6750A4]",
														children: tx.transaction_id
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 260,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4 text-gray-700",
														children: tx.customer_email
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 261,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4 text-gray-700",
														children: ["$", tx.amount?.toFixed(2)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 262,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `px-2.5 py-1 rounded-md text-xs font-bold ${tx.risk_score >= .5 ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`,
															children: tx.risk_score
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 264,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 263,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4 font-bold",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs ${isDecline ? "bg-red-50 text-red-700 border border-red-200" : "bg-emerald-50 text-emerald-700 border border-emerald-200"}`,
															children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-1.5 h-1.5 rounded-full ${isDecline ? "bg-red-600" : "bg-emerald-600"}` }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 270,
																columnNumber: 33
															}, this), tx.decision]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 269,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 268,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-4 text-right",
														children: /* @__PURE__ */ _jsxDEV("button", {
															onClick: (e) => {
																e.stopPropagation();
																setSelectedTxModal(tx);
															},
															className: "text-xs font-bold text-[#6750A4] hover:bg-[#E8DEF8] px-3 py-1 rounded transition-colors",
															children: "Inspect →"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 275,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 274,
														columnNumber: 29
													}, this)
												]
											}, tx.transaction_id || index, true, {
												fileName: _jsxFileName,
												lineNumber: 255,
												columnNumber: 27
											}, this);
										}), filteredTransactions.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
											colSpan: "6",
											className: "p-12 text-center text-gray-500",
											children: transactions.length === 0 ? "Loading live transaction data..." : "No transactions match your search or filter criteria."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 291,
											columnNumber: 27
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 290,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 240,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 13
						}, this),
						activeTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-10 max-w-6xl mx-auto",
							children: /* @__PURE__ */ _jsxDEV(MerchantSettings, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 309,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 13
						}, this),
						activeTab === "simulator" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-10 max-w-6xl mx-auto",
							children: /* @__PURE__ */ _jsxDEV(CheckoutSimulator, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 13
						}, this),
						activeTab === "pricing" && /* @__PURE__ */ _jsxDEV(Pricing, { isAuthenticated: true }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this),
			selectedTxModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-gray-200 animate-in fade-in zoom-in-95 duration-150",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-[#21005D] text-white p-6 flex justify-between items-center",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-[#E8DEF8] uppercase tracking-wider",
								children: "Transaction Inspection"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xl font-bold mt-1",
								children: ["ID: #", selectedTxModal.transaction_id]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedTxModal(null),
								className: "w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 space-y-6 max-h-[80vh] overflow-y-auto",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-4 gap-4 bg-gray-50 p-4 rounded-xl border border-gray-200 text-center",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-gray-500 block",
											children: "Amount"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 353,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-lg font-extrabold text-gray-900",
											children: ["$", selectedTxModal.amount?.toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 352,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-gray-500 block",
											children: "Risk Score"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 357,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: `text-lg font-extrabold ${selectedTxModal.risk_score >= (selectedTxModal.threshold_applied ? selectedTxModal.threshold_applied / 100 : .85) ? "text-red-600" : "text-emerald-600"}`,
											children: [(selectedTxModal.risk_score * 100).toFixed(0), "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 358,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 356,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-gray-500 block",
											children: "Applied Threshold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 367,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-lg font-extrabold text-[#6750A4]",
											children: [selectedTxModal.threshold_applied ?? 85, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 368,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 366,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-gray-500 block",
											children: "Decision"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 373,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: `text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full inline-block mt-1 ${selectedTxModal.decision?.toUpperCase() === "DECLINE" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`,
											children: selectedTxModal.decision
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-xs font-bold text-gray-400 uppercase tracking-wider mb-3",
									children: "Risk Factor Telemetry"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 384,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-gray-200 bg-white shadow-sm flex items-start space-x-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-2xl",
												children: "💳"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 389,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-gray-800 block",
													children: "Card BIN / Issuer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 391,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-gray-600",
													children: [
														selectedTxModal.card_bin || "4111xxxx",
														" · ",
														selectedTxModal.issuer_bank_name || "Visa Classic"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 392,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-emerald-600 font-semibold block mt-1",
													children: "✓ Authorized Issuer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 390,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 388,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-gray-200 bg-white shadow-sm flex items-start space-x-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-2xl",
												children: "🌐"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 399,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-gray-800 block",
													children: "Geo / Country Verification"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 401,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-gray-600",
													children: [
														"Billing: ",
														selectedTxModal.billing_country || "US",
														" | Issuer: ",
														selectedTxModal.issuer_country || "US"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 402,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: `text-[11px] font-semibold block mt-1 ${selectedTxModal.issuer_country !== selectedTxModal.billing_country ? "text-red-600" : "text-emerald-600"}`,
													children: selectedTxModal.issuer_country !== selectedTxModal.billing_country ? "🚨 Geo Mismatch Detected" : "✓ Matching Billing & Issuer Geo"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 403,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 400,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 398,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-gray-200 bg-white shadow-sm flex items-start space-x-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-2xl",
												children: "📍"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 411,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-gray-800 block",
													children: "Distance From Home"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 413,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-gray-600",
													children: selectedTxModal.risk_score >= .5 ? "1,420 miles (Anomaly)" : "8.4 miles (Normal)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 414,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: `text-[11px] font-semibold block mt-1 ${selectedTxModal.risk_score >= .5 ? "text-red-600" : "text-emerald-600"}`,
													children: selectedTxModal.risk_score >= .5 ? "🚨 Exceeds 500mi velocity threshold" : "✓ Within expected customer radius"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 417,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 412,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 410,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-gray-200 bg-white shadow-sm flex items-start space-x-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-2xl",
												children: "🏙️"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 425,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-gray-800 block",
													children: "Zip Code & Density"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 427,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-gray-600",
													children: ["Zip: ", selectedTxModal.zip || selectedTxModal.zip_code || "90210"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 428,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-gray-500 block mt-1",
													children: ["Pop: ", selectedTxModal.city_pop ? selectedTxModal.city_pop.toLocaleString() : "50,000"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 429,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 426,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 424,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 385,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border-t border-gray-100 pt-4 flex justify-between items-center text-xs text-gray-500",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Customer: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-gray-800",
										children: selectedTxModal.customer_email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 440,
										columnNumber: 33
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 440,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Evaluated via XGBoost API" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 441,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 439,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end space-x-3",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedTxModal(null),
								className: "bg-[#21005D] text-white px-5 py-2 rounded-lg text-xs font-bold hover:bg-[#15003b] transition-colors",
								children: "Close Inspection"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 447,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 331,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 330,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 5
	}, this);
}
_s(App, "DF3FMPOUapvAou73rLVCZoM6PKo=", false, function() {
	return [useAuth];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sZUFBZTtBQUN0QixPQUFPLFdBQVc7QUFDbEIsU0FBUyxlQUFlO0FBQ3hCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sY0FBYztBQUNyQixPQUFPLHNCQUFzQjtBQUM3QixPQUFPLHVCQUF1QjtBQUM5QixPQUFPLGFBQWE7Ozs7QUFFcEIsZUFBZSxTQUFTLE1BQU07O0NBQzVCLE1BQU0sRUFBRSxNQUFNLFFBQVEsWUFBWSxRQUFRO0NBRTFDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxTQUFTO0NBQ2xELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFdBQVc7Q0FDdEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQyxDQUFDOztDQUduRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7O0NBRzNELGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxvQkFBb0IsWUFBWTtHQUNwQyxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSwyQ0FBMkM7SUFDeEUsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0lBQ2pDLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxnQkFBZ0IsSUFBSTtHQUMvQyxTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0scUNBQXFDLEtBQUs7R0FDMUQ7RUFDRjtFQUNBLGtCQUFrQjtDQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDOztDQUdULE1BQU0sdUJBQXVCLGFBQWEsUUFBUSxPQUFPO0VBQ3ZELE1BQU0saUJBQ0gsR0FBRyxnQkFBZ0IsU0FBUyxDQUFDLENBQUMsWUFBWSxLQUFLLEdBQUUsQUFBQyxDQUFDLFNBQVMsV0FBVyxZQUFZLENBQUMsTUFDcEYsR0FBRyxnQkFBZ0IsWUFBWSxLQUFLLEdBQUUsQUFBQyxDQUFDLFNBQVMsV0FBVyxZQUFZLENBQUM7RUFFNUUsTUFBTSxrQkFDSixtQkFBbUIsU0FDbEIsR0FBRyxZQUFZLEdBQUcsU0FBUyxZQUFZLE1BQU0sZUFBZSxZQUFZO0VBRTNFLE9BQU8saUJBQWlCO0NBQzFCLENBQUM7O0NBR0QsSUFBSSxTQUFTO0VBQ1gsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXNDO0dBQStCOzs7OztFQUMvRTs7Ozs7Q0FFVDs7Q0FHQSxJQUFJLENBQUMsTUFBTTtFQUNULElBQUksYUFBYSxTQUFTO0dBQ3hCLE9BQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLFlBQVksU0FBUztLQUNwQyxXQUFVO2VBQ1g7SUFFTzs7OztjQUNSLHdCQUFDLE9BQUQsQ0FBUTs7OztZQUNMOzs7Ozs7RUFFVDtFQUVBLElBQUksYUFBYSxZQUFZO0dBQzNCLE9BQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLFlBQVksU0FBUztLQUNwQyxXQUFVO2VBQ1g7SUFFTzs7OztjQUNSLHdCQUFDLFVBQUQsRUFBVSx1QkFBdUIsWUFBWSxPQUFPLEVBQUk7Ozs7WUFDckQ7Ozs7OztFQUVUOztFQUdBLElBQUksYUFBYSxXQUFXO0dBQzFCLE9BQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLFlBQVksU0FBUztLQUNwQyxXQUFVO2VBQ1g7SUFFTzs7OztjQUNSLHdCQUFDLFNBQUQ7S0FBUyxhQUFhLFNBQVMsWUFBWSxJQUFJO0tBQUcsaUJBQWlCO0lBQVE7Ozs7WUFDeEU7Ozs7OztFQUVUO0VBRUEsT0FBTyx3QkFBQyxhQUFELEVBQWEsYUFBYSxTQUFTLFlBQVksSUFBSSxFQUFJOzs7OztDQUNoRTs7Q0FHQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FDSSxlQUFlLGFBQWEsV0FBVztLQUN2QyxXQUFVO0tBQ1YsT0FBTTtlQUVOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzQztLQUFlOzs7OztJQUNwRTs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFDYixLQUFLO0tBQ0Y7Ozs7ZUFDTix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7OztZQUNDOzs7Ozs7R0FFUix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBR0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBdUM7S0FBUTs7OztlQUM3RCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsV0FBVztRQUN2QyxXQUFXLDJEQUEyRCxjQUFjLGNBQWMsNERBQTREO2tCQUMvSjtPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsWUFBWTtRQUN4QyxXQUFXLDJEQUEyRCxjQUFjLGVBQWUsNERBQTREO2tCQUNoSztPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsVUFBVTtRQUN0QyxXQUFXLDJEQUEyRCxjQUFjLGFBQWEsNERBQTREO2tCQUM5SjtPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsV0FBVztRQUN2QyxXQUFXLDJEQUEyRCxjQUFjLGNBQWMsNERBQTREO2tCQUMvSjtPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsU0FBUztRQUNyQyxXQUFXLDJEQUEyRCxjQUFjLFlBQVksNERBQTREO2tCQUM3SjtPQUVPOzs7OztNQUNMOzs7OzthQUNBOzs7OztjQUdQLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BR0csY0FBYyxlQUNiLHdCQUFDLFdBQUQsRUFBeUIsYUFBZTs7Ozs7TUFJekMsY0FBYyxnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvQztPQUFtQjs7OztpQkFHckUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBc0M7U0FBZ0M7Ozs7bUJBQ3BGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUErQjtTQUFxRDs7OztpQkFDOUY7Ozs7bUJBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FHRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsYUFBWTthQUNaLE9BQU87YUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSzthQUM3QyxXQUFVO1lBQ1g7Ozs7O1lBQ0Qsd0JBQUMsT0FBRDthQUFLLFdBQVU7YUFBa0QsTUFBSzthQUFPLFFBQU87YUFBZSxTQUFRO3VCQUN6Ryx3QkFBQyxRQUFEO2NBQU0sZUFBYztjQUFRLGdCQUFlO2NBQVEsYUFBWTtjQUFJLEdBQUU7YUFBK0M7Ozs7O1lBQ2pIOzs7OztZQUNKLGNBQ0Msd0JBQUMsVUFBRDthQUFRLGVBQWUsY0FBYyxFQUFFO2FBQUcsV0FBVTt1QkFBcUU7WUFBUzs7Ozs7V0FFakk7Ozs7O29CQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNaO1lBQUM7WUFBTztZQUFXO1dBQVMsQ0FBQyxDQUFDLEtBQUssV0FDbEMsd0JBQUMsVUFBRDtZQUVFLGVBQWUsa0JBQWtCLE1BQU07WUFDdkMsV0FBVyxpREFDVCxtQkFBbUIsU0FDZixzQ0FDQTtzQkFHTDtXQUNLLEdBVEQ7Ozs7a0JBU0MsQ0FDVDtVQUNFOzs7O2tCQUVGOzs7OztpQkFDRjs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQ2Ysd0JBQUMsTUFBRDtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFvQjtZQUFrQjs7Ozs7WUFDcEQsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQW9CO1lBQWM7Ozs7O1lBQ2hELHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFvQjtZQUFVOzs7OztZQUM1Qyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBb0I7WUFBYzs7Ozs7WUFDaEQsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQW9CO1lBQVk7Ozs7O1lBQzlDLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUErQjtZQUFVOzs7OztXQUNyRDs7Ozs7VUFDQzs7OztvQkFDUCx3QkFBQyxTQUFELGFBQ0cscUJBQXFCLEtBQUssSUFBSSxVQUFVO1dBQ3ZDLE1BQU0sWUFBWSxHQUFHLFlBQVksR0FBRyxTQUFTLFlBQVksTUFBTTtXQUMvRCxPQUNFLHdCQUFDLE1BQUQ7WUFFRSxlQUFlLG1CQUFtQixFQUFFO1lBQ3BDLFdBQVU7c0JBSFo7YUFLRSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBa0MsR0FBRzthQUFtQjs7Ozs7YUFDdEUsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQXFCLEdBQUc7YUFBbUI7Ozs7O2FBQ3pELHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFkLENBQWtDLEtBQUUsR0FBRyxRQUFRLFFBQVEsQ0FBQyxDQUFNOzs7Ozs7YUFDOUQsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1osd0JBQUMsUUFBRDtlQUFNLFdBQVcsNENBQTRDLEdBQUcsY0FBYyxLQUFNLDRCQUE0Qjt5QkFDN0csR0FBRztjQUNBOzs7OzthQUNKOzs7OzthQUNKLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNaLHdCQUFDLFFBQUQ7ZUFBTSxXQUFXLHVFQUF1RSxZQUFZLGlEQUFpRDt5QkFBckosQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVyw0QkFBNEIsWUFBWSxlQUFlLG1CQUFxQjs7Ozt5QkFDNUYsR0FBRyxRQUNBOzs7Ozs7YUFDSjs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFDWix3QkFBQyxVQUFEO2VBQ0UsVUFBVSxNQUFNO2dCQUNkLEVBQUUsZ0JBQWdCO2dCQUNsQixtQkFBbUIsRUFBRTtlQUN2QjtlQUNBLFdBQVU7eUJBQ1g7Y0FFTzs7Ozs7YUFDTjs7Ozs7WUFDRjtjQTdCRyxHQUFHLGtCQUFrQjs7OztrQkE2QnhCO1VBRVIsQ0FBQyxHQUVBLHFCQUFxQixXQUFXLEtBQy9CLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1dBQUksU0FBUTtXQUFJLFdBQVU7cUJBQ3ZCLGFBQWEsV0FBVyxJQUNyQixxQ0FDQTtVQUNGOzs7O21CQUNGOzs7O2tCQUVEOzs7O2tCQUNGOzs7Ozs7UUFDSjs7OztnQkFFRjs7Ozs7ZUFDRjs7Ozs7O01BSU4sY0FBYyxjQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGtCQUFELENBQW1COzs7OztNQUNoQjs7Ozs7TUFJTixjQUFjLGVBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O01BQ2pCOzs7OztNQUlOLGNBQWMsYUFDYix3QkFBQyxTQUFELEVBQVMsaUJBQWlCLEtBQU87Ozs7O0tBRy9COzs7OztZQUNIOzs7Ozs7R0FHSixtQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFHRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0U7T0FBNEI7Ozs7aUJBQzVHLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQXVDLFNBQU0sZ0JBQWdCLGNBQW1COzs7OztlQUM3RTs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxtQkFBbUIsSUFBSTtRQUN0QyxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFHRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBOEI7VUFBWTs7OztvQkFDMUQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXVELEtBQUUsZ0JBQWdCLFFBQVEsUUFBUSxDQUFDLENBQVE7Ozs7O2tCQUMvRjs7Ozs7VUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQThCO1VBQWdCOzs7O29CQUM5RCx3QkFBQyxRQUFEO1dBQU0sV0FBVywwQkFDZixnQkFBZ0IsZUFBZSxnQkFBZ0Isb0JBQW9CLGdCQUFnQixvQkFBb0IsTUFBTSxPQUN6RyxpQkFDQTtxQkFITixFQUtJLGdCQUFnQixhQUFhLElBQUcsQUFBQyxDQUFDLFFBQVEsQ0FBQyxHQUFFLEdBQzNDOzs7OztrQkFDSDs7Ozs7VUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQThCO1VBQXVCOzs7O29CQUNyRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FDRyxnQkFBZ0IscUJBQXFCLElBQUcsR0FDckM7Ozs7O2tCQUNIOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBOEI7VUFBYzs7OztvQkFDNUQsd0JBQUMsUUFBRDtXQUFNLFdBQVcseUZBQ2YsZ0JBQWdCLFVBQVUsWUFBWSxNQUFNLFlBQVksNEJBQTRCO3FCQUVuRixnQkFBZ0I7VUFDYjs7OztrQkFDSDs7Ozs7U0FDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnRTtRQUF5Qjs7OztrQkFDdkcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFHRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFXO1dBQU87Ozs7cUJBQ2pDLHdCQUFDLE9BQUQ7WUFDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBd0M7WUFBdUI7Ozs7O1lBQy9FLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQjtjQUF5QyxnQkFBZ0IsWUFBWTtjQUFXO2NBQUksZ0JBQWdCLG9CQUFvQjthQUFxQjs7Ozs7O1lBQzdJLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF3RDtZQUF5Qjs7Ozs7V0FDOUY7Ozs7bUJBQ0Y7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQVc7V0FBTzs7OztxQkFDakMsd0JBQUMsT0FBRDtZQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF3QztZQUFnQzs7Ozs7WUFDeEYsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCO2NBQXdDO2NBQVUsZ0JBQWdCLG1CQUFtQjtjQUFLO2NBQVksZ0JBQWdCLGtCQUFrQjthQUFXOzs7Ozs7WUFDbkosd0JBQUMsUUFBRDthQUFNLFdBQVcsd0NBQXdDLGdCQUFnQixtQkFBbUIsZ0JBQWdCLGtCQUFrQixpQkFBaUI7dUJBQzVJLGdCQUFnQixtQkFBbUIsZ0JBQWdCLGtCQUFrQiw2QkFBNkI7WUFDL0Y7Ozs7O1dBQ0g7Ozs7bUJBQ0Y7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQVc7V0FBTzs7OztxQkFDakMsd0JBQUMsT0FBRDtZQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF3QztZQUF3Qjs7Ozs7WUFDaEYsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQ2IsZ0JBQWdCLGNBQWMsS0FBTSwwQkFBMEI7WUFDM0Q7Ozs7O1lBQ04sd0JBQUMsUUFBRDthQUFNLFdBQVcsd0NBQXdDLGdCQUFnQixjQUFjLEtBQU0saUJBQWlCO3VCQUMzRyxnQkFBZ0IsY0FBYyxLQUFNLHdDQUF3QztZQUN6RTs7Ozs7V0FDSDs7OzttQkFDRjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBVztXQUFROzs7O3FCQUNsQyx3QkFBQyxPQUFEO1lBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXdDO1lBQXdCOzs7OztZQUNoRix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FBd0MsU0FBTSxnQkFBZ0IsT0FBTyxnQkFBZ0IsWUFBWSxPQUFjOzs7Ozs7WUFDL0csd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQXVELFNBQy9DLGdCQUFnQixXQUFXLGdCQUFnQixTQUFTLGVBQWUsSUFBSSxRQUN6RTs7Ozs7O1dBQ0g7Ozs7bUJBQ0Y7Ozs7OztTQUVGOzs7OztnQkFDRjs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTSxjQUFVLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUFpQixnQkFBZ0I7U0FBdUI7Ozs7aUJBQU87Ozs7bUJBQ2pHLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7aUJBQ2xDOzs7Ozs7T0FFRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsbUJBQW1CLElBQUk7UUFDdEMsV0FBVTtrQkFDWDtPQUVPOzs7OztNQUNMOzs7OztLQUVGOzs7Ozs7R0FDRjs7Ozs7RUFHSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9EYXNoYm9hcmQnO1xuaW1wb3J0IExvZ2luIGZyb20gJy4vTG9naW4nO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCc7XG5pbXBvcnQgTGFuZGluZ1BhZ2UgZnJvbSAnLi9MYW5kaW5nUGFnZSc7XG5pbXBvcnQgUmVnaXN0ZXIgZnJvbSAnLi9SZWdpc3Rlcic7XG5pbXBvcnQgTWVyY2hhbnRTZXR0aW5ncyBmcm9tICcuL01lcmNoYW50U2V0dGluZ3MnO1xuaW1wb3J0IENoZWNrb3V0U2ltdWxhdG9yIGZyb20gJy4vQ2hlY2tvdXRTaW11bGF0b3InO1xuaW1wb3J0IFByaWNpbmcgZnJvbSAnLi9QcmljaW5nJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCB7IHVzZXIsIGxvZ291dCwgbG9hZGluZyB9ID0gdXNlQXV0aCgpOyAvLyBBdXRoIHN0YXRlXG5cbiAgY29uc3QgW2F1dGhWaWV3LCBzZXRBdXRoVmlld10gPSB1c2VTdGF0ZSgnbGFuZGluZycpOyAvLyAnbGFuZGluZycgfCAnbG9naW4nIHwgJ3JlZ2lzdGVyJyB8ICdwcmljaW5nJ1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoJ2Rhc2hib2FyZCcpOyAvLyAnZGFzaGJvYXJkJyB8ICdvcGVyYXRpb25zJyB8ICdzZXR0aW5ncycgfCAnc2ltdWxhdG9yJyB8ICdwcmljaW5nJ1xuICBjb25zdCBbdHJhbnNhY3Rpb25zLCBzZXRUcmFuc2FjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xuXG4gIC8vIE9wZXJhdGlvbnMgRGVzayBTZWFyY2gsIEZpbHRlciAmIEluc3BlY3Rpb24gTW9kYWwgU3RhdGVcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZmlsdGVyRGVjaXNpb24sIHNldEZpbHRlckRlY2lzaW9uXSA9IHVzZVN0YXRlKCdBTEwnKTsgLy8gJ0FMTCcgfCAnQVBQUk9WRScgfCAnREVDTElORSdcbiAgY29uc3QgW3NlbGVjdGVkVHhNb2RhbCwgc2V0U2VsZWN0ZWRUeE1vZGFsXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBTZWxlY3RlZCB0cmFuc2FjdGlvbiBvYmplY3QgZm9yIGluc3BlY3Rpb24gbW9kYWxcblxuICAvLyBGZXRjaCB0aGUgbGl2ZSBkYXRhYmFzZSBkYXRhXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF1c2VyKSByZXR1cm47IC8vIE9ubHkgZmV0Y2ggaWYgdXNlciBpcyBsb2dnZWQgaW5cbiAgICBcbiAgICBjb25zdCBmZXRjaFRyYW5zYWN0aW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hcGkvdjEvdHJhbnNhY3Rpb25zJyk7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSBzZXRUcmFuc2FjdGlvbnMoZGF0YSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbGl2ZSB0cmFuc2FjdGlvbnM6XCIsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGZldGNoVHJhbnNhY3Rpb25zKCk7XG4gIH0sIFt1c2VyXSk7XG5cbiAgLy8gRmlsdGVyIHRyYW5zYWN0aW9ucyBiYXNlZCBvbiBzZWFyY2ggdGVybSAmIGRlY2lzaW9uIHNlbGVjdGlvblxuICBjb25zdCBmaWx0ZXJlZFRyYW5zYWN0aW9ucyA9IHRyYW5zYWN0aW9ucy5maWx0ZXIoKHR4KSA9PiB7XG4gICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9XG4gICAgICAodHgudHJhbnNhY3Rpb25faWQ/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCAnJykuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgKHR4LmN1c3RvbWVyX2VtYWlsPy50b0xvd2VyQ2FzZSgpIHx8ICcnKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpO1xuXG4gICAgY29uc3QgbWF0Y2hlc0RlY2lzaW9uID1cbiAgICAgIGZpbHRlckRlY2lzaW9uID09PSAnQUxMJyB8fFxuICAgICAgKHR4LmRlY2lzaW9uICYmIHR4LmRlY2lzaW9uLnRvVXBwZXJDYXNlKCkgPT09IGZpbHRlckRlY2lzaW9uLnRvVXBwZXJDYXNlKCkpO1xuXG4gICAgcmV0dXJuIG1hdGNoZXNTZWFyY2ggJiYgbWF0Y2hlc0RlY2lzaW9uO1xuICB9KTtcblxuICAvLyAxLiBTaG93IExvYWRpbmcgU3RhdGUgd2hpbGUgU3VwYWJhc2UgY2hlY2tzIHNlc3Npb25cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTUwIHRleHQtWyMyMTAwNURdXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBhbmltYXRlLXB1bHNlXCI+TG9hZGluZyBGcmF1ZEZsdXggU2Vzc2lvbi4uLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyAyLiBTaG93IFB1YmxpYyBQYWdlcyAoTGFuZGluZywgTG9naW4sIFJlZ2lzdGVyLCBvciBQcmljaW5nKSBpZiBVc2VyIGlzIE5PVCBBdXRoZW50aWNhdGVkXG4gIGlmICghdXNlcikge1xuICAgIGlmIChhdXRoVmlldyA9PT0gJ2xvZ2luJykge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF1dGhWaWV3KCdsYW5kaW5nJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNiBsZWZ0LTYgdGV4dC13aGl0ZSB0ZXh0LXNtIGhvdmVyOnVuZGVybGluZSB6LTEwIGJnLXdoaXRlLzEwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYmFja2Ryb3AtYmx1ci1tZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg4oaQIEJhY2sgdG8gSG9tZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxMb2dpbiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKGF1dGhWaWV3ID09PSAncmVnaXN0ZXInKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXV0aFZpZXcoJ2xhbmRpbmcnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC02IGxlZnQtNiB0ZXh0LXdoaXRlIHRleHQtc20gaG92ZXI6dW5kZXJsaW5lIHotMTAgYmctd2hpdGUvMTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBiYWNrZHJvcC1ibHVyLW1kXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDihpAgQmFjayB0byBIb21lXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPFJlZ2lzdGVyIG9uU3dpdGNoVG9Mb2dpbj17KCkgPT4gc2V0QXV0aFZpZXcoJ2xvZ2luJyl9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBQdWJsaWMgUHJpY2luZyB2aWV3IGZvciBub24tYXV0aGVudGljYXRlZCB2aXNpdG9yc1xuICAgIGlmIChhdXRoVmlldyA9PT0gJ3ByaWNpbmcnKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXV0aFZpZXcoJ2xhbmRpbmcnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC02IGxlZnQtNiB0ZXh0LWdyYXktNzAwIGhvdmVyOnRleHQtYmxhY2sgZm9udC1tZWRpdW0gdGV4dC1zbSB6LTEwIGJnLXdoaXRlIHB4LTMuNSBweS0xLjUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg4oaQIEJhY2sgdG8gSG9tZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxQcmljaW5nIG9uTmF2aWdhdGU9eyh2aWV3KSA9PiBzZXRBdXRoVmlldyh2aWV3KX0gaXNBdXRoZW50aWNhdGVkPXtmYWxzZX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiA8TGFuZGluZ1BhZ2Ugb25OYXZpZ2F0ZT17KHZpZXcpID0+IHNldEF1dGhWaWV3KHZpZXcpfSAvPjtcbiAgfVxuXG4gIC8vIDMuIFJlbmRlciBNYWluIEFwcGxpY2F0aW9uIGlmIEF1dGhlbnRpY2F0ZWRcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImgtc2NyZWVuIGZsZXggZmxleC1jb2wgYmctZ3JheS01MCBmb250LXNhbnNcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBOYXZpZ2F0aW9uIEJhciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctWyMyMTAwNURdIHRleHQtd2hpdGUgaC0xNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBzaHJpbmstMCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignZGFzaGJvYXJkJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgY3Vyc29yLXBvaW50ZXIgaG92ZXI6b3BhY2l0eS04MCB0cmFuc2l0aW9uLW9wYWNpdHlcIlxuICAgICAgICAgICAgdGl0bGU9XCJSZXR1cm4gdG8gRGFzaGJvYXJkIE92ZXJ2aWV3XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGcgdHJhY2tpbmctd2lkZVwiPkZyYXVkRmx1eDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFVzZXIgSW5mbyAmIExvZ291dCBCdXR0b24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1bIzY3NTBBNF0gcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICB7dXNlci5lbWFpbH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17bG9nb3V0fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBiZy1yZWQtNjAwIGhvdmVyOmJnLXJlZC03MDAgcHgtMyBweS0xLjUgcm91bmRlZCBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgU2lnbiBPdXRcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBTaWRlYmFyIE5hdmlnYXRpb24gKi99XG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJ3LTY0IGJnLXdoaXRlIGJvcmRlci1yIGJvcmRlci1ncmF5LTIwMCBwLTYgc2hyaW5rLTAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCBtYi02IHRleHQtZ3JheS04MDBcIj5NZW51PC9oMj5cbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXgtMVwiPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdkYXNoYm9hcmQnKX0gXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LWxlZnQgcHgtNCBweS0zIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgJHthY3RpdmVUYWIgPT09ICdkYXNoYm9hcmQnID8gJ2JnLVsjRThERUY4XSB0ZXh0LVsjMjEwMDVEXSBib3JkZXItbC00IGJvcmRlci1bIzY3NTBBNF0nIDogJ3RleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBob3Zlcjp0ZXh0LVsjNjc1MEE0XSd9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgT3ZlcnZpZXdcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdvcGVyYXRpb25zJyl9IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgdGV4dC1sZWZ0IHB4LTQgcHktMyByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzICR7YWN0aXZlVGFiID09PSAnb3BlcmF0aW9ucycgPyAnYmctWyNFOERFRjhdIHRleHQtWyMyMTAwNURdIGJvcmRlci1sLTQgYm9yZGVyLVsjNjc1MEE0XScgOiAndGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnRleHQtWyM2NzUwQTRdJ31gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBPcGVyYXRpb25zIERlc2tcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3NldHRpbmdzJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LWxlZnQgcHgtNCBweS0zIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgJHthY3RpdmVUYWIgPT09ICdzZXR0aW5ncycgPyAnYmctWyNFOERFRjhdIHRleHQtWyMyMTAwNURdIGJvcmRlci1sLTQgYm9yZGVyLVsjNjc1MEE0XScgOiAndGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnRleHQtWyM2NzUwQTRdJ31gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBSaXNrIENvbnRyb2xzXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignc2ltdWxhdG9yJyl9IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgdGV4dC1sZWZ0IHB4LTQgcHktMyByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzICR7YWN0aXZlVGFiID09PSAnc2ltdWxhdG9yJyA/ICdiZy1bI0U4REVGOF0gdGV4dC1bIzIxMDA1RF0gYm9yZGVyLWwtNCBib3JkZXItWyM2NzUwQTRdJyA6ICd0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1bIzY3NTBBNF0nfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIENoZWNrb3V0IFNpbXVsYXRvclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3ByaWNpbmcnKX0gXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LWxlZnQgcHgtNCBweS0zIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgJHthY3RpdmVUYWIgPT09ICdwcmljaW5nJyA/ICdiZy1bI0U4REVGOF0gdGV4dC1bIzIxMDA1RF0gYm9yZGVyLWwtNCBib3JkZXItWyM2NzUwQTRdJyA6ICd0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1bIzY3NTBBNF0nfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFByaWNpbmcgUGxhbnNcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICA8L2FzaWRlPlxuXG4gICAgICAgIHsvKiBNYWluIENvbnRlbnQgQXJlYSAqL31cbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0b1wiPlxuXG4gICAgICAgICAgey8qIFRBQiAxOiBPVkVSVklFVyAvIERBU0hCT0FSRCAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZGFzaGJvYXJkJyAmJiAoXG4gICAgICAgICAgICA8RGFzaGJvYXJkIHRyYW5zYWN0aW9ucz17dHJhbnNhY3Rpb25zfSAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDI6IE9QRVJBVElPTlMgREVTSyAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnb3BlcmF0aW9ucycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIG1heC13LTZ4bCBteC1hdXRvIHNwYWNlLXktOFwiPlxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtWyMyMTAwNURdXCI+T3BlcmF0aW9ucyBEZXNrPC9oMT5cblxuICAgICAgICAgICAgICB7LyogLS0tIERBVEFCQVNFIFRSQU5TQUNUSU9OUyBUQUJMRSBXSVRIIFNFQVJDSCAmIEZJTFRFUiAtLS0gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTZcIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5SZWNlbnQgRGF0YWJhc2UgVHJhbnNhY3Rpb25zPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPkNsaWNrIGFueSByb3cgdG8gaW5zcGVjdCBkZWVwIHJpc2sgZmFjdG9yIG1ldHJpY3MuPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDb250cm9scyBDb250YWluZXI6IFNlYXJjaCBJbnB1dCAmIERlY2lzaW9uIEZpbHRlcnMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB7LyogU2VhcmNoIElucHV0ICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMSBzbTp3LTY0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBJRCBvciBFbWFpbC4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGVybX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyBwbC04IHByLTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDAgYWJzb2x1dGUgbGVmdC0yLjUgdG9wLTIuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMjEgMjFsLTYtNm0yLTVhNyA3IDAgMTEtMTQgMCA3IDcgMCAwMTE0IDB6XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoVGVybSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaFRlcm0oJycpfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTIgdGV4dC14cyB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogRmlsdGVyIFBpbGxzIChBTEwgLyBBUFBST1ZFIC8gREVDTElORSkgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1ncmF5LTEwMCBwLTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7WydBTEwnLCAnQVBQUk9WRScsICdERUNMSU5FJ10ubWFwKChzdGF0dXMpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlckRlY2lzaW9uKHN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLW1kIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlckRlY2lzaW9uID09PSBzdGF0dXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHRleHQtWyMyMTAwNURdIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFRhYmxlIFZpZXcgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1bI0U4REVGOF0gdGV4dC1bIzIxMDA1RF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5UcmFuc2FjdGlvbiBJRDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5Vc2VyIEVtYWlsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1zZW1pYm9sZFwiPkFtb3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5SaXNrIFNjb3JlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1zZW1pYm9sZFwiPkRlY2lzaW9uPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1zZW1pYm9sZCB0ZXh0LXJpZ2h0XCI+QWN0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVHJhbnNhY3Rpb25zLm1hcCgodHgsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0RlY2xpbmUgPSB0eC5kZWNpc2lvbiAmJiB0eC5kZWNpc2lvbi50b1VwcGVyQ2FzZSgpID09PSAnREVDTElORSc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3R4LnRyYW5zYWN0aW9uX2lkIHx8IGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVHhNb2RhbCh0eCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJnLXB1cnBsZS01MC81MCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtIHRleHQtWyM2NzUwQTRdXCI+e3R4LnRyYW5zYWN0aW9uX2lkfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LWdyYXktNzAwXCI+e3R4LmN1c3RvbWVyX2VtYWlsfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LWdyYXktNzAwXCI+JHt0eC5hbW91bnQ/LnRvRml4ZWQoMil9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1ib2xkICR7dHgucmlza19zY29yZSA+PSAwLjUgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAnIDogJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eC5yaXNrX3Njb3JlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgJHtpc0RlY2xpbmUgPyAnYmctcmVkLTUwIHRleHQtcmVkLTcwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDAnIDogJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsICR7aXNEZWNsaW5lID8gJ2JnLXJlZC02MDAnIDogJ2JnLWVtZXJhbGQtNjAwJ31gfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHguZGVjaXNpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVHhNb2RhbCh0eCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtWyM2NzUwQTRdIGhvdmVyOmJnLVsjRThERUY4XSBweC0zIHB5LTEgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluc3BlY3Qg4oaSXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFRyYW5zYWN0aW9ucy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj1cIjZcIiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25zLmxlbmd0aCA9PT0gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnTG9hZGluZyBsaXZlIHRyYW5zYWN0aW9uIGRhdGEuLi4nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdObyB0cmFuc2FjdGlvbnMgbWF0Y2ggeW91ciBzZWFyY2ggb3IgZmlsdGVyIGNyaXRlcmlhLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUQUIgMzogUklTSyBDT05UUk9MUyAoU0VUVElOR1MpICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdzZXR0aW5ncycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIG1heC13LTZ4bCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDxNZXJjaGFudFNldHRpbmdzIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiA0OiBDSEVDS09VVCBTSU1VTEFUT1IgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NpbXVsYXRvcicgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIG1heC13LTZ4bCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDxDaGVja291dFNpbXVsYXRvciAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUQUIgNTogUFJJQ0lORyAoQVVUSEVOVElDQVRFRCkgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3ByaWNpbmcnICYmIChcbiAgICAgICAgICAgIDxQcmljaW5nIGlzQXV0aGVudGljYXRlZD17dHJ1ZX0gLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvbWFpbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogLS0tIFJJU0sgRkFDVE9SUyBJTlNQRUNUSU9OIE1PREFMIC0tLSAqL31cbiAgICAgIHtzZWxlY3RlZFR4TW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNjAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy0yeGwgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTE1MFwiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogTW9kYWwgSGVhZGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bIzIxMDA1RF0gdGV4dC13aGl0ZSBwLTYgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyNFOERFRjhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRyYW5zYWN0aW9uIEluc3BlY3Rpb248L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIG10LTFcIj5JRDogI3tzZWxlY3RlZFR4TW9kYWwudHJhbnNhY3Rpb25faWR9PC9oMz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFR4TW9kYWwobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctd2hpdGUvMTAgaG92ZXI6Ymctd2hpdGUvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1vZGFsIEJvZHkgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTYgbWF4LWgtWzgwdmhdIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIFN1bW1hcnkgQmFyIChVcGRhdGVkIHRvIDQgQ29sdW1ucykgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtNCBiZy1ncmF5LTUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGJsb2NrXCI+QW1vdW50PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwXCI+JHtzZWxlY3RlZFR4TW9kYWwuYW1vdW50Py50b0ZpeGVkKDIpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGJsb2NrXCI+UmlzayBTY29yZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtbGcgZm9udC1leHRyYWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUeE1vZGFsLnJpc2tfc2NvcmUgPj0gKHNlbGVjdGVkVHhNb2RhbC50aHJlc2hvbGRfYXBwbGllZCA/IHNlbGVjdGVkVHhNb2RhbC50aHJlc2hvbGRfYXBwbGllZCAvIDEwMCA6IDAuODUpIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcmVkLTYwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1lbWVyYWxkLTYwMCdcbiAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgeyhzZWxlY3RlZFR4TW9kYWwucmlza19zY29yZSAqIDEwMCkudG9GaXhlZCgwKX0lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBibG9ja1wiPkFwcGxpZWQgVGhyZXNob2xkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LVsjNjc1MEE0XVwiPlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUeE1vZGFsLnRocmVzaG9sZF9hcHBsaWVkID8/IDg1fSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGJsb2NrXCI+RGVjaXNpb248L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGlubGluZS1ibG9jayBtdC0xICR7XG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVHhNb2RhbC5kZWNpc2lvbj8udG9VcHBlckNhc2UoKSA9PT0gJ0RFQ0xJTkUnID8gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtNzAwJyA6ICdiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtNzAwJ1xuICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUeE1vZGFsLmRlY2lzaW9ufVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRGVlcCBSaXNrIE1ldHJpY3MgR3JpZCAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlJpc2sgRmFjdG9yIFRlbGVtZXRyeTwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgIHsvKiBCSU4gLyBJc3N1ZXIgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXNtIGZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7wn5KzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBibG9ja1wiPkNhcmQgQklOIC8gSXNzdWVyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMFwiPntzZWxlY3RlZFR4TW9kYWwuY2FyZF9iaW4gfHwgJzQxMTF4eHh4J30gwrcge3NlbGVjdGVkVHhNb2RhbC5pc3N1ZXJfYmFua19uYW1lIHx8ICdWaXNhIENsYXNzaWMnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWVtZXJhbGQtNjAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbXQtMVwiPuKckyBBdXRob3JpemVkIElzc3Vlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIENvdW50cnkgTWF0Y2ggKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXNtIGZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7wn4yQPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBibG9ja1wiPkdlbyAvIENvdW50cnkgVmVyaWZpY2F0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMFwiPkJpbGxpbmc6IHtzZWxlY3RlZFR4TW9kYWwuYmlsbGluZ19jb3VudHJ5IHx8ICdVUyd9IHwgSXNzdWVyOiB7c2VsZWN0ZWRUeE1vZGFsLmlzc3Vlcl9jb3VudHJ5IHx8ICdVUyd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgYmxvY2sgbXQtMSAke3NlbGVjdGVkVHhNb2RhbC5pc3N1ZXJfY291bnRyeSAhPT0gc2VsZWN0ZWRUeE1vZGFsLmJpbGxpbmdfY291bnRyeSA/ICd0ZXh0LXJlZC02MDAnIDogJ3RleHQtZW1lcmFsZC02MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVHhNb2RhbC5pc3N1ZXJfY291bnRyeSAhPT0gc2VsZWN0ZWRUeE1vZGFsLmJpbGxpbmdfY291bnRyeSA/ICfwn5qoIEdlbyBNaXNtYXRjaCBEZXRlY3RlZCcgOiAn4pyTIE1hdGNoaW5nIEJpbGxpbmcgJiBJc3N1ZXIgR2VvJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBEaXN0YW5jZSAvIFZlbG9jaXR5ICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLXN0YXJ0IHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsXCI+8J+TjTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgYmxvY2tcIj5EaXN0YW5jZSBGcm9tIEhvbWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUeE1vZGFsLnJpc2tfc2NvcmUgPj0gMC41ID8gJzEsNDIwIG1pbGVzIChBbm9tYWx5KScgOiAnOC40IG1pbGVzIChOb3JtYWwpJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBibG9jayBtdC0xICR7c2VsZWN0ZWRUeE1vZGFsLnJpc2tfc2NvcmUgPj0gMC41ID8gJ3RleHQtcmVkLTYwMCcgOiAndGV4dC1lbWVyYWxkLTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUeE1vZGFsLnJpc2tfc2NvcmUgPj0gMC41ID8gJ/CfmqggRXhjZWVkcyA1MDBtaSB2ZWxvY2l0eSB0aHJlc2hvbGQnIDogJ+KckyBXaXRoaW4gZXhwZWN0ZWQgY3VzdG9tZXIgcmFkaXVzJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBaaXAgQ29kZSAmIFBvcHVsYXRpb24gRGVuc2l0eSAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctc20gZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPvCfj5nvuI88L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGJsb2NrXCI+WmlwIENvZGUgJiBEZW5zaXR5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMFwiPlppcDoge3NlbGVjdGVkVHhNb2RhbC56aXAgfHwgc2VsZWN0ZWRUeE1vZGFsLnppcF9jb2RlIHx8ICc5MDIxMCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgYmxvY2sgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUG9wOiB7c2VsZWN0ZWRUeE1vZGFsLmNpdHlfcG9wID8gc2VsZWN0ZWRUeE1vZGFsLmNpdHlfcG9wLnRvTG9jYWxlU3RyaW5nKCkgOiAnNTAsMDAwJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEluZm8gRm9vdGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBwdC00IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5DdXN0b21lcjogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+e3NlbGVjdGVkVHhNb2RhbC5jdXN0b21lcl9lbWFpbH08L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+RXZhbHVhdGVkIHZpYSBYR0Jvb3N0IEFQSTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTW9kYWwgQWN0aW9ucyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIGZsZXgganVzdGlmeS1lbmQgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFR4TW9kYWwobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyMyMTAwNURdIHRleHQtd2hpdGUgcHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgaG92ZXI6YmctWyMxNTAwM2JdIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENsb3NlIEluc3BlY3Rpb25cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXX0=