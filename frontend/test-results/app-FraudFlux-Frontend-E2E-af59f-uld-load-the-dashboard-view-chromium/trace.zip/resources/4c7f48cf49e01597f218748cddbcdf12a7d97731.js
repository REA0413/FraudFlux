import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MerchantSettings.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/MerchantSettings.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
export default function MerchantSettings() {
	_s();
	const { user } = useAuth();
	const [threshold, setThreshold] = useState(85);
	const [loading, setLoading] = useState(false);
	const [message, setMessage] = useState(null);
	// Load current threshold from Supabase / Backend on load
	useEffect(() => {
		const fetchThreshold = async () => {
			try {
				const res = await fetch(`http://localhost:8000/v1/settings/thresholds/${user.id}`);
				if (res.ok) {
					const data = await res.json();
					if (data?.auto_decline_threshold) {
						setThreshold(data.auto_decline_threshold);
					}
				}
			} catch (err) {
				console.error("Failed to load merchant settings:", err);
			}
		};
		if (user?.id) {
			fetchThreshold();
		}
	}, [user]);
	// Unified Save Handler (Runs ONLY on "Save Settings" click)
	const handleSave = async () => {
		setLoading(true);
		setMessage(null);
		try {
			const res = await fetch("http://localhost:8000/v1/settings/thresholds", {
				method: "PUT",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					merchant_id: user.id,
					auto_decline_threshold: Number(threshold)
				})
			});
			if (res.ok) {
				setMessage({
					type: "success",
					text: "Threshold updated successfully!"
				});
			} else {
				setMessage({
					type: "error",
					text: "Failed to update threshold."
				});
			}
		} catch (err) {
			setMessage({
				type: "error",
				text: "Backend server unavailable."
			});
		} finally {
			setLoading(false);
		}
	};
	const selectPreset = (val) => {
		setThreshold(val);
		setMessage(null);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-6 max-w-2xl mx-auto bg-white dark:bg-slate-800 rounded-lg shadow-md mt-8",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold mb-2 text-slate-800 dark:text-white",
				children: "Fraud Risk Thresholds"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-600 dark:text-slate-300 mb-6",
				children: "Configure the risk sensitivity for automatic transaction declines."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("div", {
				className: `p-3 rounded mb-4 text-sm ${message.type === "success" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`,
				children: message.text
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: "block font-semibold mb-2 text-slate-700 dark:text-slate-200",
					children: "Quick Presets"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => selectPreset(70),
							className: `p-3 border rounded-lg text-left transition ${threshold === 70 ? "border-purple-600 bg-purple-50 dark:bg-slate-700" : "border-slate-300"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "font-bold text-sm",
								children: "Maximise Protection"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-slate-500",
								children: "Threshold: 70%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => selectPreset(85),
							className: `p-3 border rounded-lg text-left transition ${threshold === 85 ? "border-purple-600 bg-purple-50 dark:bg-slate-700" : "border-slate-300"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "font-bold text-sm",
								children: "Balanced"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-slate-500",
								children: "Threshold: 85% (Default)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => selectPreset(95),
							className: `p-3 border rounded-lg text-left transition ${threshold === 95 ? "border-purple-600 bg-purple-50 dark:bg-slate-700" : "border-slate-300"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "font-bold text-sm",
								children: "Maximise Revenue"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-slate-500",
								children: "Threshold: 95%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center mb-2",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "font-semibold text-slate-700 dark:text-slate-200",
							children: "Custom Threshold Slider"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-lg font-bold text-purple-600",
							children: [threshold, "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "range",
						min: "1",
						max: "99",
						value: threshold,
						onChange: (e) => {
							setThreshold(Number(e.target.value));
							setMessage(null);
						},
						className: "w-full accent-purple-600 cursor-pointer"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between text-xs text-slate-400 mt-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "1% (Strict)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "99% (Permissive)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				onClick: handleSave,
				disabled: loading,
				className: "w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition disabled:opacity-50",
				children: loading ? "Saving Changes..." : "Save Settings"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_s(MerchantSettings, "8TBL7N9/gO5kI7EvqU94R4ixAbY=", false, function() {
	return [useAuth];
});
_c = MerchantSettings;
var _c;
$RefreshReg$(_c, "MerchantSettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/MerchantSettings.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/MerchantSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/MerchantSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/MerchantSettings.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsbUJBQW1COztDQUN6QyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7O0NBRzNDLGdCQUFnQjtFQUNkLE1BQU0saUJBQWlCLFlBQVk7R0FDakMsSUFBSTtJQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sZ0RBQWdELEtBQUssSUFBSTtJQUNqRixJQUFJLElBQUksSUFBSTtLQUNWLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztLQUM1QixJQUFJLE1BQU0sd0JBQXdCO01BQ2hDLGFBQWEsS0FBSyxzQkFBc0I7S0FDMUM7SUFDRjtHQUNGLFNBQVMsS0FBSztJQUNaLFFBQVEsTUFBTSxxQ0FBcUMsR0FBRztHQUN4RDtFQUNGO0VBRUEsSUFBSSxNQUFNLElBQUk7R0FDWixlQUFlO0VBQ2pCO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQzs7Q0FHVCxNQUFNLGFBQWEsWUFBWTtFQUM3QixXQUFXLElBQUk7RUFDZixXQUFXLElBQUk7RUFFZixJQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sTUFBTSxnREFBZ0Q7SUFDdEUsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVO0tBQ25CLGFBQWEsS0FBSztLQUNsQix3QkFBd0IsT0FBTyxTQUFTO0lBQzFDLENBQUM7R0FDSCxDQUFDO0dBRUQsSUFBSSxJQUFJLElBQUk7SUFDVixXQUFXO0tBQUUsTUFBTTtLQUFXLE1BQU07SUFBa0MsQ0FBQztHQUN6RSxPQUFPO0lBQ0wsV0FBVztLQUFFLE1BQU07S0FBUyxNQUFNO0lBQThCLENBQUM7R0FDbkU7RUFDRixTQUFTLEtBQUs7R0FDWixXQUFXO0lBQUUsTUFBTTtJQUFTLE1BQU07R0FBOEIsQ0FBQztFQUNuRSxVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxNQUFNLGdCQUFnQixRQUFRO0VBQzVCLGFBQWEsR0FBRztFQUNoQixXQUFXLElBQUk7Q0FDakI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF5RDtHQUVuRTs7Ozs7R0FDSix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUEwQztHQUVwRDs7Ozs7R0FFRixXQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLDRCQUNkLFFBQVEsU0FBUyxZQUFZLGdDQUFnQztjQUU1RCxRQUFRO0dBQ047Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQThEO0lBRXhFOzs7O2NBQ1Asd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsRUFBRTtPQUM5QixXQUFXLDhDQUNULGNBQWMsS0FBSyxxREFBcUQ7aUJBSDVFLENBTUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQW9CO09BQXdCOzs7O2lCQUMzRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBeUI7T0FBbUI7Ozs7ZUFDckQ7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsRUFBRTtPQUM5QixXQUFXLDhDQUNULGNBQWMsS0FBSyxxREFBcUQ7aUJBSDVFLENBTUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQW9CO09BQWE7Ozs7aUJBQ2hELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF5QjtPQUE2Qjs7OztlQUMvRDs7Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxFQUFFO09BQzlCLFdBQVcsOENBQ1QsY0FBYyxLQUFLLHFEQUFxRDtpQkFINUUsQ0FNRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBb0I7T0FBcUI7Ozs7aUJBQ3hELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF5QjtPQUFtQjs7OztlQUNyRDs7Ozs7O0tBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFtRDtNQUU3RDs7OztnQkFDUCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FBcUQsV0FBVSxHQUFPOzs7OztjQUNuRTs7Ozs7O0tBQ0wsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxLQUFJO01BQ0osS0FBSTtNQUNKLE9BQU87TUFDUCxXQUFXLE1BQU07T0FDZixhQUFhLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztPQUNuQyxXQUFXLElBQUk7TUFDakI7TUFDQSxXQUFVO0tBQ1g7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7Z0JBQ3ZCLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7Y0FDekI7Ozs7OztJQUNGOzs7Ozs7R0FFTCx3QkFBQyxVQUFEO0lBQ0UsU0FBUztJQUNULFVBQVU7SUFDVixXQUFVO2NBRVQsVUFBVSxzQkFBc0I7R0FDM0I7Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1lcmNoYW50U2V0dGluZ3MuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1lcmNoYW50U2V0dGluZ3MoKSB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW3RocmVzaG9sZCwgc2V0VGhyZXNob2xkXSA9IHVzZVN0YXRlKDg1KTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIC8vIExvYWQgY3VycmVudCB0aHJlc2hvbGQgZnJvbSBTdXBhYmFzZSAvIEJhY2tlbmQgb24gbG9hZFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFRocmVzaG9sZCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgaHR0cDovL2xvY2FsaG9zdDo4MDAwL3YxL3NldHRpbmdzL3RocmVzaG9sZHMvJHt1c2VyLmlkfWApO1xyXG4gICAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgaWYgKGRhdGE/LmF1dG9fZGVjbGluZV90aHJlc2hvbGQpIHtcclxuICAgICAgICAgICAgc2V0VGhyZXNob2xkKGRhdGEuYXV0b19kZWNsaW5lX3RocmVzaG9sZCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgbWVyY2hhbnQgc2V0dGluZ3M6XCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgaWYgKHVzZXI/LmlkKSB7XHJcbiAgICAgIGZldGNoVGhyZXNob2xkKCk7XHJcbiAgICB9XHJcbiAgfSwgW3VzZXJdKTtcclxuXHJcbiAgLy8gVW5pZmllZCBTYXZlIEhhbmRsZXIgKFJ1bnMgT05MWSBvbiBcIlNhdmUgU2V0dGluZ3NcIiBjbGljaylcclxuICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldE1lc3NhZ2UobnVsbCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6ODAwMC92MS9zZXR0aW5ncy90aHJlc2hvbGRzJywge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgbWVyY2hhbnRfaWQ6IHVzZXIuaWQsXHJcbiAgICAgICAgICBhdXRvX2RlY2xpbmVfdGhyZXNob2xkOiBOdW1iZXIodGhyZXNob2xkKVxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICBzZXRNZXNzYWdlKHsgdHlwZTogJ3N1Y2Nlc3MnLCB0ZXh0OiAnVGhyZXNob2xkIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IScgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0TWVzc2FnZSh7IHR5cGU6ICdlcnJvcicsIHRleHQ6ICdGYWlsZWQgdG8gdXBkYXRlIHRocmVzaG9sZC4nIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0TWVzc2FnZSh7IHR5cGU6ICdlcnJvcicsIHRleHQ6ICdCYWNrZW5kIHNlcnZlciB1bmF2YWlsYWJsZS4nIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2VsZWN0UHJlc2V0ID0gKHZhbCkgPT4ge1xyXG4gICAgc2V0VGhyZXNob2xkKHZhbCk7XHJcbiAgICBzZXRNZXNzYWdlKG51bGwpOyAvLyBDbGVhciBwcmV2aW91cyBhbGVydCBzbyB1c2VyIGtub3dzIGNoYW5nZXMgYXJlIHN0YWdlZFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBtYXgtdy0yeGwgbXgtYXV0byBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHNoYWRvdy1tZCBtdC04XCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItMiB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICBGcmF1ZCBSaXNrIFRocmVzaG9sZHNcclxuICAgICAgPC9oMj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi02XCI+XHJcbiAgICAgICAgQ29uZmlndXJlIHRoZSByaXNrIHNlbnNpdGl2aXR5IGZvciBhdXRvbWF0aWMgdHJhbnNhY3Rpb24gZGVjbGluZXMuXHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIHttZXNzYWdlICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMyByb3VuZGVkIG1iLTQgdGV4dC1zbSAke1xyXG4gICAgICAgICAgbWVzc2FnZS50eXBlID09PSAnc3VjY2VzcycgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCdcclxuICAgICAgICB9YH0+XHJcbiAgICAgICAgICB7bWVzc2FnZS50ZXh0fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIFByZXNldCBTdHJhdGVneSBCdXR0b25zICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0yIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgIFF1aWNrIFByZXNldHNcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxlY3RQcmVzZXQoNzApfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMgYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC1sZWZ0IHRyYW5zaXRpb24gJHtcclxuICAgICAgICAgICAgICB0aHJlc2hvbGQgPT09IDcwID8gJ2JvcmRlci1wdXJwbGUtNjAwIGJnLXB1cnBsZS01MCBkYXJrOmJnLXNsYXRlLTcwMCcgOiAnYm9yZGVyLXNsYXRlLTMwMCdcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc21cIj5NYXhpbWlzZSBQcm90ZWN0aW9uPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlRocmVzaG9sZDogNzAlPC9kaXY+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNlbGVjdFByZXNldCg4NSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyBib3JkZXIgcm91bmRlZC1sZyB0ZXh0LWxlZnQgdHJhbnNpdGlvbiAke1xyXG4gICAgICAgICAgICAgIHRocmVzaG9sZCA9PT0gODUgPyAnYm9yZGVyLXB1cnBsZS02MDAgYmctcHVycGxlLTUwIGRhcms6Ymctc2xhdGUtNzAwJyA6ICdib3JkZXItc2xhdGUtMzAwJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbVwiPkJhbGFuY2VkPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlRocmVzaG9sZDogODUlIChEZWZhdWx0KTwvZGl2PlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxlY3RQcmVzZXQoOTUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMgYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC1sZWZ0IHRyYW5zaXRpb24gJHtcclxuICAgICAgICAgICAgICB0aHJlc2hvbGQgPT09IDk1ID8gJ2JvcmRlci1wdXJwbGUtNjAwIGJnLXB1cnBsZS01MCBkYXJrOmJnLXNsYXRlLTcwMCcgOiAnYm9yZGVyLXNsYXRlLTMwMCdcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc21cIj5NYXhpbWlzZSBSZXZlbnVlPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlRocmVzaG9sZDogOTUlPC9kaXY+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ3VzdG9tIFNsaWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItMlwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICBDdXN0b20gVGhyZXNob2xkIFNsaWRlclxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcHVycGxlLTYwMFwiPnt0aHJlc2hvbGR9JTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXHJcbiAgICAgICAgICBtaW49XCIxXCJcclxuICAgICAgICAgIG1heD1cIjk5XCJcclxuICAgICAgICAgIHZhbHVlPXt0aHJlc2hvbGR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgc2V0VGhyZXNob2xkKE51bWJlcihlLnRhcmdldC52YWx1ZSkpO1xyXG4gICAgICAgICAgICBzZXRNZXNzYWdlKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtcHVycGxlLTYwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgPHNwYW4+MSUgKFN0cmljdCk8L3NwYW4+XHJcbiAgICAgICAgICA8c3Bhbj45OSUgKFBlcm1pc3NpdmUpPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxyXG4gICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIGJnLXB1cnBsZS02MDAgaG92ZXI6YmctcHVycGxlLTcwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgPlxyXG4gICAgICAgIHtsb2FkaW5nID8gJ1NhdmluZyBDaGFuZ2VzLi4uJyA6ICdTYXZlIFNldHRpbmdzJ31cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19