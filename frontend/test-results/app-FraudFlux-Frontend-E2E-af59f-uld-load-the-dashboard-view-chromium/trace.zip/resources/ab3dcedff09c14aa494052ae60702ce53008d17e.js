import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/LandingPage.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=51adfdae";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=51adfdae";
export default function LandingPage({ onNavigate }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#1a103c] text-white flex flex-col font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "flex items-center justify-between px-8 py-5 border-b border-white/10 max-w-7xl mx-auto w-full",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-full bg-[#6750A4] flex items-center justify-center font-bold text-lg text-white",
						children: "FF"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 10,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xl font-bold tracking-tight",
						children: "FraudFlux"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-4",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onNavigate("login"),
						className: "text-sm font-medium text-gray-300 hover:text-white px-4 py-2 transition-colors",
						children: "Sign In"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onNavigate("register"),
						className: "text-sm font-medium bg-[#6750A4] hover:bg-[#533f85] text-white px-5 py-2.5 rounded-lg shadow-lg transition-all",
						children: "Get Started"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 flex flex-col items-center justify-center text-center px-6 max-w-4xl mx-auto my-12",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs uppercase tracking-widest bg-[#6750A4]/30 text-[#e0d7f5] px-4 py-1.5 rounded-full font-semibold mb-6 border border-[#6750A4]/40",
						children: "AI-Powered Risk Intelligence"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl text-gray-200 sm:text-6xl font-extrabold tracking-tight leading-tight mb-6",
						children: "Real-Time Transaction Fraud Detection"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-lg text-gray-300 mb-10 max-w-2xl leading-relaxed",
						children: "FraudFlux leverages Machine Learning and real-time database streaming to identify high-risk payments, mitigate financial fraud, and empower operations desk analysts instantly."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row gap-4 w-full sm:w-auto",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("login"),
							className: "bg-[#6750A4] hover:bg-[#533f85] text-white font-medium px-8 py-3.5 rounded-xl text-base shadow-xl transition-all",
							children: "Access Operations Console"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 text-left w-full",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "⚡ Instant ML Scoring"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 58,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Evaluate transaction amounts, zip codes, and population density using automated XGBoost predictions."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "📊 Live Dashboard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Track key merchant transaction metrics, risk distributions, and live flag statuses effortlessly."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "🔒 Supabase Backed"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Enterprise-grade secure row-level security and authentication provided by Supabase."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "py-6 border-t border-white/10 text-center text-xs text-gray-500",
				children: "© 2026 FraudFlux Academic Project. Built with React, Fast API & Supabase."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = LandingPage;
var _c;
$RefreshReg$(_c, "LandingPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/LandingPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsZUFBZSxTQUFTLFlBQVksRUFBRSxjQUFjO0NBQ2xELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWtHO0tBRTVHOzs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1DO0tBQWU7Ozs7YUFDL0Q7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFdBQVcsT0FBTztNQUNqQyxXQUFVO2dCQUNYO0tBRU87Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxXQUFXLFVBQVU7TUFDcEMsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTBJO0tBRXBKOzs7OztLQUVOLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFzRjtLQUVoRzs7Ozs7S0FFSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBd0Q7S0FFbEU7Ozs7O0tBRUgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsV0FBVyxPQUFPO09BQ2pDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdDO1FBQXdCOzs7O2tCQUM5RSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBd0I7UUFBdUc7Ozs7Z0JBQ3pJOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF3QztRQUFxQjs7OztrQkFDM0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXdCO1FBQW1HOzs7O2dCQUNySTs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBd0M7UUFBc0I7Ozs7a0JBQzVFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF3QjtRQUFzRjs7OztnQkFDeEg7Ozs7OztNQUNGOzs7Ozs7SUFDRDs7Ozs7O0dBR04sd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBa0U7R0FFNUU7Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhbmRpbmdQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGFuZGluZ1BhZ2UoeyBvbk5hdmlnYXRlIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyMxYTEwM2NdIHRleHQtd2hpdGUgZmxleCBmbGV4LWNvbCBmb250LXNhbnNcIj5cclxuICAgICAgXHJcbiAgICAgIHsvKiBUb3AgTmF2aWdhdGlvbiBCYXIgKi99XHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTggcHktNSBib3JkZXItYiBib3JkZXItd2hpdGUvMTAgbWF4LXctN3hsIG14LWF1dG8gdy1mdWxsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctWyM2NzUwQTRdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgRkZcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5GcmF1ZEZsdXg8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00XCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2xvZ2luJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTMwMCBob3Zlcjp0ZXh0LXdoaXRlIHB4LTQgcHktMiB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFNpZ24gSW5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdyZWdpc3RlcicpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIGJnLVsjNjc1MEE0XSBob3ZlcjpiZy1bIzUzM2Y4NV0gdGV4dC13aGl0ZSBweC01IHB5LTIuNSByb3VuZGVkLWxnIHNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEdldCBTdGFydGVkXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uYXY+XHJcblxyXG4gICAgICB7LyogSGVybyBTZWN0aW9uICovfVxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcHgtNiBtYXgtdy00eGwgbXgtYXV0byBteS0xMlwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBiZy1bIzY3NTBBNF0vMzAgdGV4dC1bI2UwZDdmNV0gcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIGZvbnQtc2VtaWJvbGQgbWItNiBib3JkZXIgYm9yZGVyLVsjNjc1MEE0XS80MFwiPlxyXG4gICAgICAgICAgQUktUG93ZXJlZCBSaXNrIEludGVsbGlnZW5jZVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICBcclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgdGV4dC1ncmF5LTIwMCBzbTp0ZXh0LTZ4bCBmb250LWV4dHJhYm9sZCB0cmFja2luZy10aWdodCBsZWFkaW5nLXRpZ2h0IG1iLTZcIj5cclxuICAgICAgICAgIFJlYWwtVGltZSBUcmFuc2FjdGlvbiBGcmF1ZCBEZXRlY3Rpb25cclxuICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIHRleHQtZ3JheS0zMDAgbWItMTAgbWF4LXctMnhsIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgRnJhdWRGbHV4IGxldmVyYWdlcyBNYWNoaW5lIExlYXJuaW5nIGFuZCByZWFsLXRpbWUgZGF0YWJhc2Ugc3RyZWFtaW5nIHRvIGlkZW50aWZ5IGhpZ2gtcmlzayBwYXltZW50cywgbWl0aWdhdGUgZmluYW5jaWFsIGZyYXVkLCBhbmQgZW1wb3dlciBvcGVyYXRpb25zIGRlc2sgYW5hbHlzdHMgaW5zdGFudGx5LlxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC00IHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnbG9naW4nKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyM2NzUwQTRdIGhvdmVyOmJnLVsjNTMzZjg1XSB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHB4LTggcHktMy41IHJvdW5kZWQteGwgdGV4dC1iYXNlIHNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEFjY2VzcyBPcGVyYXRpb25zIENvbnNvbGVcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRmVhdHVyZSBIaWdobGlnaHRzIEdyaWQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IG10LTE2IHRleHQtbGVmdCB3LWZ1bGxcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvNSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHAtNiByb3VuZGVkLTJ4bCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyBtYi0yIHRleHQtWyNlMGQ3ZjVdXCI+4pqhIEluc3RhbnQgTUwgU2NvcmluZzwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPkV2YWx1YXRlIHRyYW5zYWN0aW9uIGFtb3VudHMsIHppcCBjb2RlcywgYW5kIHBvcHVsYXRpb24gZGVuc2l0eSB1c2luZyBhdXRvbWF0ZWQgWEdCb29zdCBwcmVkaWN0aW9ucy48L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvNSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHAtNiByb3VuZGVkLTJ4bCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyBtYi0yIHRleHQtWyNlMGQ3ZjVdXCI+8J+TiiBMaXZlIERhc2hib2FyZDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPlRyYWNrIGtleSBtZXJjaGFudCB0cmFuc2FjdGlvbiBtZXRyaWNzLCByaXNrIGRpc3RyaWJ1dGlvbnMsIGFuZCBsaXZlIGZsYWcgc3RhdHVzZXMgZWZmb3J0bGVzc2x5LjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZS81IGJvcmRlciBib3JkZXItd2hpdGUvMTAgcC02IHJvdW5kZWQtMnhsIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIG1iLTIgdGV4dC1bI2UwZDdmNV1cIj7wn5SSIFN1cGFiYXNlIEJhY2tlZDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPkVudGVycHJpc2UtZ3JhZGUgc2VjdXJlIHJvdy1sZXZlbCBzZWN1cml0eSBhbmQgYXV0aGVudGljYXRpb24gcHJvdmlkZWQgYnkgU3VwYWJhc2UuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgIHsvKiBGb290ZXIgKi99XHJcbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwicHktNiBib3JkZXItdCBib3JkZXItd2hpdGUvMTAgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgwqkgMjAyNiBGcmF1ZEZsdXggQWNhZGVtaWMgUHJvamVjdC4gQnVpbHQgd2l0aCBSZWFjdCwgRmFzdCBBUEkgJiBTdXBhYmFzZS5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19