const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const StrictMode = __vite__cjsImport0_react["StrictMode"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=4f441ac6";
import "/src/index.css";
import App from "/src/App.jsx";
import { AuthProvider } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/main.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 10,
	columnNumber: 6
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 9,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTztBQUNQLE9BQU8sU0FBUztBQUNoQixTQUFTLG9CQUFvQjs7O0FBRTdCLFdBQVcsU0FBUyxlQUFlLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FDMUMsd0JBQUMsWUFBRCxZQUNFLHdCQUFDLGNBQUQsWUFDQyx3QkFBQyxLQUFELENBQU07Ozs7U0FDTzs7OztTQUNKOzs7O1FBQ2QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC5qc3gnXG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tICcuL2NvbnRleHQvQXV0aENvbnRleHQuanN4J1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpLnJlbmRlcihcbiAgPFN0cmljdE1vZGU+XG4gICAgPEF1dGhQcm92aWRlcj5cbiAgICAgPEFwcCAvPlxuICAgIDwvQXV0aFByb3ZpZGVyPlxuICA8L1N0cmljdE1vZGU+LFxuKVxuIl19