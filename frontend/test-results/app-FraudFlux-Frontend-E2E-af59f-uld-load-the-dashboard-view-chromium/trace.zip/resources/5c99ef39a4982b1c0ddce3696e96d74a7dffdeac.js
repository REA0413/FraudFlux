import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Register.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];// src/Register.jsx
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Register.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
export default function Register({ onSwitchToLogin }) {
	_s();
	const [merchantName, setMerchantName] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState(null);
	const [success, setSuccess] = useState(false);
	const [loading, setLoading] = useState(false);
	const { register } = useAuth();
	const handleSubmit = async (e) => {
		e.preventDefault();
		setError(null);
		setLoading(true);
		try {
			await register(email, password, merchantName);
			setSuccess(true);
		} catch (err) {
			setError(err.message || "Failed to create account.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen items-center justify-center bg-[#1a103c] text-white p-4 font-sans",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-md rounded-xl bg-white p-8 text-slate-900 shadow-2xl",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-2xl font-bold text-[#1a103c] mb-1",
					children: "FraudFlux"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-semibold mb-6 text-gray-700",
					children: "Create Merchant Account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("div", {
					className: "mb-4 rounded-md bg-red-100 p-3 text-sm text-red-700",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this),
				success ? /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-md bg-green-50 p-4 text-green-800 text-center space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-semibold text-base",
							children: "Thank you! Account Created Successfully! 🎉"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-gray-600",
							children: "Please check your inbox and click on the verification link to start working with FraudFlux."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: onSwitchToLogin,
							className: "mt-2 w-full rounded-md bg-[#5842be] py-2 text-sm font-medium text-white hover:bg-[#4833a8]",
							children: "Go to Sign In"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-gray-700 mb-1",
							children: "Business / Merchant Name"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							required: true,
							className: "w-full rounded-md border border-gray-300 p-2.5 text-sm focus:border-indigo-500 focus:outline-none text-black",
							placeholder: "Acme Payments Ltd",
							value: merchantName,
							onChange: (e) => setMerchantName(e.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-gray-700 mb-1",
							children: "Email Address"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							required: true,
							className: "w-full rounded-md border border-gray-300 p-2.5 text-sm focus:border-indigo-500 focus:outline-none text-black",
							placeholder: "admin@merchant.com",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-gray-700 mb-1",
							children: "Password"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							required: true,
							minLength: 6,
							className: "w-full rounded-md border border-gray-300 p-2.5 text-sm focus:border-indigo-500 focus:outline-none text-black",
							placeholder: "At least 6 characters",
							value: password,
							onChange: (e) => setPassword(e.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: loading,
							className: "w-full rounded-md bg-[#5842be] py-2.5 text-sm font-medium text-white hover:bg-[#4833a8] transition-colors disabled:opacity-50",
							children: loading ? "Creating Account..." : "Register Merchant"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-center text-xs text-gray-500 mt-4",
							children: [
								"Already have an account?",
								" ",
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: onSwitchToLogin,
									className: "text-[#5842be] font-semibold hover:underline",
									children: "Sign In"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s(Register, "U+WjXdoMWl4x8ARseOeCtpKhlyk=", false, function() {
	return [useAuth];
});
_c = Register;
var _c;
$RefreshReg$(_c, "Register");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Register.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Register.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Register.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Register.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUNBLE9BQU8sU0FBUyxnQkFBZ0I7QUFDaEMsU0FBUyxlQUFlOzs7O0FBRXhCLGVBQWUsU0FBUyxTQUFTLEVBQUUsbUJBQW1COztDQUNwRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLE1BQU0sRUFBRSxhQUFhLFFBQVE7Q0FFN0IsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFDakIsU0FBUyxJQUFJO0VBQ2IsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNGLE1BQU0sU0FBUyxPQUFPLFVBQVUsWUFBWTtHQUM1QyxXQUFXLElBQUk7RUFDakIsU0FBUyxLQUFLO0dBQ1osU0FBUyxJQUFJLFdBQVcsMkJBQTJCO0VBQ3JELFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUM7SUFBYTs7Ozs7SUFDcEUsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBMkM7SUFBMkI7Ozs7O0lBRW5GLFNBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtJQUNFOzs7OztJQUdOLFVBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEwQjtNQUE4Qzs7Ozs7TUFDckYsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXdCO01BRWxDOzs7OztNQUNILHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFDWDtNQUVPOzs7OztLQUNMOzs7OztlQUVMLHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQWMsV0FBVTtlQUF4QztNQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBK0M7TUFBK0I7Ozs7Z0JBQy9GLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0w7T0FDQSxXQUFVO09BQ1YsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO01BQ2hEOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUErQztNQUFvQjs7OztnQkFDcEYsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTDtPQUNBLFdBQVU7T0FDVixhQUFZO09BQ1osT0FBTztPQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO01BQ3pDOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUErQztNQUFlOzs7O2dCQUMvRSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMO09BQ0EsV0FBVztPQUNYLFdBQVU7T0FDVixhQUFZO09BQ1osT0FBTztPQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO01BQzVDOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVO09BQ1YsV0FBVTtpQkFFVCxVQUFVLHdCQUF3QjtNQUM3Qjs7Ozs7TUFFUix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFzRDtRQUMzQjtRQUN6Qix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFNBQVM7U0FDVCxXQUFVO21CQUNYO1FBRU87Ozs7O09BQ1A7Ozs7OztLQUNDOzs7Ozs7R0FFTDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVnaXN0ZXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9SZWdpc3Rlci5qc3hcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlZ2lzdGVyKHsgb25Td2l0Y2hUb0xvZ2luIH0pIHtcclxuICBjb25zdCBbbWVyY2hhbnROYW1lLCBzZXRNZXJjaGFudE5hbWVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3N1Y2Nlc3MsIHNldFN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgeyByZWdpc3RlciB9ID0gdXNlQXV0aCgpO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHJlZ2lzdGVyKGVtYWlsLCBwYXNzd29yZCwgbWVyY2hhbnROYW1lKTtcclxuICAgICAgc2V0U3VjY2Vzcyh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGNyZWF0ZSBhY2NvdW50LicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjMWExMDNjXSB0ZXh0LXdoaXRlIHAtNCBmb250LXNhbnNcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgcm91bmRlZC14bCBiZy13aGl0ZSBwLTggdGV4dC1zbGF0ZS05MDAgc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1bIzFhMTAzY10gbWItMVwiPkZyYXVkRmx1eDwvaDE+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi02IHRleHQtZ3JheS03MDBcIj5DcmVhdGUgTWVyY2hhbnQgQWNjb3VudDwvaDI+XHJcblxyXG4gICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcm91bmRlZC1tZCBiZy1yZWQtMTAwIHAtMyB0ZXh0LXNtIHRleHQtcmVkLTcwMFwiPlxyXG4gICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7c3VjY2VzcyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBiZy1ncmVlbi01MCBwLTQgdGV4dC1ncmVlbi04MDAgdGV4dC1jZW50ZXIgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1iYXNlXCI+VGhhbmsgeW91ISBBY2NvdW50IENyZWF0ZWQgU3VjY2Vzc2Z1bGx5ISDwn46JPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICBQbGVhc2UgY2hlY2sgeW91ciBpbmJveCBhbmQgY2xpY2sgb24gdGhlIHZlcmlmaWNhdGlvbiBsaW5rIHRvIHN0YXJ0IHdvcmtpbmcgd2l0aCBGcmF1ZEZsdXguXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uU3dpdGNoVG9Mb2dpbn1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHctZnVsbCByb3VuZGVkLW1kIGJnLVsjNTg0MmJlXSBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBob3ZlcjpiZy1bIzQ4MzNhOF1cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgR28gdG8gU2lnbiBJblxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5CdXNpbmVzcyAvIE1lcmNoYW50IE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcC0yLjUgdGV4dC1zbSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgdGV4dC1ibGFja1wiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFjbWUgUGF5bWVudHMgTHRkXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXJjaGFudE5hbWV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1lcmNoYW50TmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkVtYWlsIEFkZHJlc3M8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHAtMi41IHRleHQtc20gZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgZm9jdXM6b3V0bGluZS1ub25lIHRleHQtYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJhZG1pbkBtZXJjaGFudC5jb21cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgbWluTGVuZ3RoPXs2fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTIuNSB0ZXh0LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOm91dGxpbmUtbm9uZSB0ZXh0LWJsYWNrXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXQgbGVhc3QgNiBjaGFyYWN0ZXJzXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJnLVsjNTg0MmJlXSBweS0yLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGhvdmVyOmJnLVsjNDgzM2E4XSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nID8gJ0NyZWF0aW5nIEFjY291bnQuLi4nIDogJ1JlZ2lzdGVyIE1lcmNoYW50J31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtNFwiPlxyXG4gICAgICAgICAgICAgIEFscmVhZHkgaGF2ZSBhbiBhY2NvdW50P3snICd9XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblN3aXRjaFRvTG9naW59XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsjNTg0MmJlXSBmb250LXNlbWlib2xkIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgU2lnbiBJblxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19