import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CheckoutSimulator.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_SUPABASE_ANON_KEY": "sb_publishable_iXnBnK_nFS7GrBAhKQzJJA_l1zwJNcU", "VITE_SUPABASE_URL": "https://ofdwlagawlawrfqbgbbq.supabase.co"};const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/CheckoutSimulator.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
const SUPABASE_URL = "https://ofdwlagawlawrfqbgbbq.supabase.co";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
export default function CheckoutSimulator() {
	_s();
	// Extract user and session token from AuthContext
	const auth = useAuth();
	const userEmail = auth?.user?.email || null;
	const userToken = auth?.session?.access_token || auth?.token || null;
	// Authenticated Merchant State
	const [merchantId, setMerchantId] = useState("");
	const [merchantName, setMerchantName] = useState("Fetching merchant profile...");
	// Customer Form State
	const [amount, setAmount] = useState("25.00");
	const [cardNumber, setCardNumber] = useState("4532 8901 2345 8892");
	const [expiryDate, setExpiryDate] = useState("12/28");
	const [cvv, setCvv] = useState("381");
	const [email, setEmail] = useState("john.doe@gmail.com");
	const [issuerCountry, setIssuerCountry] = useState("US");
	const [billingCountry, setBillingCountry] = useState("US");
	const [currency] = useState("EUR");
	// Advanced ML Parameter States
	const [showAdvanced, setShowAdvanced] = useState(false);
	const [zipCode, setZipCode] = useState("90210");
	const [cityPop, setCityPop] = useState("50000");
	// Evaluation State
	const [loading, setLoading] = useState(false);
	const [result, setResult] = useState(null);
	const [latency, setLatency] = useState(null);
	const [lastPayload, setLastPayload] = useState(null);
	const [error, setError] = useState(null);
	const MOCK_BIN_LOOKUP = {
		"453289": "Chase Bank",
		"541299": "Barclays Bank"
	};
	useEffect(() => {
		const fetchMerchantProfile = async () => {
			// 1. Handle unauthenticated state
			if (!userEmail) {
				console.warn("CheckoutSimulator: No user email available from AuthContext.");
				setMerchantId("");
				setMerchantName("Unauthenticated User");
				return;
			}
			try {
				const headers = {
					"Content-Type": "application/json",
					...SUPABASE_ANON_KEY ? { apikey: SUPABASE_ANON_KEY } : {},
					...userToken ? { Authorization: `Bearer ${userToken}` } : {}
				};
				const url = `${SUPABASE_URL}/rest/v1/merchants?email=eq.${encodeURIComponent(userEmail)}&select=id,merchant_name`;
				console.log(`Fetching merchant profile for: "${userEmail}" (RLS Token Present: ${!!userToken})`);
				const response = await fetch(url, { headers });
				if (response.ok) {
					const data = await response.json();
					console.log("Supabase Merchant Lookup Response:", data);
					if (Array.isArray(data) && data.length > 0) {
						setMerchantId(data[0].id || "");
						setMerchantName(data[0].merchant_name || "Unnamed Merchant");
						return;
					}
					setMerchantId("");
					setMerchantName(`No merchant record for ${userEmail}`);
				} else {
					console.error("Supabase HTTP Error:", response.status, response.statusText);
					setMerchantId("");
					setMerchantName("Failed to fetch merchant profile");
				}
			} catch (err) {
				console.error("Error fetching merchant profile:", err);
				setMerchantId("");
				setMerchantName("Error loading merchant");
			}
		};
		fetchMerchantProfile();
	}, [userEmail, userToken]);
	// Preset 1: Safe Customer Flow
	const handlePresetSafe = () => {
		setAmount("25.00");
		setCardNumber("4532 8901 2345 8892");
		setExpiryDate("12/28");
		setCvv("381");
		setEmail("john.doe@gmail.com");
		setIssuerCountry("US");
		setBillingCountry("US");
		setZipCode("90210");
		setCityPop("50000");
		setResult(null);
		setError(null);
	};
	// Preset 2: Suspicious Fraudster Flow
	const handlePresetFraud = () => {
		setAmount("1250.00");
		setCardNumber("5412 9918 2039 1049");
		setExpiryDate("04/26");
		setCvv("992");
		setEmail("bot9921@temp-mail.org");
		setIssuerCountry("NG");
		setBillingCountry("US");
		setZipCode("99999");
		setCityPop("1250");
		setResult(null);
		setError(null);
	};
	// Clear Form Inputs
	const handleClear = () => {
		setAmount("");
		setCardNumber("");
		setExpiryDate("");
		setCvv("");
		setEmail("");
		setIssuerCountry("");
		setBillingCountry("");
		setZipCode("90210");
		setCityPop("50000");
		setResult(null);
		setLastPayload(null);
		setLatency(null);
		setError(null);
	};
	// Submit Payment Request
	const handleCheckout = async (e) => {
		e.preventDefault();
		if (!merchantId) {
			setError("Cannot evaluate payment without a valid Merchant ID.");
			return;
		}
		setLoading(true);
		setError(null);
		setResult(null);
		const cardBin = cardNumber.replace(/\D/g, "").slice(0, 6);
		const payload = {
			transaction_id: `tx_live_${Math.floor(Math.random() * 1e5)}`,
			merchant_id: merchantId,
			amount: parseFloat(amount),
			currency,
			issuer_country: issuerCountry,
			billing_country: billingCountry,
			customer_email: email,
			card_bin: cardBin,
			issuer_bank_name: MOCK_BIN_LOOKUP[cardBin] || "Global Issuer Bank",
			timestamp: new Date().toISOString(),
			zip: zipCode ? parseInt(zipCode, 10) : 90210,
			city_pop: cityPop ? parseInt(cityPop, 10) : 5e4
		};
		setLastPayload(payload);
		const startTime = performance.now();
		try {
			const response = await fetch("http://127.0.0.1:8000/v1/charge/evaluate", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload)
			});
			const elapsedMs = Math.round(performance.now() - startTime);
			setLatency(elapsedMs);
			if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
			const data = await response.json();
			setResult(data);
		} catch (err) {
			setError(err.message || "Failed to connect to FraudFlux API.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-2xl font-bold text-[#21005D]",
				children: "Payment Checkout Simulator"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-gray-600 mt-1",
				children: "Simulate e-commerce checkout events and evaluate risk inference latency in real-time."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-[#E8DEF8] p-4 rounded-lg flex items-center justify-between border border-[#6750A4]/20",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-bold text-[#21005D] uppercase tracking-wider",
					children: "LIVE SIMULATION SETUP"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 204,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-x-3 flex items-center",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handlePresetSafe,
							className: "bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium px-3.5 py-2 rounded-md transition-colors",
							children: "Safe Customer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handlePresetFraud,
							className: "bg-red-600 hover:bg-red-700 text-white text-xs font-medium px-3.5 py-2 rounded-md transition-colors",
							children: "Suspicious Fraud"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleClear,
							className: "bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-medium px-3 py-2 rounded-md transition-colors border border-gray-300",
							children: "Clear"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 203,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white p-6 rounded-lg shadow-sm border border-gray-200",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-gray-800 mb-4",
						children: "Checkout Form"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCheckout,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-medium text-gray-600",
								children: [
									"Amount (",
									currency,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								step: "0.01",
								value: amount,
								onChange: (e) => setAmount(e.target.value),
								required: true,
								className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-medium text-gray-600",
								children: "Card Number"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "4532 0000 0000 0000",
								value: cardNumber,
								onChange: (e) => setCardNumber(e.target.value),
								required: true,
								className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-medium text-gray-600",
									children: "Expiry (MM/YY)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "12/28",
									value: expiryDate,
									onChange: (e) => setExpiryDate(e.target.value),
									maxLength: 5,
									required: true,
									className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-medium text-gray-600",
									children: "CVV"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "123",
									value: cvv,
									onChange: (e) => setCvv(e.target.value),
									maxLength: 4,
									required: true,
									className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 275,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 262,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-medium text-gray-600",
								children: "Customer Email"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								placeholder: "customer@example.com",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								required: true,
								className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-medium text-gray-600",
									children: "Billing Country"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: billingCountry,
									onChange: (e) => setBillingCountry(e.target.value.toUpperCase()),
									maxLength: 2,
									required: true,
									className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-medium text-gray-600",
									children: "Issuer Country"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 316,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: issuerCountry,
									onChange: (e) => setIssuerCountry(e.target.value.toUpperCase()),
									maxLength: 2,
									required: true,
									className: "w-full border border-gray-300 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 317,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-medium text-gray-600",
								children: "Merchant Name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: merchantName,
								readOnly: true,
								className: "w-full border border-gray-200 bg-gray-50 text-gray-700 font-medium rounded px-3 py-2 text-sm mt-1 focus:outline-none cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-medium text-gray-600",
								children: "Merchant ID"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: merchantId,
								onChange: (e) => setMerchantId(e.target.value),
								required: true,
								placeholder: "e.g. 677995a6-1e94-440d-9d27-79ae5d7d0e88",
								className: "w-full border border-gray-300 bg-gray-50 rounded px-3 py-2 text-sm mt-1 focus:outline-none focus:border-[#6750A4]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-gray-100",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowAdvanced(!showAdvanced),
									className: "text-xs font-semibold text-[#6750A4] hover:underline flex items-center gap-1 focus:outline-none",
									children: showAdvanced ? "▼ Hide Advanced ML Parameters" : "▶ Show Advanced ML Parameters (ZIP & Population)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 15
								}, this), showAdvanced && /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-4 mt-3 p-3 bg-purple-50/50 rounded-md border border-purple-100",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-medium text-gray-600",
										children: "ZIP Code (5 digits)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 365,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: zipCode,
										onChange: (e) => setZipCode(e.target.value),
										placeholder: "90210",
										className: "w-full border border-gray-300 rounded px-3 py-1.5 text-sm mt-1 focus:outline-none focus:border-[#6750A4] bg-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 366,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 364,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-medium text-gray-600",
										children: "City Population"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 375,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: cityPop,
										onChange: (e) => setCityPop(e.target.value),
										placeholder: "50000",
										className: "w-full border border-gray-300 rounded px-3 py-1.5 text-sm mt-1 focus:outline-none focus:border-[#6750A4] bg-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 353,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: loading || !merchantId,
								className: "w-full bg-[#6750A4] hover:bg-[#533f85] text-white font-medium py-2.5 rounded-md text-sm transition-colors disabled:opacity-50 mt-2",
								children: loading ? "Evaluating Risk via XGBoost..." : "Process Payment & Evaluate Risk"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 388,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col justify-between",
					children: /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-semibold text-gray-800 mb-4",
							children: "Evaluation Result"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 401,
							columnNumber: 13
						}, this),
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-red-50 border border-red-200 text-red-700 p-4 rounded-md text-sm",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Error:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 17
								}, this),
								" ",
								error
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 15
						}, this),
						!result && !error && /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-12 text-gray-400 text-sm",
							children: [
								"Select a setup and click ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "\"Process Payment\"" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 42
								}, this),
								" to run a live evaluation."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 410,
							columnNumber: 15
						}, this),
						result && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: `p-4 rounded-md border text-center ${result.decision === "APPROVE" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-red-50 border-red-200 text-red-800"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-lg font-bold",
										children: result.decision === "APPROVE" ? "✅ PAYMENT APPROVED" : "🚨 PAYMENT DECLINED (FRAUD DETECTED)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 425,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs mt-1",
										children: [
											"Risk Score: ",
											/* @__PURE__ */ _jsxDEV("strong", { children: [Math.round(result.risk_score > 1 ? result.risk_score : result.risk_score * 100), "%"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 429,
												columnNumber: 33
											}, this),
											" | Dynamic Threshold: ",
											/* @__PURE__ */ _jsxDEV("strong", { children: [result.threshold_applied, "%"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 429,
												columnNumber: 154
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 428,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 418,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-gray-50 border border-gray-200 p-3 rounded-md flex items-center justify-between text-sm",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-gray-600 font-medium",
										children: "⚡ Real-Time API Latency:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 435,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `font-bold ${latency < 50 ? "text-emerald-600" : "text-amber-600"}`,
										children: [
											latency,
											" ms ",
											latency < 50 ? "(SLA <50ms Met)" : "(Over 50ms Target)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-[#1E1E1E] text-gray-200 p-3 rounded-md font-mono text-xs overflow-x-auto space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-gray-400 font-sans font-semibold",
											children: "POST Payload sent to /v1/charge/evaluate:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("pre", {
											className: "text-sky-300",
											children: JSON.stringify(lastPayload, null, 2)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-gray-400 font-sans font-semibold pt-2",
											children: "API Response received:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 445,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("pre", {
											className: "text-emerald-300",
											children: JSON.stringify(result, null, 2)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 446,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 442,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 416,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 400,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 399,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 230,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 194,
		columnNumber: 5
	}, this);
}
_s(CheckoutSimulator, "/ILNxgqySOJD+1Wz+wOZKk0w48o=", false, function() {
	return [useAuth];
});
_c = CheckoutSimulator;
var _c;
$RefreshReg$(_c, "CheckoutSimulator");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/CheckoutSimulator.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/CheckoutSimulator.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/CheckoutSimulator.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/CheckoutSimulator.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsZUFBZTs7OztBQUV4QixNQUFNLGVBQWU7QUFDckIsTUFBTSxvQkFBb0IsT0FBTyxLQUFLLElBQUksMEJBQTBCO0FBRXBFLGVBQWUsU0FBUyxvQkFBb0I7OztDQUUxQyxNQUFNLE9BQU8sUUFBUTtDQUNyQixNQUFNLFlBQVksTUFBTSxNQUFNLFNBQVM7Q0FDdkMsTUFBTSxZQUFZLE1BQU0sU0FBUyxnQkFBZ0IsTUFBTSxTQUFTOztDQUdoRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLDhCQUE4Qjs7Q0FHL0UsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLE9BQU87Q0FDNUMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMscUJBQXFCO0NBQ2xFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLE9BQU87Q0FDcEQsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUs7Q0FDcEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLG9CQUFvQjtDQUN2RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJO0NBQ3ZELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsSUFBSTtDQUN6RCxNQUFNLENBQUMsWUFBWSxTQUFTLEtBQUs7O0NBR2pDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLE9BQU87Q0FDOUMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLE9BQU87O0NBRzlDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxJQUFJO0NBQ3pDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLElBQUk7Q0FDbkQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FFdkMsTUFBTSxrQkFBa0I7RUFDdEIsVUFBVTtFQUNWLFVBQVU7Q0FDWjtDQUVBLGdCQUFnQjtFQUNkLE1BQU0sdUJBQXVCLFlBQVk7O0dBRXZDLElBQUksQ0FBQyxXQUFXO0lBQ2QsUUFBUSxLQUFLLDhEQUE4RDtJQUMzRSxjQUFjLEVBQUU7SUFDaEIsZ0JBQWdCLHNCQUFzQjtJQUN0QztHQUNGO0dBRUEsSUFBSTtJQUNGLE1BQU0sVUFBVTtLQUNkLGdCQUFnQjtLQUNoQixHQUFJLG9CQUFvQixFQUFFLFFBQVEsa0JBQWtCLElBQUksQ0FBQztLQUN6RCxHQUFJLFlBQVksRUFBRSxlQUFlLFVBQVUsWUFBWSxJQUFJLENBQUM7SUFDOUQ7SUFFQSxNQUFNLE1BQU0sR0FBRyxhQUFhLDhCQUE4QixtQkFBbUIsU0FBUyxFQUFFO0lBRXhGLFFBQVEsSUFBSSxtQ0FBbUMsVUFBVSx3QkFBd0IsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUUvRixNQUFNLFdBQVcsTUFBTSxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUM7SUFFN0MsSUFBSSxTQUFTLElBQUk7S0FDZixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7S0FDakMsUUFBUSxJQUFJLHNDQUFzQyxJQUFJO0tBRXRELElBQUksTUFBTSxRQUFRLElBQUksS0FBSyxLQUFLLFNBQVMsR0FBRztNQUMxQyxjQUFjLEtBQUssRUFBRSxDQUFDLE1BQU0sRUFBRTtNQUM5QixnQkFBZ0IsS0FBSyxFQUFFLENBQUMsaUJBQWlCLGtCQUFrQjtNQUMzRDtLQUNGO0tBRUEsY0FBYyxFQUFFO0tBQ2hCLGdCQUFnQiwwQkFBMEIsV0FBVztJQUN2RCxPQUFPO0tBQ0wsUUFBUSxNQUFNLHdCQUF3QixTQUFTLFFBQVEsU0FBUyxVQUFVO0tBQzFFLGNBQWMsRUFBRTtLQUNoQixnQkFBZ0Isa0NBQWtDO0lBQ3BEO0dBQ0YsU0FBUyxLQUFLO0lBQ1osUUFBUSxNQUFNLG9DQUFvQyxHQUFHO0lBQ3JELGNBQWMsRUFBRTtJQUNoQixnQkFBZ0Isd0JBQXdCO0dBQzFDO0VBQ0Y7RUFFQSxxQkFBcUI7Q0FDdkIsR0FBRyxDQUFDLFdBQVcsU0FBUyxDQUFDOztDQUd6QixNQUFNLHlCQUF5QjtFQUM3QixVQUFVLE9BQU87RUFDakIsY0FBYyxxQkFBcUI7RUFDbkMsY0FBYyxPQUFPO0VBQ3JCLE9BQU8sS0FBSztFQUNaLFNBQVMsb0JBQW9CO0VBQzdCLGlCQUFpQixJQUFJO0VBQ3JCLGtCQUFrQixJQUFJO0VBQ3RCLFdBQVcsT0FBTztFQUNsQixXQUFXLE9BQU87RUFDbEIsVUFBVSxJQUFJO0VBQ2QsU0FBUyxJQUFJO0NBQ2Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsVUFBVSxTQUFTO0VBQ25CLGNBQWMscUJBQXFCO0VBQ25DLGNBQWMsT0FBTztFQUNyQixPQUFPLEtBQUs7RUFDWixTQUFTLHVCQUF1QjtFQUNoQyxpQkFBaUIsSUFBSTtFQUNyQixrQkFBa0IsSUFBSTtFQUN0QixXQUFXLE9BQU87RUFDbEIsV0FBVyxNQUFNO0VBQ2pCLFVBQVUsSUFBSTtFQUNkLFNBQVMsSUFBSTtDQUNmOztDQUdBLE1BQU0sb0JBQW9CO0VBQ3hCLFVBQVUsRUFBRTtFQUNaLGNBQWMsRUFBRTtFQUNoQixjQUFjLEVBQUU7RUFDaEIsT0FBTyxFQUFFO0VBQ1QsU0FBUyxFQUFFO0VBQ1gsaUJBQWlCLEVBQUU7RUFDbkIsa0JBQWtCLEVBQUU7RUFDcEIsV0FBVyxPQUFPO0VBQ2xCLFdBQVcsT0FBTztFQUNsQixVQUFVLElBQUk7RUFDZCxlQUFlLElBQUk7RUFDbkIsV0FBVyxJQUFJO0VBQ2YsU0FBUyxJQUFJO0NBQ2Y7O0NBR0EsTUFBTSxpQkFBaUIsT0FBTyxNQUFNO0VBQ2xDLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsWUFBWTtHQUNmLFNBQVMsc0RBQXNEO0dBQy9EO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFDZixTQUFTLElBQUk7RUFDYixVQUFVLElBQUk7RUFFZCxNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUM7RUFDeEQsTUFBTSxVQUFVO0dBQ2QsZ0JBQWdCLFdBQVcsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQU07R0FDNUQsYUFBYTtHQUNiLFFBQVEsV0FBVyxNQUFNO0dBQ2Y7R0FDVixnQkFBZ0I7R0FDaEIsaUJBQWlCO0dBQ2pCLGdCQUFnQjtHQUNoQixVQUFVO0dBQ1Ysa0JBQWtCLGdCQUFnQixZQUFZO0dBQzlDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ2xDLEtBQUssVUFBVSxTQUFTLFNBQVMsRUFBRSxJQUFJO0dBQ3ZDLFVBQVUsVUFBVSxTQUFTLFNBQVMsRUFBRSxJQUFJO0VBQzlDO0VBRUEsZUFBZSxPQUFPO0VBQ3RCLE1BQU0sWUFBWSxZQUFZLElBQUk7RUFFbEMsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sNENBQTRDO0lBQ3ZFLFFBQVE7SUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtJQUM5QyxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQzlCLENBQUM7R0FFRCxNQUFNLFlBQVksS0FBSyxNQUFNLFlBQVksSUFBSSxJQUFJLFNBQVM7R0FDMUQsV0FBVyxTQUFTO0dBRXBCLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sY0FBYyxTQUFTLFFBQVE7R0FFakUsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0dBQ2pDLFVBQVUsSUFBSTtFQUNoQixTQUFTLEtBQUs7R0FDWixTQUFTLElBQUksV0FBVyxxQ0FBcUM7RUFDL0QsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsVUFBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQW9DO0dBQThCOzs7O2FBQ2hGLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTZCO0dBRXZDOzs7O1dBQ0c7Ozs7O0dBR1Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQTREO0lBQTJCOzs7O2NBQ3ZHLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO2lCQUNYO01BRU87Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVTtpQkFDWDtNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBMkM7S0FBaUI7Ozs7ZUFDMUUsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBZ0IsV0FBVTtnQkFBMUM7T0FFRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCO1NBQXFEO1NBQVM7U0FBUztRQUFROzs7OztpQkFDL0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1FBQ3pDO1FBQ0EsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFvQztPQUFrQjs7OztpQkFDdkUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1FBQzdDO1FBQ0EsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQW9DO1FBQXFCOzs7O2tCQUMxRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7U0FDN0MsV0FBVztTQUNYO1NBQ0EsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBb0M7UUFBVTs7OztrQkFDL0Qsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxPQUFPLEVBQUUsT0FBTyxLQUFLO1NBQ3RDLFdBQVc7U0FDWDtTQUNBLFdBQVU7UUFDWDs7OztnQkFDRTs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFvQztPQUFxQjs7OztpQkFDMUUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1FBQ3hDO1FBQ0EsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQW9DO1FBQXNCOzs7O2tCQUMzRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxNQUFNLFlBQVksQ0FBQztTQUMvRCxXQUFXO1NBQ1g7U0FDQSxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFvQztRQUFxQjs7OztrQkFDMUUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sTUFBTSxZQUFZLENBQUM7U0FDOUQsV0FBVztTQUNYO1NBQ0EsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQW9DO09BQW9COzs7O2lCQUN6RSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUDtRQUNBLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBb0M7T0FBa0I7Ozs7aUJBQ3ZFLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1FBQzdDO1FBQ0EsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLGdCQUFnQixDQUFDLFlBQVk7U0FDNUMsV0FBVTttQkFFVCxlQUFlLGtDQUFrQztRQUM1Qzs7OztrQkFFUCxnQkFDQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBb0M7U0FBMEI7Ozs7bUJBQy9FLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxXQUFXLEVBQUUsT0FBTyxLQUFLO1VBQzFDLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFvQztTQUFzQjs7OzttQkFDM0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7VUFDMUMsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7OztpQkFDRjs7Ozs7Z0JBRUo7Ozs7OztPQUVMLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVSxXQUFXLENBQUM7UUFDdEIsV0FBVTtrQkFFVCxVQUFVLG1DQUFtQztPQUN4Qzs7Ozs7TUFDSjs7Ozs7YUFDSDs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMkM7TUFBcUI7Ozs7O01BRTdFLFNBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFELFlBQVEsU0FBYzs7Ozs7UUFBQztRQUFFO09BQ3RCOzs7Ozs7TUFHTixDQUFDLFVBQVUsQ0FBQyxTQUNYLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQXlEO1FBQzlCLHdCQUFDLFVBQUQsWUFBUSxzQkFBeUI7Ozs7O1FBQUM7T0FDeEQ7Ozs7OztNQUdOLFVBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFFRSx3QkFBQyxPQUFEO1NBQ0UsV0FBVyxxQ0FDVCxPQUFPLGFBQWEsWUFDaEIsc0RBQ0E7bUJBSlIsQ0FPRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixPQUFPLGFBQWEsWUFBWSx1QkFBdUI7U0FDckQ7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBOEI7V0FDaEIsd0JBQUMsVUFBRCxhQUFTLEtBQUssTUFBTSxPQUFPLGFBQWEsSUFBSSxPQUFPLGFBQWEsT0FBTyxhQUFhLEdBQUcsR0FBRSxHQUFTOzs7OztXQUFDO1dBQXNCLHdCQUFDLFVBQUQsYUFBUyxPQUFPLG1CQUFrQixHQUFTOzs7OztVQUM3Szs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTRCO1NBQThCOzs7O21CQUMxRSx3QkFBQyxRQUFEO1VBQU0sV0FBVyxhQUFhLFVBQVUsS0FBSyxxQkFBcUI7b0JBQWxFO1dBQ0c7V0FBUTtXQUFLLFVBQVUsS0FBSyxvQkFBb0I7VUFDN0M7Ozs7O2lCQUNIOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF3QztVQUE0Qzs7Ozs7VUFDakcsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWdCLEtBQUssVUFBVSxhQUFhLE1BQU0sQ0FBQztVQUFPOzs7OztVQUN6RSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBNkM7VUFBeUI7Ozs7O1VBQ25GLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFvQixLQUFLLFVBQVUsUUFBUSxNQUFNLENBQUM7VUFBTzs7Ozs7U0FDckU7Ozs7OztPQUNGOzs7Ozs7S0FFSjs7Ozs7SUFDRjs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hlY2tvdXRTaW11bGF0b3IuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JzsgXHJcblxyXG5jb25zdCBTVVBBQkFTRV9VUkwgPSAnaHR0cHM6Ly9vZmR3bGFnYXdsYXdyZnFiZ2JicS5zdXBhYmFzZS5jbyc7XHJcbmNvbnN0IFNVUEFCQVNFX0FOT05fS0VZID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfU1VQQUJBU0VfQU5PTl9LRVkgfHwgJyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDaGVja291dFNpbXVsYXRvcigpIHtcclxuICAvLyBFeHRyYWN0IHVzZXIgYW5kIHNlc3Npb24gdG9rZW4gZnJvbSBBdXRoQ29udGV4dFxyXG4gIGNvbnN0IGF1dGggPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgdXNlckVtYWlsID0gYXV0aD8udXNlcj8uZW1haWwgfHwgbnVsbDtcclxuICBjb25zdCB1c2VyVG9rZW4gPSBhdXRoPy5zZXNzaW9uPy5hY2Nlc3NfdG9rZW4gfHwgYXV0aD8udG9rZW4gfHwgbnVsbDtcclxuXHJcbiAgLy8gQXV0aGVudGljYXRlZCBNZXJjaGFudCBTdGF0ZVxyXG4gIGNvbnN0IFttZXJjaGFudElkLCBzZXRNZXJjaGFudElkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbbWVyY2hhbnROYW1lLCBzZXRNZXJjaGFudE5hbWVdID0gdXNlU3RhdGUoJ0ZldGNoaW5nIG1lcmNoYW50IHByb2ZpbGUuLi4nKTtcclxuXHJcbiAgLy8gQ3VzdG9tZXIgRm9ybSBTdGF0ZVxyXG4gIGNvbnN0IFthbW91bnQsIHNldEFtb3VudF0gPSB1c2VTdGF0ZSgnMjUuMDAnKTtcclxuICBjb25zdCBbY2FyZE51bWJlciwgc2V0Q2FyZE51bWJlcl0gPSB1c2VTdGF0ZSgnNDUzMiA4OTAxIDIzNDUgODg5MicpO1xyXG4gIGNvbnN0IFtleHBpcnlEYXRlLCBzZXRFeHBpcnlEYXRlXSA9IHVzZVN0YXRlKCcxMi8yOCcpO1xyXG4gIGNvbnN0IFtjdnYsIHNldEN2dl0gPSB1c2VTdGF0ZSgnMzgxJyk7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnam9obi5kb2VAZ21haWwuY29tJyk7XHJcbiAgY29uc3QgW2lzc3VlckNvdW50cnksIHNldElzc3VlckNvdW50cnldID0gdXNlU3RhdGUoJ1VTJyk7XHJcbiAgY29uc3QgW2JpbGxpbmdDb3VudHJ5LCBzZXRCaWxsaW5nQ291bnRyeV0gPSB1c2VTdGF0ZSgnVVMnKTtcclxuICBjb25zdCBbY3VycmVuY3ldID0gdXNlU3RhdGUoJ0VVUicpO1xyXG5cclxuICAvLyBBZHZhbmNlZCBNTCBQYXJhbWV0ZXIgU3RhdGVzXHJcbiAgY29uc3QgW3Nob3dBZHZhbmNlZCwgc2V0U2hvd0FkdmFuY2VkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbemlwQ29kZSwgc2V0WmlwQ29kZV0gPSB1c2VTdGF0ZSgnOTAyMTAnKTtcclxuICBjb25zdCBbY2l0eVBvcCwgc2V0Q2l0eVBvcF0gPSB1c2VTdGF0ZSgnNTAwMDAnKTtcclxuXHJcbiAgLy8gRXZhbHVhdGlvbiBTdGF0ZVxyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVzdWx0LCBzZXRSZXN1bHRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xhdGVuY3ksIHNldExhdGVuY3ldID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xhc3RQYXlsb2FkLCBzZXRMYXN0UGF5bG9hZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBNT0NLX0JJTl9MT09LVVAgPSB7XHJcbiAgICAnNDUzMjg5JzogJ0NoYXNlIEJhbmsnLCAgICAgICAvLyBTYWZlIEN1c3RvbWVyIHNldHVwXHJcbiAgICAnNTQxMjk5JzogJ0JhcmNsYXlzIEJhbmsnLCAgICAvLyBTdXNwaWNpb3VzIEZyYXVkIHNldHVwXHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTWVyY2hhbnRQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAvLyAxLiBIYW5kbGUgdW5hdXRoZW50aWNhdGVkIHN0YXRlXHJcbiAgICAgIGlmICghdXNlckVtYWlsKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKCdDaGVja291dFNpbXVsYXRvcjogTm8gdXNlciBlbWFpbCBhdmFpbGFibGUgZnJvbSBBdXRoQ29udGV4dC4nKTtcclxuICAgICAgICBzZXRNZXJjaGFudElkKCcnKTtcclxuICAgICAgICBzZXRNZXJjaGFudE5hbWUoJ1VuYXV0aGVudGljYXRlZCBVc2VyJyk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7XHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgLi4uKFNVUEFCQVNFX0FOT05fS0VZID8geyBhcGlrZXk6IFNVUEFCQVNFX0FOT05fS0VZIH0gOiB7fSksXHJcbiAgICAgICAgICAuLi4odXNlclRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dXNlclRva2VufWAgfSA6IHt9KVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke1NVUEFCQVNFX1VSTH0vcmVzdC92MS9tZXJjaGFudHM/ZW1haWw9ZXEuJHtlbmNvZGVVUklDb21wb25lbnQodXNlckVtYWlsKX0mc2VsZWN0PWlkLG1lcmNoYW50X25hbWVgO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnNvbGUubG9nKGBGZXRjaGluZyBtZXJjaGFudCBwcm9maWxlIGZvcjogXCIke3VzZXJFbWFpbH1cIiAoUkxTIFRva2VuIFByZXNlbnQ6ICR7ISF1c2VyVG9rZW59KWApO1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwgeyBoZWFkZXJzIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uub2spIHtcclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnU3VwYWJhc2UgTWVyY2hhbnQgTG9va3VwIFJlc3BvbnNlOicsIGRhdGEpO1xyXG5cclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpICYmIGRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBzZXRNZXJjaGFudElkKGRhdGFbMF0uaWQgfHwgJycpO1xyXG4gICAgICAgICAgICBzZXRNZXJjaGFudE5hbWUoZGF0YVswXS5tZXJjaGFudF9uYW1lIHx8ICdVbm5hbWVkIE1lcmNoYW50Jyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBzZXRNZXJjaGFudElkKCcnKTtcclxuICAgICAgICAgIHNldE1lcmNoYW50TmFtZShgTm8gbWVyY2hhbnQgcmVjb3JkIGZvciAke3VzZXJFbWFpbH1gKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignU3VwYWJhc2UgSFRUUCBFcnJvcjonLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnN0YXR1c1RleHQpO1xyXG4gICAgICAgICAgc2V0TWVyY2hhbnRJZCgnJyk7XHJcbiAgICAgICAgICBzZXRNZXJjaGFudE5hbWUoJ0ZhaWxlZCB0byBmZXRjaCBtZXJjaGFudCBwcm9maWxlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyBtZXJjaGFudCBwcm9maWxlOicsIGVycik7XHJcbiAgICAgICAgc2V0TWVyY2hhbnRJZCgnJyk7XHJcbiAgICAgICAgc2V0TWVyY2hhbnROYW1lKCdFcnJvciBsb2FkaW5nIG1lcmNoYW50Jyk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hNZXJjaGFudFByb2ZpbGUoKTtcclxuICB9LCBbdXNlckVtYWlsLCB1c2VyVG9rZW5dKTtcclxuXHJcbiAgLy8gUHJlc2V0IDE6IFNhZmUgQ3VzdG9tZXIgRmxvd1xyXG4gIGNvbnN0IGhhbmRsZVByZXNldFNhZmUgPSAoKSA9PiB7XHJcbiAgICBzZXRBbW91bnQoJzI1LjAwJyk7XHJcbiAgICBzZXRDYXJkTnVtYmVyKCc0NTMyIDg5MDEgMjM0NSA4ODkyJyk7XHJcbiAgICBzZXRFeHBpcnlEYXRlKCcxMi8yOCcpO1xyXG4gICAgc2V0Q3Z2KCczODEnKTtcclxuICAgIHNldEVtYWlsKCdqb2huLmRvZUBnbWFpbC5jb20nKTtcclxuICAgIHNldElzc3VlckNvdW50cnkoJ1VTJyk7XHJcbiAgICBzZXRCaWxsaW5nQ291bnRyeSgnVVMnKTtcclxuICAgIHNldFppcENvZGUoJzkwMjEwJyk7XHJcbiAgICBzZXRDaXR5UG9wKCc1MDAwMCcpO1xyXG4gICAgc2V0UmVzdWx0KG51bGwpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gUHJlc2V0IDI6IFN1c3BpY2lvdXMgRnJhdWRzdGVyIEZsb3dcclxuICBjb25zdCBoYW5kbGVQcmVzZXRGcmF1ZCA9ICgpID0+IHtcclxuICAgIHNldEFtb3VudCgnMTI1MC4wMCcpO1xyXG4gICAgc2V0Q2FyZE51bWJlcignNTQxMiA5OTE4IDIwMzkgMTA0OScpO1xyXG4gICAgc2V0RXhwaXJ5RGF0ZSgnMDQvMjYnKTtcclxuICAgIHNldEN2dignOTkyJyk7XHJcbiAgICBzZXRFbWFpbCgnYm90OTkyMUB0ZW1wLW1haWwub3JnJyk7XHJcbiAgICBzZXRJc3N1ZXJDb3VudHJ5KCdORycpO1xyXG4gICAgc2V0QmlsbGluZ0NvdW50cnkoJ1VTJyk7XHJcbiAgICBzZXRaaXBDb2RlKCc5OTk5OScpO1xyXG4gICAgc2V0Q2l0eVBvcCgnMTI1MCcpO1xyXG4gICAgc2V0UmVzdWx0KG51bGwpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ2xlYXIgRm9ybSBJbnB1dHNcclxuICBjb25zdCBoYW5kbGVDbGVhciA9ICgpID0+IHtcclxuICAgIHNldEFtb3VudCgnJyk7XHJcbiAgICBzZXRDYXJkTnVtYmVyKCcnKTtcclxuICAgIHNldEV4cGlyeURhdGUoJycpO1xyXG4gICAgc2V0Q3Z2KCcnKTtcclxuICAgIHNldEVtYWlsKCcnKTtcclxuICAgIHNldElzc3VlckNvdW50cnkoJycpO1xyXG4gICAgc2V0QmlsbGluZ0NvdW50cnkoJycpO1xyXG4gICAgc2V0WmlwQ29kZSgnOTAyMTAnKTtcclxuICAgIHNldENpdHlQb3AoJzUwMDAwJyk7XHJcbiAgICBzZXRSZXN1bHQobnVsbCk7XHJcbiAgICBzZXRMYXN0UGF5bG9hZChudWxsKTtcclxuICAgIHNldExhdGVuY3kobnVsbCk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICB9O1xyXG5cclxuICAvLyBTdWJtaXQgUGF5bWVudCBSZXF1ZXN0XHJcbiAgY29uc3QgaGFuZGxlQ2hlY2tvdXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKCFtZXJjaGFudElkKSB7XHJcbiAgICAgIHNldEVycm9yKCdDYW5ub3QgZXZhbHVhdGUgcGF5bWVudCB3aXRob3V0IGEgdmFsaWQgTWVyY2hhbnQgSUQuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRSZXN1bHQobnVsbCk7XHJcblxyXG4gICAgY29uc3QgY2FyZEJpbiA9IGNhcmROdW1iZXIucmVwbGFjZSgvXFxEL2csICcnKS5zbGljZSgwLCA2KTtcclxuICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBgdHhfbGl2ZV8ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDAwMCl9YCxcclxuICAgICAgbWVyY2hhbnRfaWQ6IG1lcmNoYW50SWQsXHJcbiAgICAgIGFtb3VudDogcGFyc2VGbG9hdChhbW91bnQpLFxyXG4gICAgICBjdXJyZW5jeTogY3VycmVuY3ksXHJcbiAgICAgIGlzc3Vlcl9jb3VudHJ5OiBpc3N1ZXJDb3VudHJ5LFxyXG4gICAgICBiaWxsaW5nX2NvdW50cnk6IGJpbGxpbmdDb3VudHJ5LFxyXG4gICAgICBjdXN0b21lcl9lbWFpbDogZW1haWwsXHJcbiAgICAgIGNhcmRfYmluOiBjYXJkQmluLFxyXG4gICAgICBpc3N1ZXJfYmFua19uYW1lOiBNT0NLX0JJTl9MT09LVVBbY2FyZEJpbl0gfHwgJ0dsb2JhbCBJc3N1ZXIgQmFuaycsXHJcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICB6aXA6IHppcENvZGUgPyBwYXJzZUludCh6aXBDb2RlLCAxMCkgOiA5MDIxMCxcclxuICAgICAgY2l0eV9wb3A6IGNpdHlQb3AgPyBwYXJzZUludChjaXR5UG9wLCAxMCkgOiA1MDAwMCxcclxuICAgIH07XHJcblxyXG4gICAgc2V0TGFzdFBheWxvYWQocGF5bG9hZCk7XHJcbiAgICBjb25zdCBzdGFydFRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCdodHRwOi8vMTI3LjAuMC4xOjgwMDAvdjEvY2hhcmdlL2V2YWx1YXRlJywge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGVsYXBzZWRNcyA9IE1hdGgucm91bmQocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydFRpbWUpO1xyXG4gICAgICBzZXRMYXRlbmN5KGVsYXBzZWRNcyk7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoYEhUVFAgRXJyb3IgJHtyZXNwb25zZS5zdGF0dXN9YCk7XHJcblxyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICBzZXRSZXN1bHQoZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBjb25uZWN0IHRvIEZyYXVkRmx1eCBBUEkuJyk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPGhlYWRlcj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtWyMyMTAwNURdXCI+UGF5bWVudCBDaGVja291dCBTaW11bGF0b3I8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICBTaW11bGF0ZSBlLWNvbW1lcmNlIGNoZWNrb3V0IGV2ZW50cyBhbmQgZXZhbHVhdGUgcmlzayBpbmZlcmVuY2UgbGF0ZW5jeSBpbiByZWFsLXRpbWUuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIHsvKiBQcmVzZXQgQWN0aW9uIEJhciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI0U4REVGOF0gcC00IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlciBib3JkZXItWyM2NzUwQTRdLzIwXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzIxMDA1RF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TElWRSBTSU1VTEFUSU9OIFNFVFVQPC9zcGFuPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteC0zIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmVzZXRTYWZlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMy41IHB5LTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFNhZmUgQ3VzdG9tZXJcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJlc2V0RnJhdWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC02MDAgaG92ZXI6YmctcmVkLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMy41IHB5LTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFN1c3BpY2lvdXMgRnJhdWRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJ9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMjAwIGhvdmVyOmJnLWdyYXktMzAwIHRleHQtZ3JheS03MDAgdGV4dC14cyBmb250LW1lZGl1bSBweC0zIHB5LTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ2xlYXJcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgIHsvKiBSZWFsaXN0aWMgQ2hlY2tvdXQgRm9ybSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPkNoZWNrb3V0IEZvcm08L2gyPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNoZWNrb3V0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgey8qIEFtb3VudCAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+QW1vdW50ICh7Y3VycmVuY3l9KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXthbW91bnR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbSBtdC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDYXJkIE51bWJlciAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+Q2FyZCBOdW1iZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI0NTMyIDAwMDAgMDAwMCAwMDAwXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjYXJkTnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXJkTnVtYmVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtIG10LTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF1cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEV4cGlyeSAmIENWViAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5FeHBpcnkgKE1NL1lZKTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjEyLzI4XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2V4cGlyeURhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RXhwaXJ5RGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbSBtdC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5DVlY8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIxMjNcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3Z2fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN2dihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NH1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbSBtdC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEN1c3RvbWVyIEVtYWlsICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5DdXN0b21lciBFbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJjdXN0b21lckBleGFtcGxlLmNvbVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtIG10LTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF1cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIENvdW50cnkgQ29udGV4dCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5CaWxsaW5nIENvdW50cnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2JpbGxpbmdDb3VudHJ5fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJpbGxpbmdDb3VudHJ5KGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtMyBweS0yIHRleHQtc20gbXQtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjNjc1MEE0XVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+SXNzdWVyIENvdW50cnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2lzc3VlckNvdW50cnl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SXNzdWVyQ291bnRyeShlLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpKX1cclxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtIG10LTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF1cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTWVyY2hhbnQgTmFtZSAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+TWVyY2hhbnQgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWVyY2hhbnROYW1lfVxyXG4gICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktNTAgdGV4dC1ncmF5LTcwMCBmb250LW1lZGl1bSByb3VuZGVkIHB4LTMgcHktMiB0ZXh0LXNtIG10LTEgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTWVyY2hhbnQgSUQgKi99XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPk1lcmNoYW50IElEPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXJjaGFudElkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXJjaGFudElkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gNjc3OTk1YTYtMWU5NC00NDBkLTlkMjctNzlhZTVkN2QwZTg4XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcm91bmRlZCBweC0zIHB5LTIgdGV4dC1zbSBtdC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUb2dnbGVhYmxlIEFkdmFuY2VkIFBhcmFtZXRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkdmFuY2VkKCFzaG93QWR2YW5jZWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyM2NzUwQTRdIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb2N1czpvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtzaG93QWR2YW5jZWQgPyAn4pa8IEhpZGUgQWR2YW5jZWQgTUwgUGFyYW1ldGVycycgOiAn4pa2IFNob3cgQWR2YW5jZWQgTUwgUGFyYW1ldGVycyAoWklQICYgUG9wdWxhdGlvbiknfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICB7c2hvd0FkdmFuY2VkICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNCBtdC0zIHAtMyBiZy1wdXJwbGUtNTAvNTAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXB1cnBsZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+WklQIENvZGUgKDUgZGlnaXRzKTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt6aXBDb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRaaXBDb2RlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiOTAyMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC0zIHB5LTEuNSB0ZXh0LXNtIG10LTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF0gYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5DaXR5IFBvcHVsYXRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2l0eVBvcH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2l0eVBvcChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjUwMDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtMyBweS0xLjUgdGV4dC1zbSBtdC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFtZXJjaGFudElkfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1bIzY3NTBBNF0gaG92ZXI6YmctWyM1MzNmODVdIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gcHktMi41IHJvdW5kZWQtbWQgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwIG10LTJcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcgPyAnRXZhbHVhdGluZyBSaXNrIHZpYSBYR0Jvb3N0Li4uJyA6ICdQcm9jZXNzIFBheW1lbnQgJiBFdmFsdWF0ZSBSaXNrJ31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBFdmFsdWF0aW9uIE91dHB1dCBDYXJkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+RXZhbHVhdGlvbiBSZXN1bHQ8L2gyPlxyXG5cclxuICAgICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgdGV4dC1yZWQtNzAwIHAtNCByb3VuZGVkLW1kIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgIDxzdHJvbmc+RXJyb3I6PC9zdHJvbmc+IHtlcnJvcn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshcmVzdWx0ICYmICFlcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiB0ZXh0LWdyYXktNDAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgIFNlbGVjdCBhIHNldHVwIGFuZCBjbGljayA8c3Ryb25nPlwiUHJvY2VzcyBQYXltZW50XCI8L3N0cm9uZz4gdG8gcnVuIGEgbGl2ZSBldmFsdWF0aW9uLlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3Jlc3VsdCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBSZXN1bHQgQmFubmVyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTQgcm91bmRlZC1tZCBib3JkZXIgdGV4dC1jZW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQuZGVjaXNpb24gPT09ICdBUFBST1ZFJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCBib3JkZXItZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTgwMCdcclxuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXJlZC01MCBib3JkZXItcmVkLTIwMCB0ZXh0LXJlZC04MDAnXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC5kZWNpc2lvbiA9PT0gJ0FQUFJPVkUnID8gJ+KchSBQQVlNRU5UIEFQUFJPVkVEJyA6ICfwn5qoIFBBWU1FTlQgREVDTElORUQgKEZSQVVEIERFVEVDVEVEKSd9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJpc2sgU2NvcmU6IDxzdHJvbmc+e01hdGgucm91bmQocmVzdWx0LnJpc2tfc2NvcmUgPiAxID8gcmVzdWx0LnJpc2tfc2NvcmUgOiByZXN1bHQucmlza19zY29yZSAqIDEwMCl9JTwvc3Ryb25nPiB8IER5bmFtaWMgVGhyZXNob2xkOiA8c3Ryb25nPntyZXN1bHQudGhyZXNob2xkX2FwcGxpZWR9JTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBTTEEgTWV0cmljICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC0zIHJvdW5kZWQtbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBmb250LW1lZGl1bVwiPuKaoSBSZWFsLVRpbWUgQVBJIExhdGVuY3k6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LWJvbGQgJHtsYXRlbmN5IDwgNTAgPyAndGV4dC1lbWVyYWxkLTYwMCcgOiAndGV4dC1hbWJlci02MDAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtsYXRlbmN5fSBtcyB7bGF0ZW5jeSA8IDUwID8gJyhTTEEgPDUwbXMgTWV0KScgOiAnKE92ZXIgNTBtcyBUYXJnZXQpJ31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFJhdyBKU09OIERlYnVnIEJveCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyMxRTFFMUVdIHRleHQtZ3JheS0yMDAgcC0zIHJvdW5kZWQtbWQgZm9udC1tb25vIHRleHQteHMgb3ZlcmZsb3cteC1hdXRvIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZvbnQtc2FucyBmb250LXNlbWlib2xkXCI+UE9TVCBQYXlsb2FkIHNlbnQgdG8gL3YxL2NoYXJnZS9ldmFsdWF0ZTo8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwidGV4dC1za3ktMzAwXCI+e0pTT04uc3RyaW5naWZ5KGxhc3RQYXlsb2FkLCBudWxsLCAyKX08L3ByZT5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBmb250LXNhbnMgZm9udC1zZW1pYm9sZCBwdC0yXCI+QVBJIFJlc3BvbnNlIHJlY2VpdmVkOjwvcD5cclxuICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtMzAwXCI+e0pTT04uc3RyaW5naWZ5KHJlc3VsdCwgbnVsbCwgMil9PC9wcmU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn0iXX0=