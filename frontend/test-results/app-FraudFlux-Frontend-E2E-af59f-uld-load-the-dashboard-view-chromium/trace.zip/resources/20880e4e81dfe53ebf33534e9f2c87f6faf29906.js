import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Dashboard.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=51adfdae";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=36d5d5c3";
// Import useAuth to access authenticated merchant user session (Req 6)
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=51adfdae";
var _s = $RefreshSig$();
// 1. Accept the transactions prop we just passed from App.jsx
export default function Dashboard({ transactions = [] }) {
	_s();
	// Access logged-in user context
	const { user } = useAuth();
	// State for CSV export date filter and loading state (Req 6)
	const [days, setDays] = useState(30);
	const [downloading, setDownloading] = useState(false);
	// 2. Format the data slightly so Recharts can easily read it
	const chartData = transactions.map((tx) => ({
		name: tx.transaction_id,
		amount: tx.amount
	}));
	// CSV Export Handler Function for Requirement 6
	const handleExportCSV = async () => {
		if (!user?.id) {
			alert("Merchant session not found. Please sign in again.");
			return;
		}
		setDownloading(true);
		try {
			// Fetch transaction CSV stream from FastAPI backend
			const response = await fetch(`http://localhost:8000/v1/transactions/export?merchant_id=${user.id}&days=${days}`);
			if (!response.ok) throw new Error("Failed to generate export report.");
			// Step 1: Convert response stream into a downloadable file Blob
			const blob = await response.blob();
			// Step 2: Create a temporary in-memory Object URL for browser download
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `fraudflux_report_${days}d.csv`;
			// Step 3: Programmatically click the link to trigger download and cleanup memory
			document.body.appendChild(a);
			a.click();
			a.remove();
			window.URL.revokeObjectURL(url);
		} catch (err) {
			console.error("Export error:", err);
			alert("Error exporting CSV report.");
		} finally {
			setDownloading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-10 bg-white flex-1 overflow-y-auto text-gray-900 font-sans",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-5xl mx-auto space-y-12",
			children: [
				/* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center mb-6",
						children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-3xl font-bold",
							children: "Fraud"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: days,
								onChange: (e) => setDays(Number(e.target.value)),
								className: "p-1.5 border border-gray-300 rounded-md text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#6750A4]",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: 7,
										children: "Last 7 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 76,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 30,
										children: "Last 30 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 90,
										children: "Last 90 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 78,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleExportCSV,
								disabled: downloading,
								className: "text-[#6750A4] text-sm font-medium flex items-center hover:underline disabled:opacity-50",
								children: downloading ? "Downloading..." : "Download report overview (CSV)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-3 gap-8 mb-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-blue-400 mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 17
								}, this), " Fraud disputes"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.06%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-[#E8DEF8] mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 100,
									columnNumber: 17
								}, this), " Early fraud warnings"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.03%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-[#21005D] mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this), " Fraud rate"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.08%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border border-gray-100 rounded-lg p-6 h-72 bg-white shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-semibold text-gray-700 mb-4",
							children: "Transaction Volume by ID"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ _jsxDEV(BarChart, {
								data: chartData,
								children: [
									/* @__PURE__ */ _jsxDEV(CartesianGrid, {
										strokeDasharray: "3 3",
										vertical: false,
										stroke: "#E5E7EB"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 117,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(XAxis, {
										dataKey: "name",
										axisLine: false,
										tickLine: false,
										tick: {
											fontSize: 12,
											fill: "#6B7280"
										},
										dy: 10
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(YAxis, {
										axisLine: false,
										tickLine: false,
										tick: {
											fontSize: 12,
											fill: "#6B7280"
										},
										tickFormatter: (value) => `$${value}`,
										dx: -10
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Tooltip, {
										cursor: { fill: "#F3F4F6" },
										contentStyle: {
											borderRadius: "8px",
											border: "none",
											boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)"
										},
										formatter: (value) => [`$${value}`, "Amount"]
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Bar, {
										dataKey: "amount",
										fill: "#6750A4",
										radius: [
											4,
											4,
											0,
											0
										],
										barSize: 40
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("hr", { className: "border-gray-200" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold",
							children: "Fraud prevention"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-gray-600 mt-1",
							children: ["Understand trends in the volume of transactions blocked by the system. ", /* @__PURE__ */ _jsxDEV("a", {
								href: "#",
								className: "text-[#6750A4] hover:underline",
								children: "Learn more"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 126
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-4 gap-6 mb-8",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Attempted transactions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "138,910"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Blocked"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "1,320"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Block rate"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.95%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Volume blocked"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "€150,000"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-sm text-gray-700",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-200",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/4",
									children: "Block Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Count"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Volume"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Block rate"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/4",
									children: "Est. false positive rate"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-100",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4 font-medium text-[#6750A4]",
									children: "Flux - High risk score"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "924"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "€90,000"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.67%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.12%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 175,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-100",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4 font-medium text-[#6750A4]",
									children: "Flux - Rules"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "396"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 179,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "€40,800"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 180,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.29%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "1.94%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
}
_s(Dashboard, "3wZA4LIX64hdnvND+tuFOo9nV3M=", false, function() {
	return [useAuth];
});
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Dashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFVBQVUsS0FBSyxPQUFPLE9BQU8sZUFBZSxTQUFTLDJCQUEyQjs7QUFFekYsU0FBUyxlQUFlOzs7OztBQUd4QixlQUFlLFNBQVMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxLQUFLOzs7Q0FFdkQsTUFBTSxFQUFFLFNBQVMsUUFBUTs7Q0FHekIsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSzs7Q0FHcEQsTUFBTSxZQUFZLGFBQWEsS0FBSSxRQUFPO0VBQ3hDLE1BQU0sR0FBRztFQUNULFFBQVEsR0FBRztDQUNiLEVBQUU7O0NBR0YsTUFBTSxrQkFBa0IsWUFBWTtFQUNsQyxJQUFJLENBQUMsTUFBTSxJQUFJO0dBQ2IsTUFBTSxtREFBbUQ7R0FDekQ7RUFDRjtFQUVBLGVBQWUsSUFBSTtFQUVuQixJQUFJOztHQUVGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLDREQUE0RCxLQUFLLEdBQUcsUUFBUSxNQUM5RTtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sbUNBQW1DOztHQUdyRSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7O0dBR2pDLE1BQU0sTUFBTSxPQUFPLElBQUksZ0JBQWdCLElBQUk7R0FDM0MsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0dBQ3BDLEVBQUUsT0FBTztHQUNULEVBQUUsV0FBVyxvQkFBb0IsS0FBSzs7R0FHdEMsU0FBUyxLQUFLLFlBQVksQ0FBQztHQUMzQixFQUFFLE1BQU07R0FDUixFQUFFLE9BQU87R0FDVCxPQUFPLElBQUksZ0JBQWdCLEdBQUc7RUFDaEMsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLGlCQUFpQixHQUFHO0dBQ2xDLE1BQU0sNkJBQTZCO0VBQ3JDLFVBQVU7R0FDUixlQUFlLEtBQUs7RUFDdEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsV0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXFCO01BQVM7Ozs7Z0JBRzVDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sUUFBUSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7UUFDL0MsV0FBVTtrQkFIWjtTQUtFLHdCQUFDLFVBQUQ7VUFBUSxPQUFPO29CQUFHO1NBQW1COzs7OztTQUNyQyx3QkFBQyxVQUFEO1VBQVEsT0FBTztvQkFBSTtTQUFvQjs7Ozs7U0FDdkMsd0JBQUMsVUFBRDtVQUFRLE9BQU87b0JBQUk7U0FBb0I7Ozs7O1FBQ2pDOzs7OztpQkFFUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFVBQVU7UUFDVixXQUFVO2tCQUVULGNBQWMsbUJBQW1CO09BQzVCOzs7O2VBQ0w7Ozs7O2NBQ0Y7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQTRDOzs7O2tCQUFDLGlCQUMxRDs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7O2tCQUFDLHVCQUMzRDs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7O2tCQUFDLGFBQzNEOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBNEI7T0FBVTs7OztlQUNsRDs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMkM7TUFBNEI7Ozs7Z0JBQ3JGLHdCQUFDLHFCQUFEO09BQXFCLE9BQU07T0FBTyxRQUFPO2lCQUN2Qyx3QkFBQyxVQUFEO1FBQVUsTUFBTTtrQkFBaEI7U0FDRSx3QkFBQyxlQUFEO1VBQWUsaUJBQWdCO1VBQU0sVUFBVTtVQUFPLFFBQU87U0FBVzs7Ozs7U0FDeEUsd0JBQUMsT0FBRDtVQUFPLFNBQVE7VUFBTyxVQUFVO1VBQU8sVUFBVTtVQUFPLE1BQU07V0FBRSxVQUFVO1dBQUksTUFBTTtVQUFVO1VBQUcsSUFBSTtTQUFLOzs7OztTQUMxRyx3QkFBQyxPQUFEO1VBQU8sVUFBVTtVQUFPLFVBQVU7VUFBTyxNQUFNO1dBQUUsVUFBVTtXQUFJLE1BQU07VUFBVTtVQUFHLGdCQUFnQixVQUFVLElBQUk7VUFBUyxJQUFJLENBQUM7U0FBSzs7Ozs7U0FDbkksd0JBQUMsU0FBRDtVQUNFLFFBQVEsRUFBRSxNQUFNLFVBQVU7VUFDMUIsY0FBYztXQUFFLGNBQWM7V0FBTyxRQUFRO1dBQVEsV0FBVztVQUFvQztVQUNwRyxZQUFZLFVBQVUsQ0FBQyxJQUFJLFNBQVMsUUFBUTtTQUM3Qzs7Ozs7U0FDRCx3QkFBQyxLQUFEO1VBQUssU0FBUTtVQUFTLE1BQUs7VUFBVSxRQUFRO1dBQUM7V0FBRztXQUFHO1dBQUc7VUFBQztVQUFHLFNBQVM7U0FBSzs7Ozs7UUFDakU7Ozs7OztNQUNTOzs7O2NBQ2xCOzs7Ozs7SUFDRTs7Ozs7SUFFVCx3QkFBQyxNQUFELEVBQUksV0FBVSxrQkFBbUI7Ozs7O0lBR2pDLHdCQUFDLFdBQUQ7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQjtNQUFvQjs7OztnQkFDdEQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWIsQ0FBMEMsMkVBQXVFLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO1FBQUksV0FBVTtrQkFBaUM7T0FBYTs7OztlQUFJOzs7OztjQUN0TDs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXlDO09BQTJCOzs7O2lCQUNuRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBNEI7T0FBWTs7OztlQUNwRDs7Ozs7T0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXlDO09BQVk7Ozs7aUJBQ3BFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE0QjtPQUFVOzs7O2VBQ2xEOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBeUM7T0FBZTs7OztpQkFDdkUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF5QztPQUFtQjs7OztpQkFDM0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQWE7Ozs7ZUFDckQ7Ozs7O01BQ0Y7Ozs7OztLQUVMLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUFjOzs7OztRQUNyRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUM7UUFBUzs7Ozs7UUFDaEUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlDO1FBQVU7Ozs7O1FBQ2pFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUFjOzs7OztRQUNyRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUM7UUFBNEI7Ozs7O09BQ2pGOzs7OztlQUNDOzs7O2dCQUNQLHdCQUFDLFNBQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFrQztRQUEwQjs7Ozs7UUFDMUUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBTzs7Ozs7UUFDNUIsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBVzs7Ozs7UUFDaEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBUzs7Ozs7UUFDOUIsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBUzs7Ozs7T0FDNUI7Ozs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWtDO1FBQWdCOzs7OztRQUNoRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFPOzs7OztRQUM1Qix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFXOzs7OztRQUNoQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFTOzs7OztRQUM5Qix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFTOzs7OztPQUM1Qjs7Ozs7Y0FDQzs7OztjQUNGOzs7Ozs7SUFDQTs7Ozs7R0FDTjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEJhckNoYXJ0LCBCYXIsIFhBeGlzLCBZQXhpcywgQ2FydGVzaWFuR3JpZCwgVG9vbHRpcCwgUmVzcG9uc2l2ZUNvbnRhaW5lciB9IGZyb20gJ3JlY2hhcnRzJztcclxuLy8gSW1wb3J0IHVzZUF1dGggdG8gYWNjZXNzIGF1dGhlbnRpY2F0ZWQgbWVyY2hhbnQgdXNlciBzZXNzaW9uIChSZXEgNilcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcblxyXG4vLyAxLiBBY2NlcHQgdGhlIHRyYW5zYWN0aW9ucyBwcm9wIHdlIGp1c3QgcGFzc2VkIGZyb20gQXBwLmpzeFxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXNoYm9hcmQoeyB0cmFuc2FjdGlvbnMgPSBbXSB9KSB7XHJcbiAgLy8gQWNjZXNzIGxvZ2dlZC1pbiB1c2VyIGNvbnRleHRcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBcclxuICAvLyBTdGF0ZSBmb3IgQ1NWIGV4cG9ydCBkYXRlIGZpbHRlciBhbmQgbG9hZGluZyBzdGF0ZSAoUmVxIDYpXHJcbiAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoMzApO1xyXG4gIGNvbnN0IFtkb3dubG9hZGluZywgc2V0RG93bmxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyAyLiBGb3JtYXQgdGhlIGRhdGEgc2xpZ2h0bHkgc28gUmVjaGFydHMgY2FuIGVhc2lseSByZWFkIGl0XHJcbiAgY29uc3QgY2hhcnREYXRhID0gdHJhbnNhY3Rpb25zLm1hcCh0eCA9PiAoe1xyXG4gICAgbmFtZTogdHgudHJhbnNhY3Rpb25faWQsXHJcbiAgICBhbW91bnQ6IHR4LmFtb3VudFxyXG4gIH0pKTtcclxuXHJcbiAgLy8gQ1NWIEV4cG9ydCBIYW5kbGVyIEZ1bmN0aW9uIGZvciBSZXF1aXJlbWVudCA2XHJcbiAgY29uc3QgaGFuZGxlRXhwb3J0Q1NWID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCF1c2VyPy5pZCkge1xyXG4gICAgICBhbGVydChcIk1lcmNoYW50IHNlc3Npb24gbm90IGZvdW5kLiBQbGVhc2Ugc2lnbiBpbiBhZ2Fpbi5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXREb3dubG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBGZXRjaCB0cmFuc2FjdGlvbiBDU1Ygc3RyZWFtIGZyb20gRmFzdEFQSSBiYWNrZW5kXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC92MS90cmFuc2FjdGlvbnMvZXhwb3J0P21lcmNoYW50X2lkPSR7dXNlci5pZH0mZGF5cz0ke2RheXN9YFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gZ2VuZXJhdGUgZXhwb3J0IHJlcG9ydC4nKTtcclxuXHJcbiAgICAgIC8vIFN0ZXAgMTogQ29udmVydCByZXNwb25zZSBzdHJlYW0gaW50byBhIGRvd25sb2FkYWJsZSBmaWxlIEJsb2JcclxuICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFN0ZXAgMjogQ3JlYXRlIGEgdGVtcG9yYXJ5IGluLW1lbW9yeSBPYmplY3QgVVJMIGZvciBicm93c2VyIGRvd25sb2FkXHJcbiAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgICBhLmhyZWYgPSB1cmw7XHJcbiAgICAgIGEuZG93bmxvYWQgPSBgZnJhdWRmbHV4X3JlcG9ydF8ke2RheXN9ZC5jc3ZgO1xyXG5cclxuICAgICAgLy8gU3RlcCAzOiBQcm9ncmFtbWF0aWNhbGx5IGNsaWNrIHRoZSBsaW5rIHRvIHRyaWdnZXIgZG93bmxvYWQgYW5kIGNsZWFudXAgbWVtb3J5XHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XHJcbiAgICAgIGEuY2xpY2soKTtcclxuICAgICAgYS5yZW1vdmUoKTtcclxuICAgICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFeHBvcnQgZXJyb3I6JywgZXJyKTtcclxuICAgICAgYWxlcnQoJ0Vycm9yIGV4cG9ydGluZyBDU1YgcmVwb3J0LicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RG93bmxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTAgYmctd2hpdGUgZmxleC0xIG92ZXJmbG93LXktYXV0byB0ZXh0LWdyYXktOTAwIGZvbnQtc2Fuc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTV4bCBteC1hdXRvIHNwYWNlLXktMTJcIj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogU2VjdGlvbiAxOiBGcmF1ZCAqL31cclxuICAgICAgICA8c2VjdGlvbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZFwiPkZyYXVkPC9oMT5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDU1YgRXhwb3J0IERhdGUgU2VsZWN0b3IgYW5kIERvd25sb2FkIEJ1dHRvbiBDb250cm9scyAoUmVxIDYpICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2RheXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERheXMoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzY3NTBBNF1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezd9Pkxhc3QgNyBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXszMH0+TGFzdCAzMCBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs5MH0+TGFzdCA5MCBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydENTVn1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkb3dubG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWyM2NzUwQTRdIHRleHQtc20gZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgaG92ZXI6dW5kZXJsaW5lIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtkb3dubG9hZGluZyA/ICdEb3dubG9hZGluZy4uLicgOiAnRG93bmxvYWQgcmVwb3J0IG92ZXJ2aWV3IChDU1YpJ31cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTggbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgYmctYmx1ZS00MDAgbXItMiByb3VuZGVkLXNtXCI+PC9zcGFuPiBGcmF1ZCBkaXNwdXRlc1xyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPjAuMDYlPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgYmctWyNFOERFRjhdIG1yLTIgcm91bmRlZC1zbVwiPjwvc3Bhbj4gRWFybHkgZnJhdWQgd2FybmluZ3NcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGRcIj4wLjAzJTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIGJnLVsjMjEwMDVEXSBtci0yIHJvdW5kZWQtc21cIj48L3NwYW4+IEZyYXVkIHJhdGVcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGRcIj4wLjA4JTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7LyogMy4gVGhlIE5ldyBEeW5hbWljIENoYXJ0ISAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLWxnIHAtNiBoLTcyIGJnLXdoaXRlIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItNFwiPlRyYW5zYWN0aW9uIFZvbHVtZSBieSBJRDwvaDM+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICA8QmFyQ2hhcnQgZGF0YT17Y2hhcnREYXRhfT5cclxuICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHZlcnRpY2FsPXtmYWxzZX0gc3Ryb2tlPVwiI0U1RTdFQlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cIm5hbWVcIiBheGlzTGluZT17ZmFsc2V9IHRpY2tMaW5lPXtmYWxzZX0gdGljaz17eyBmb250U2l6ZTogMTIsIGZpbGw6ICcjNkI3MjgwJyB9fSBkeT17MTB9IC8+XHJcbiAgICAgICAgICAgICAgICA8WUF4aXMgYXhpc0xpbmU9e2ZhbHNlfSB0aWNrTGluZT17ZmFsc2V9IHRpY2s9e3sgZm9udFNpemU6IDEyLCBmaWxsOiAnIzZCNzI4MCcgfX0gdGlja0Zvcm1hdHRlcj17KHZhbHVlKSA9PiBgJCR7dmFsdWV9YH0gZHg9ey0xMH0gLz5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIFxyXG4gICAgICAgICAgICAgICAgICBjdXJzb3I9e3sgZmlsbDogJyNGM0Y0RjYnIH19XHJcbiAgICAgICAgICAgICAgICAgIGNvbnRlbnRTdHlsZT17eyBib3JkZXJSYWRpdXM6ICc4cHgnLCBib3JkZXI6ICdub25lJywgYm94U2hhZG93OiAnMCA0cHggNnB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjEpJyB9fVxyXG4gICAgICAgICAgICAgICAgICBmb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gW2AkJHt2YWx1ZX1gLCAnQW1vdW50J119XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiYW1vdW50XCIgZmlsbD1cIiM2NzUwQTRcIiByYWRpdXM9e1s0LCA0LCAwLCAwXX0gYmFyU2l6ZT17NDB9IC8+XHJcbiAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8aHIgY2xhc3NOYW1lPVwiYm9yZGVyLWdyYXktMjAwXCIgLz5cclxuXHJcbiAgICAgICAgey8qIFNlY3Rpb24gMjogRnJhdWQgUHJldmVudGlvbiAoS2VwdCBleGFjdGx5IGFzIGl0IHdhcykgKi99XHJcbiAgICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCI+RnJhdWQgcHJldmVudGlvbjwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0xXCI+VW5kZXJzdGFuZCB0cmVuZHMgaW4gdGhlIHZvbHVtZSBvZiB0cmFuc2FjdGlvbnMgYmxvY2tlZCBieSB0aGUgc3lzdGVtLiA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInRleHQtWyM2NzUwQTRdIGhvdmVyOnVuZGVybGluZVwiPkxlYXJuIG1vcmU8L2E+PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC02IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+QXR0ZW1wdGVkIHRyYW5zYWN0aW9uczwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPjEzOCw5MTA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkJsb2NrZWQ8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGRcIj4xLDMyMDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+QmxvY2sgcmF0ZTwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPjAuOTUlPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Wb2x1bWUgYmxvY2tlZDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPuKCrDE1MCwwMDA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwYi0zIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB3LTEvNFwiPkJsb2NrIFR5cGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInBiLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS82XCI+Q291bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInBiLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS82XCI+Vm9sdW1lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwYi0zIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB3LTEvNlwiPkJsb2NrIHJhdGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInBiLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS80XCI+RXN0LiBmYWxzZSBwb3NpdGl2ZSByYXRlPC90aD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgZm9udC1tZWRpdW0gdGV4dC1bIzY3NTBBNF1cIj5GbHV4IC0gSGlnaCByaXNrIHNjb3JlPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+OTI0PC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+4oKsOTAsMDAwPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+MC42NyU8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTRcIj4wLjEyJTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBmb250LW1lZGl1bSB0ZXh0LVsjNjc1MEE0XVwiPkZsdXggLSBSdWxlczwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNFwiPjM5NjwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNFwiPuKCrDQwLDgwMDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNFwiPjAuMjklPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+MS45NCU8L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19