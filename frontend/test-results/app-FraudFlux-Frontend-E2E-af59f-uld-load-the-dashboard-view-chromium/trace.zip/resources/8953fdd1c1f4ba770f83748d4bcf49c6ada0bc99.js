import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pricing.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Pricing.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
export default function Pricing({ onNavigate, isAuthenticated = false }) {
	_s();
	const [billingCycle, setBillingCycle] = useState("monthly");
	const plans = [
		{
			name: "Free",
			id: "plan-free",
			priceMonthly: "$0",
			priceAnnual: "$0",
			period: "forever",
			description: "Ideal for small projects, testing, and sandbox integration.",
			highlight: false,
			badge: null,
			ctaText: "Get Started Free",
			ctaStyle: "bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300",
			features: [
				"Up to 1,000 transactions / mo",
				"Standard rule-based risk evaluation",
				"< 100ms evaluation latency SLA",
				"Single merchant profile",
				"7-day transaction logs history",
				"Community support"
			]
		},
		{
			name: "Pro",
			id: "plan-pro",
			priceMonthly: "$20",
			priceAnnual: "$15",
			period: "/ month",
			description: "For growing e-commerce businesses needing real-time ML risk inference.",
			highlight: true,
			badge: "MOST POPULAR",
			ctaText: "Start 14-Day Free Trial",
			ctaStyle: "bg-[#6750A4] hover:bg-[#533f85] text-white shadow-md",
			features: [
				"Up to 100,000 transactions / mo",
				"Real-time XGBoost ML Model scoring",
				"Sub-50ms latency SLA guarantee",
				"Dynamic auto-decline threshold tuning",
				"CSV & report export tools (30-day logs)",
				"Standard email & chat support"
			]
		},
		{
			name: "Lifetime",
			id: "plan-lifetime",
			priceMonthly: "$200",
			priceAnnual: "$200",
			period: "one-time pay",
			description: "Pay once, protect forever. Unlimited access for scale-ups and founders.",
			highlight: false,
			badge: "BEST VALUE",
			ctaText: "Get Lifetime Access",
			ctaStyle: "bg-[#21005D] hover:bg-[#15003b] text-white shadow-md",
			features: [
				"Unlimited monthly transactions",
				"Priority XGBoost ML Model execution",
				"Ultra-low latency infrastructure (<30ms SLA)",
				"Unlimited historical transaction logs",
				"Custom risk rule configuration",
				"24/7 Priority developer support",
				"All future ML model updates included"
			]
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-4xl mx-auto text-center space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold text-[#6750A4] uppercase tracking-widest bg-[#E8DEF8] px-3 py-1 rounded-full",
						children: "Transparent Pricing"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl font-extrabold text-[#21005D] sm:text-5xl",
						children: "Simple, Predictive Fraud Prevention"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-base text-gray-600 max-w-2xl mx-auto",
						children: [
							"Scale your checkout without high chargeback fees.",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 60
							}, this),
							"Protect your store using real-time ML risk scoring."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-4 flex items-center justify-center space-x-3",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: `text-sm font-medium ${billingCycle === "monthly" ? "text-gray-900 font-semibold" : "text-gray-500"}`,
								children: "Monthly Billing"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setBillingCycle(billingCycle === "monthly" ? "annual" : "monthly"),
								className: "relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-[#6750A4] transition-colors duration-200 ease-in-out focus:outline-none",
								children: /* @__PURE__ */ _jsxDEV("span", { className: `pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${billingCycle === "annual" ? "translate-x-5" : "translate-x-0"}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: `text-sm font-medium ${billingCycle === "annual" ? "text-gray-900 font-semibold" : "text-gray-500"}`,
								children: ["Annual Billing ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-emerald-600 font-bold bg-emerald-100 px-2 py-0.5 rounded-full ml-1",
									children: "Save 20%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 28
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto mt-12 grid grid-cols-1 gap-8 lg:grid-cols-3 lg:gap-6 items-stretch",
				children: plans.map((plan) => {
					// Check if this card represents the logged-in user's active tier
					const isCurrentPlan = isAuthenticated && plan.id === "plan-free";
					const buttonText = isCurrentPlan ? "Your Current Plan" : plan.ctaText;
					const buttonStyle = isCurrentPlan ? "bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold cursor-default" : plan.ctaStyle;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `relative rounded-2xl bg-white p-8 shadow-sm flex flex-col justify-between border transition-all duration-200 ${plan.highlight ? "border-2 border-[#6750A4] shadow-xl scale-105 z-10" : "border-gray-200 hover:border-gray-300"}`,
						children: [
							plan.badge && /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute -top-3.5 left-1/2 -translate-x-1/2",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: `text-[10px] font-black uppercase tracking-wider text-white px-3 py-1 rounded-full ${plan.highlight ? "bg-[#6750A4]" : "bg-[#21005D]"}`,
									children: plan.badge
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center mb-4",
									children: /* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-bold text-[#21005D]",
										children: plan.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-gray-500 min-h-[36px] mb-6",
									children: plan.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-4xl font-extrabold text-gray-900",
										children: billingCycle === "annual" ? plan.priceAnnual : plan.priceMonthly
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 145,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-medium text-gray-500 ml-1",
										children: plan.period
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("ul", {
									className: "space-y-3 mb-8",
									children: plan.features.map((feature, idx) => /* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start space-x-3 text-xs text-gray-600",
										children: [/* @__PURE__ */ _jsxDEV("svg", {
											className: "h-4 w-4 text-emerald-500 flex-shrink-0 mt-0.5",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M5 13l4 4L19 7"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 161,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 155,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: feature }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 163,
											columnNumber: 23
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: isCurrentPlan,
								onClick: () => {
									if (isCurrentPlan) return;
									if (onNavigate) onNavigate("register");
								},
								className: `w-full text-center text-xs font-bold py-3 px-4 rounded-lg transition-colors ${buttonStyle}`,
								children: buttonText
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 15
							}, this)
						]
					}, plan.id, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-3xl mx-auto mt-16 text-center border-t border-gray-200 pt-8",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-sm font-semibold text-gray-700 mb-2",
						children: "Need a custom enterprise integration?"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-gray-500 mb-4",
						children: "We offer dedicated VPC deployments, custom ML retrain schedules, and tailored enterprise SLAs."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: "mailto:support@fraudflux.io",
						className: "text-xs font-bold text-[#6750A4] hover:underline",
						children: "Contact Enterprise Sales →"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 71,
		columnNumber: 5
	}, this);
}
_s(Pricing, "81HlboJFv/B1zl60iH3lKb8zPsQ=");
_c = Pricing;
var _c;
$RefreshReg$(_c, "Pricing");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Pricing.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Pricing.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Pricing.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Pricing.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjs7OztBQUVoQyxlQUFlLFNBQVMsUUFBUSxFQUFFLFlBQVksa0JBQWtCLFNBQVM7O0NBQ3ZFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLFNBQVM7Q0FFMUQsTUFBTSxRQUFRO0VBQ1o7R0FDRSxNQUFNO0dBQ04sSUFBSTtHQUNKLGNBQWM7R0FDZCxhQUFhO0dBQ2IsUUFBUTtHQUNSLGFBQWE7R0FDYixXQUFXO0dBQ1gsT0FBTztHQUNQLFNBQVM7R0FDVCxVQUFVO0dBQ1YsVUFBVTtJQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0VBQ0Y7RUFDQTtHQUNFLE1BQU07R0FDTixJQUFJO0dBQ0osY0FBYztHQUNkLGFBQWE7R0FDYixRQUFRO0dBQ1IsYUFBYTtHQUNiLFdBQVc7R0FDWCxPQUFPO0dBQ1AsU0FBUztHQUNULFVBQVU7R0FDVixVQUFVO0lBQ1I7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7RUFDRjtFQUNBO0dBQ0UsTUFBTTtHQUNOLElBQUk7R0FDSixjQUFjO0dBQ2QsYUFBYTtHQUNiLFFBQVE7R0FDUixhQUFhO0dBQ2IsV0FBVztHQUNYLE9BQU87R0FDUCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFVBQVU7SUFDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0VBQ0Y7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaUc7S0FFM0c7Ozs7O0tBQ04sd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXFEO0tBRS9EOzs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQXlEO09BQ04sd0JBQUMsTUFBRCxDQUFJOzs7OztPQUFDO01BQ3JEOzs7Ozs7S0FHSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFXLHVCQUF1QixpQkFBaUIsWUFBWSxnQ0FBZ0M7a0JBQW1CO09BRWxIOzs7OztPQUNOLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxnQkFBZ0IsaUJBQWlCLFlBQVksV0FBVyxTQUFTO1FBQ2hGLFdBQVU7a0JBRVYsd0JBQUMsUUFBRCxFQUNFLFdBQVcsOEhBQ1QsaUJBQWlCLFdBQVcsa0JBQWtCLGtCQUVqRDs7Ozs7T0FDSzs7Ozs7T0FDUix3QkFBQyxRQUFEO1FBQU0sV0FBVyx1QkFBdUIsaUJBQWlCLFdBQVcsZ0NBQWdDO2tCQUFwRyxDQUF1SCxtQkFDdEcsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWtGO1FBQWM7Ozs7Z0JBQzNIOzs7Ozs7TUFDSDs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osTUFBTSxLQUFLLFNBQVM7O0tBRW5CLE1BQU0sZ0JBQWdCLG1CQUFtQixLQUFLLE9BQU87S0FDckQsTUFBTSxhQUFhLGdCQUFnQixzQkFBc0IsS0FBSztLQUM5RCxNQUFNLGNBQWMsZ0JBQ2hCLHVGQUNBLEtBQUs7S0FFVCxPQUNFLHdCQUFDLE9BQUQ7TUFFRSxXQUFXLGdIQUNULEtBQUssWUFDRCx1REFDQTtnQkFMUjtPQVNHLEtBQUssU0FDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxRQUFEO1NBQU0sV0FBVyxxRkFDZixLQUFLLFlBQVksaUJBQWlCO21CQUVqQyxLQUFLO1FBQ0Y7Ozs7O09BQ0g7Ozs7O09BR1Asd0JBQUMsT0FBRDtRQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvQyxLQUFLO1NBQVM7Ozs7O1FBQzdEOzs7OztRQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQyxLQUFLO1FBQWU7Ozs7O1FBRzVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsaUJBQWlCLFdBQVcsS0FBSyxjQUFjLEtBQUs7U0FDakQ7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTBDLEtBQUs7U0FBYTs7OztpQkFDekU7Ozs7OztRQUdMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLEtBQUssU0FBUyxLQUFLLFNBQVMsUUFDM0Isd0JBQUMsTUFBRDtVQUFjLFdBQVU7b0JBQXhCLENBQ0Usd0JBQUMsT0FBRDtXQUNFLFdBQVU7V0FDVixNQUFLO1dBQ0wsUUFBTztXQUNQLFNBQVE7cUJBRVIsd0JBQUMsUUFBRDtZQUFNLGVBQWM7WUFBUSxnQkFBZTtZQUFRLGFBQVk7WUFBTSxHQUFFO1dBQWtCOzs7OztVQUN0Rjs7OztvQkFDTCx3QkFBQyxRQUFELFlBQU8sUUFBYzs7OztrQkFDbkI7WUFWSzs7OztnQkFVTCxDQUNMO1FBQ0M7Ozs7O09BQ0Q7Ozs7O09BR0wsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsZUFBZTtTQUNiLElBQUksZUFBZTtTQUNuQixJQUFJLFlBQVksV0FBVyxVQUFVO1FBQ3ZDO1FBQ0EsV0FBVywrRUFBK0U7a0JBRXpGO09BQ0s7Ozs7O01BQ0w7UUEvREUsS0FBSzs7OztZQStEUDtJQUVULENBQUM7R0FDRTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTJDO0tBQXlDOzs7OztLQUNsRyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNkI7S0FFdkM7Ozs7O0tBQ0gsd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBOEIsV0FBVTtnQkFBbUQ7S0FFaEc7Ozs7O0lBQ0E7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcmljaW5nLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcmljaW5nKHsgb25OYXZpZ2F0ZSwgaXNBdXRoZW50aWNhdGVkID0gZmFsc2UgfSkge1xyXG4gIGNvbnN0IFtiaWxsaW5nQ3ljbGUsIHNldEJpbGxpbmdDeWNsZV0gPSB1c2VTdGF0ZSgnbW9udGhseScpOyAvLyAnbW9udGhseScgfCAnYW5udWFsJ1xyXG5cclxuICBjb25zdCBwbGFucyA9IFtcclxuICAgIHtcclxuICAgICAgbmFtZTogJ0ZyZWUnLFxyXG4gICAgICBpZDogJ3BsYW4tZnJlZScsXHJcbiAgICAgIHByaWNlTW9udGhseTogJyQwJyxcclxuICAgICAgcHJpY2VBbm51YWw6ICckMCcsXHJcbiAgICAgIHBlcmlvZDogJ2ZvcmV2ZXInLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ0lkZWFsIGZvciBzbWFsbCBwcm9qZWN0cywgdGVzdGluZywgYW5kIHNhbmRib3ggaW50ZWdyYXRpb24uJyxcclxuICAgICAgaGlnaGxpZ2h0OiBmYWxzZSxcclxuICAgICAgYmFkZ2U6IG51bGwsXHJcbiAgICAgIGN0YVRleHQ6ICdHZXQgU3RhcnRlZCBGcmVlJyxcclxuICAgICAgY3RhU3R5bGU6ICdiZy1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTIwMCB0ZXh0LWdyYXktODAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAnLFxyXG4gICAgICBmZWF0dXJlczogW1xyXG4gICAgICAgICdVcCB0byAxLDAwMCB0cmFuc2FjdGlvbnMgLyBtbycsXHJcbiAgICAgICAgJ1N0YW5kYXJkIHJ1bGUtYmFzZWQgcmlzayBldmFsdWF0aW9uJyxcclxuICAgICAgICAnPCAxMDBtcyBldmFsdWF0aW9uIGxhdGVuY3kgU0xBJyxcclxuICAgICAgICAnU2luZ2xlIG1lcmNoYW50IHByb2ZpbGUnLFxyXG4gICAgICAgICc3LWRheSB0cmFuc2FjdGlvbiBsb2dzIGhpc3RvcnknLFxyXG4gICAgICAgICdDb21tdW5pdHkgc3VwcG9ydCcsXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBuYW1lOiAnUHJvJyxcclxuICAgICAgaWQ6ICdwbGFuLXBybycsXHJcbiAgICAgIHByaWNlTW9udGhseTogJyQyMCcsXHJcbiAgICAgIHByaWNlQW5udWFsOiAnJDE1JyxcclxuICAgICAgcGVyaW9kOiAnLyBtb250aCcsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnRm9yIGdyb3dpbmcgZS1jb21tZXJjZSBidXNpbmVzc2VzIG5lZWRpbmcgcmVhbC10aW1lIE1MIHJpc2sgaW5mZXJlbmNlLicsXHJcbiAgICAgIGhpZ2hsaWdodDogdHJ1ZSxcclxuICAgICAgYmFkZ2U6ICdNT1NUIFBPUFVMQVInLFxyXG4gICAgICBjdGFUZXh0OiAnU3RhcnQgMTQtRGF5IEZyZWUgVHJpYWwnLFxyXG4gICAgICBjdGFTdHlsZTogJ2JnLVsjNjc1MEE0XSBob3ZlcjpiZy1bIzUzM2Y4NV0gdGV4dC13aGl0ZSBzaGFkb3ctbWQnLFxyXG4gICAgICBmZWF0dXJlczogW1xyXG4gICAgICAgICdVcCB0byAxMDAsMDAwIHRyYW5zYWN0aW9ucyAvIG1vJyxcclxuICAgICAgICAnUmVhbC10aW1lIFhHQm9vc3QgTUwgTW9kZWwgc2NvcmluZycsXHJcbiAgICAgICAgJ1N1Yi01MG1zIGxhdGVuY3kgU0xBIGd1YXJhbnRlZScsXHJcbiAgICAgICAgJ0R5bmFtaWMgYXV0by1kZWNsaW5lIHRocmVzaG9sZCB0dW5pbmcnLFxyXG4gICAgICAgICdDU1YgJiByZXBvcnQgZXhwb3J0IHRvb2xzICgzMC1kYXkgbG9ncyknLFxyXG4gICAgICAgICdTdGFuZGFyZCBlbWFpbCAmIGNoYXQgc3VwcG9ydCcsXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBuYW1lOiAnTGlmZXRpbWUnLFxyXG4gICAgICBpZDogJ3BsYW4tbGlmZXRpbWUnLFxyXG4gICAgICBwcmljZU1vbnRobHk6ICckMjAwJyxcclxuICAgICAgcHJpY2VBbm51YWw6ICckMjAwJyxcclxuICAgICAgcGVyaW9kOiAnb25lLXRpbWUgcGF5JyxcclxuICAgICAgZGVzY3JpcHRpb246ICdQYXkgb25jZSwgcHJvdGVjdCBmb3JldmVyLiBVbmxpbWl0ZWQgYWNjZXNzIGZvciBzY2FsZS11cHMgYW5kIGZvdW5kZXJzLicsXHJcbiAgICAgIGhpZ2hsaWdodDogZmFsc2UsXHJcbiAgICAgIGJhZGdlOiAnQkVTVCBWQUxVRScsXHJcbiAgICAgIGN0YVRleHQ6ICdHZXQgTGlmZXRpbWUgQWNjZXNzJyxcclxuICAgICAgY3RhU3R5bGU6ICdiZy1bIzIxMDA1RF0gaG92ZXI6YmctWyMxNTAwM2JdIHRleHQtd2hpdGUgc2hhZG93LW1kJyxcclxuICAgICAgZmVhdHVyZXM6IFtcclxuICAgICAgICAnVW5saW1pdGVkIG1vbnRobHkgdHJhbnNhY3Rpb25zJyxcclxuICAgICAgICAnUHJpb3JpdHkgWEdCb29zdCBNTCBNb2RlbCBleGVjdXRpb24nLFxyXG4gICAgICAgICdVbHRyYS1sb3cgbGF0ZW5jeSBpbmZyYXN0cnVjdHVyZSAoPDMwbXMgU0xBKScsXHJcbiAgICAgICAgJ1VubGltaXRlZCBoaXN0b3JpY2FsIHRyYW5zYWN0aW9uIGxvZ3MnLFxyXG4gICAgICAgICdDdXN0b20gcmlzayBydWxlIGNvbmZpZ3VyYXRpb24nLFxyXG4gICAgICAgICcyNC83IFByaW9yaXR5IGRldmVsb3BlciBzdXBwb3J0JyxcclxuICAgICAgICAnQWxsIGZ1dHVyZSBNTCBtb2RlbCB1cGRhdGVzIGluY2x1ZGVkJyxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWdyYXktNTAgcHktMTIgcHgtNCBzbTpweC02IGxnOnB4LThcIj5cclxuICAgICAgey8qIEhlYWRlciBTZWN0aW9uICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTR4bCBteC1hdXRvIHRleHQtY2VudGVyIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtWyM2NzUwQTRdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgYmctWyNFOERFRjhdIHB4LTMgcHktMSByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgIFRyYW5zcGFyZW50IFByaWNpbmdcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRleHQtWyMyMTAwNURdIHNtOnRleHQtNXhsXCI+XHJcbiAgICAgICAgICBTaW1wbGUsIFByZWRpY3RpdmUgRnJhdWQgUHJldmVudGlvblxyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHRleHQtZ3JheS02MDAgbWF4LXctMnhsIG14LWF1dG9cIj5cclxuICAgICAgICAgIFNjYWxlIHlvdXIgY2hlY2tvdXQgd2l0aG91dCBoaWdoIGNoYXJnZWJhY2sgZmVlcy48YnIvPlByb3RlY3QgeW91ciBzdG9yZSB1c2luZyByZWFsLXRpbWUgTUwgcmlzayBzY29yaW5nLlxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgey8qIE1vbnRobHkgLyBBbm51YWwgVG9nZ2xlICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtiaWxsaW5nQ3ljbGUgPT09ICdtb250aGx5JyA/ICd0ZXh0LWdyYXktOTAwIGZvbnQtc2VtaWJvbGQnIDogJ3RleHQtZ3JheS01MDAnfWB9PlxyXG4gICAgICAgICAgICBNb250aGx5IEJpbGxpbmdcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJpbGxpbmdDeWNsZShiaWxsaW5nQ3ljbGUgPT09ICdtb250aGx5JyA/ICdhbm51YWwnIDogJ21vbnRobHknKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggaC02IHctMTEgZmxleC1zaHJpbmstMCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLVsjNjc1MEE0XSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgZWFzZS1pbi1vdXQgZm9jdXM6b3V0bGluZS1ub25lXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bwb2ludGVyLWV2ZW50cy1ub25lIGlubGluZS1ibG9jayBoLTUgdy01IHRyYW5zZm9ybSByb3VuZGVkLWZ1bGwgYmctd2hpdGUgc2hhZG93IHJpbmctMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBlYXNlLWluLW91dCAke1xyXG4gICAgICAgICAgICAgICAgYmlsbGluZ0N5Y2xlID09PSAnYW5udWFsJyA/ICd0cmFuc2xhdGUteC01JyA6ICd0cmFuc2xhdGUteC0wJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbWVkaXVtICR7YmlsbGluZ0N5Y2xlID09PSAnYW5udWFsJyA/ICd0ZXh0LWdyYXktOTAwIGZvbnQtc2VtaWJvbGQnIDogJ3RleHQtZ3JheS01MDAnfWB9PlxyXG4gICAgICAgICAgICBBbm51YWwgQmlsbGluZyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC02MDAgZm9udC1ib2xkIGJnLWVtZXJhbGQtMTAwIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBtbC0xXCI+U2F2ZSAyMCU8L3NwYW4+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFByaWNpbmcgQ2FyZHMgR3JpZCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBtdC0xMiBncmlkIGdyaWQtY29scy0xIGdhcC04IGxnOmdyaWQtY29scy0zIGxnOmdhcC02IGl0ZW1zLXN0cmV0Y2hcIj5cclxuICAgICAgICB7cGxhbnMubWFwKChwbGFuKSA9PiB7XHJcbiAgICAgICAgICAvLyBDaGVjayBpZiB0aGlzIGNhcmQgcmVwcmVzZW50cyB0aGUgbG9nZ2VkLWluIHVzZXIncyBhY3RpdmUgdGllclxyXG4gICAgICAgICAgY29uc3QgaXNDdXJyZW50UGxhbiA9IGlzQXV0aGVudGljYXRlZCAmJiBwbGFuLmlkID09PSAncGxhbi1mcmVlJztcclxuICAgICAgICAgIGNvbnN0IGJ1dHRvblRleHQgPSBpc0N1cnJlbnRQbGFuID8gJ1lvdXIgQ3VycmVudCBQbGFuJyA6IHBsYW4uY3RhVGV4dDtcclxuICAgICAgICAgIGNvbnN0IGJ1dHRvblN0eWxlID0gaXNDdXJyZW50UGxhblxyXG4gICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtODAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0zMDAgZm9udC1ib2xkIGN1cnNvci1kZWZhdWx0J1xyXG4gICAgICAgICAgICA6IHBsYW4uY3RhU3R5bGU7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGtleT17cGxhbi5pZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSByb3VuZGVkLTJ4bCBiZy13aGl0ZSBwLTggc2hhZG93LXNtIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgIHBsYW4uaGlnaGxpZ2h0XHJcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci0yIGJvcmRlci1bIzY3NTBBNF0gc2hhZG93LXhsIHNjYWxlLTEwNSB6LTEwJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdib3JkZXItZ3JheS0yMDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgey8qIFRvcCBCYWRnZSAqL31cclxuICAgICAgICAgICAgICB7cGxhbi5iYWRnZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMy41IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC13aGl0ZSBweC0zIHB5LTEgcm91bmRlZC1mdWxsICR7XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhbi5oaWdobGlnaHQgPyAnYmctWyM2NzUwQTRdJyA6ICdiZy1bIzIxMDA1RF0nXHJcbiAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICB7cGxhbi5iYWRnZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIHsvKiBDYXJkIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtWyMyMTAwNURdXCI+e3BsYW4ubmFtZX08L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbWluLWgtWzM2cHhdIG1iLTZcIj57cGxhbi5kZXNjcmlwdGlvbn08L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFByaWNpbmcgRGlzcGxheSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2JpbGxpbmdDeWNsZSA9PT0gJ2FubnVhbCcgPyBwbGFuLnByaWNlQW5udWFsIDogcGxhbi5wcmljZU1vbnRobHl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1sLTFcIj57cGxhbi5wZXJpb2R9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEZlYXR1cmUgTGlzdCAqL31cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTMgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICB7cGxhbi5mZWF0dXJlcy5tYXAoKGZlYXR1cmUsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTMgdGV4dC14cyB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1lbWVyYWxkLTUwMCBmbGV4LXNocmluay0wIG10LTAuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNNSAxM2w0IDRMMTkgN1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntmZWF0dXJlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEeW5hbWljIENUQSBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDdXJyZW50UGxhbn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGlzQ3VycmVudFBsYW4pIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgaWYgKG9uTmF2aWdhdGUpIG9uTmF2aWdhdGUoJ3JlZ2lzdGVyJyk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtY2VudGVyIHRleHQteHMgZm9udC1ib2xkIHB5LTMgcHgtNCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzICR7YnV0dG9uU3R5bGV9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7YnV0dG9uVGV4dH1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUcnVzdCAmIEZBUSBGb290ZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctM3hsIG14LWF1dG8gbXQtMTYgdGV4dC1jZW50ZXIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHB0LThcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPk5lZWQgYSBjdXN0b20gZW50ZXJwcmlzZSBpbnRlZ3JhdGlvbj88L2gzPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtYi00XCI+XHJcbiAgICAgICAgICBXZSBvZmZlciBkZWRpY2F0ZWQgVlBDIGRlcGxveW1lbnRzLCBjdXN0b20gTUwgcmV0cmFpbiBzY2hlZHVsZXMsIGFuZCB0YWlsb3JlZCBlbnRlcnByaXNlIFNMQXMuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxhIGhyZWY9XCJtYWlsdG86c3VwcG9ydEBmcmF1ZGZsdXguaW9cIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjNjc1MEE0XSBob3Zlcjp1bmRlcmxpbmVcIj5cclxuICAgICAgICAgIENvbnRhY3QgRW50ZXJwcmlzZSBTYWxlcyDihpJcclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSJdfQ==