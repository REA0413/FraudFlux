import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import { supabase } from "/src/lib/supabaseClient.js";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/context/AuthContext.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext();
_c = AuthContext;
export const AuthProvider = ({ children }) => {
	_s();
	const [user, setUser] = useState(null);
	const [session, setSession] = useState(null);
	const [merchantSettings, setMerchantSettings] = useState(null);
	const [loading, setLoading] = useState(true);
	// Fetch Merchant Settings from 'merchants' table
	const fetchMerchantSettings = async (userId) => {
		try {
			const { data, error } = await supabase.from("merchants").select("*").eq("id", userId).single();
			if (error && error.code !== "PGRST116") {
				console.error("Error fetching merchant profile:", error.message);
			} else if (data) {
				setMerchantSettings(data);
			}
		} catch (err) {
			console.error("Unexpected error fetching settings:", err);
		}
	};
	useEffect(() => {
		// Check initial session
		supabase.auth.getSession().then(({ data: { session } }) => {
			setSession(session);
			setUser(session?.user ?? null);
			if (session?.user) fetchMerchantSettings(session.user.id);
			setLoading(false);
		});
		// Listen for auth changes (Login, Logout, Sign Up)
		const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
			setSession(session);
			setUser(session?.user ?? null);
			if (session?.user) {
				fetchMerchantSettings(session.user.id);
			} else {
				setMerchantSettings(null);
			}
			setLoading(false);
		});
		return () => subscription.unsubscribe();
	}, []);
	// Register New Merchant
	const register = async (email, password, merchantName) => {
		const { data, error } = await supabase.auth.signUp({
			email,
			password,
			options: { data: { merchant_name: merchantName } }
		});
		if (error) throw error;
		return data;
	};
	// Login
	const login = async (email, password) => {
		const { data, error } = await supabase.auth.signInWithPassword({
			email,
			password
		});
		if (error) throw error;
		return data;
	};
	// Logout
	const logout = async () => {
		const { error } = await supabase.auth.signOut();
		if (error) throw error;
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			user,
			session,
			merchantSettings,
			loading,
			login,
			register,
			logout,
			fetchMerchantSettings
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 86,
		columnNumber: 5
	}, this);
};
_s(AuthProvider, "igZAoPtFORA64tQWfhned0Xhp/c=");
_c2 = AuthProvider;
export const useAuth = () => {
	_s2();
	return useContext(AuthContext);
};
_s2(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/context/AuthContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsWUFBWSxVQUFVLGlCQUFpQjtBQUN0RSxTQUFTLGdCQUFnQjs7OztBQUV6QixNQUFNLGNBQWMsY0FBYzs7QUFFbEMsT0FBTyxNQUFNLGdCQUFnQixFQUFFLGVBQWU7O0NBQzVDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsSUFBSTtDQUM3RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTs7Q0FHM0MsTUFBTSx3QkFBd0IsT0FBTyxXQUFXO0VBQzlDLElBQUk7R0FDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxXQUFXLENBQUMsQ0FDakIsT0FBTyxHQUFHLENBQUMsQ0FDWCxHQUFHLE1BQU0sTUFBTSxDQUFDLENBQ2hCLE9BQU87R0FFVixJQUFJLFNBQVMsTUFBTSxTQUFTLFlBQVk7SUFDdEMsUUFBUSxNQUFNLG9DQUFvQyxNQUFNLE9BQU87R0FDakUsT0FBTyxJQUFJLE1BQU07SUFDZixvQkFBb0IsSUFBSTtHQUMxQjtFQUNGLFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSx1Q0FBdUMsR0FBRztFQUMxRDtDQUNGO0NBRUEsZ0JBQWdCOztFQUVkLFNBQVMsS0FBSyxXQUFXLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLGdCQUFnQjtHQUN6RCxXQUFXLE9BQU87R0FDbEIsUUFBUSxTQUFTLFFBQVEsSUFBSTtHQUM3QixJQUFJLFNBQVMsTUFBTSxzQkFBc0IsUUFBUSxLQUFLLEVBQUU7R0FDeEQsV0FBVyxLQUFLO0VBQ2xCLENBQUM7O0VBR0QsTUFBTSxFQUFFLE1BQU0sRUFBRSxtQkFBbUIsU0FBUyxLQUFLLG1CQUFtQixRQUFRLFlBQVk7R0FDdEYsV0FBVyxPQUFPO0dBQ2xCLFFBQVEsU0FBUyxRQUFRLElBQUk7R0FDN0IsSUFBSSxTQUFTLE1BQU07SUFDakIsc0JBQXNCLFFBQVEsS0FBSyxFQUFFO0dBQ3ZDLE9BQU87SUFDTCxvQkFBb0IsSUFBSTtHQUMxQjtHQUNBLFdBQVcsS0FBSztFQUNsQixDQUFDO0VBRUQsYUFBYSxhQUFhLFlBQVk7Q0FDeEMsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxXQUFXLE9BQU8sT0FBTyxVQUFVLGlCQUFpQjtFQUN4RCxNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLE9BQU87R0FDakQ7R0FDQTtHQUNBLFNBQVMsRUFDUCxNQUFNLEVBQ0osZUFBZSxhQUNqQixFQUNGO0VBQ0YsQ0FBQztFQUVELElBQUksT0FBTyxNQUFNO0VBRWpCLE9BQU87Q0FDVDs7Q0FHQSxNQUFNLFFBQVEsT0FBTyxPQUFPLGFBQWE7RUFDdkMsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxtQkFBbUI7R0FBRTtHQUFPO0VBQVMsQ0FBQztFQUNsRixJQUFJLE9BQU8sTUFBTTtFQUNqQixPQUFPO0NBQ1Q7O0NBR0EsTUFBTSxTQUFTLFlBQVk7RUFDekIsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUFTLEtBQUssUUFBUTtFQUM5QyxJQUFJLE9BQU8sTUFBTTtDQUNuQjtDQUVBLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQ0UsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUVDO0NBQ21COzs7OztBQUUxQjs7O0FBRUEsT0FBTyxNQUFNLGdCQUFnQjs7bUJBQVcsV0FBVyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSAnLi4vbGliL3N1cGFiYXNlQ2xpZW50JztcclxuXHJcbmNvbnN0IEF1dGhDb250ZXh0ID0gY3JlYXRlQ29udGV4dCgpO1xyXG5cclxuZXhwb3J0IGNvbnN0IEF1dGhQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2Vzc2lvbiwgc2V0U2Vzc2lvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbWVyY2hhbnRTZXR0aW5ncywgc2V0TWVyY2hhbnRTZXR0aW5nc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgLy8gRmV0Y2ggTWVyY2hhbnQgU2V0dGluZ3MgZnJvbSAnbWVyY2hhbnRzJyB0YWJsZVxyXG4gIGNvbnN0IGZldGNoTWVyY2hhbnRTZXR0aW5ncyA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgLmZyb20oJ21lcmNoYW50cycpXHJcbiAgICAgICAgLnNlbGVjdCgnKicpXHJcbiAgICAgICAgLmVxKCdpZCcsIHVzZXJJZClcclxuICAgICAgICAuc2luZ2xlKCk7XHJcblxyXG4gICAgICBpZiAoZXJyb3IgJiYgZXJyb3IuY29kZSAhPT0gJ1BHUlNUMTE2Jykge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGZldGNoaW5nIG1lcmNoYW50IHByb2ZpbGU6JywgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoZGF0YSkge1xyXG4gICAgICAgIHNldE1lcmNoYW50U2V0dGluZ3MoZGF0YSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdVbmV4cGVjdGVkIGVycm9yIGZldGNoaW5nIHNldHRpbmdzOicsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIENoZWNrIGluaXRpYWwgc2Vzc2lvblxyXG4gICAgc3VwYWJhc2UuYXV0aC5nZXRTZXNzaW9uKCkudGhlbigoeyBkYXRhOiB7IHNlc3Npb24gfSB9KSA9PiB7XHJcbiAgICAgIHNldFNlc3Npb24oc2Vzc2lvbik7XHJcbiAgICAgIHNldFVzZXIoc2Vzc2lvbj8udXNlciA/PyBudWxsKTtcclxuICAgICAgaWYgKHNlc3Npb24/LnVzZXIpIGZldGNoTWVyY2hhbnRTZXR0aW5ncyhzZXNzaW9uLnVzZXIuaWQpO1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIExpc3RlbiBmb3IgYXV0aCBjaGFuZ2VzIChMb2dpbiwgTG9nb3V0LCBTaWduIFVwKVxyXG4gICAgY29uc3QgeyBkYXRhOiB7IHN1YnNjcmlwdGlvbiB9IH0gPSBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChfZXZlbnQsIHNlc3Npb24pID0+IHtcclxuICAgICAgc2V0U2Vzc2lvbihzZXNzaW9uKTtcclxuICAgICAgc2V0VXNlcihzZXNzaW9uPy51c2VyID8/IG51bGwpO1xyXG4gICAgICBpZiAoc2Vzc2lvbj8udXNlcikge1xyXG4gICAgICAgIGZldGNoTWVyY2hhbnRTZXR0aW5ncyhzZXNzaW9uLnVzZXIuaWQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldE1lcmNoYW50U2V0dGluZ3MobnVsbCk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gKCkgPT4gc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBSZWdpc3RlciBOZXcgTWVyY2hhbnRcclxuICBjb25zdCByZWdpc3RlciA9IGFzeW5jIChlbWFpbCwgcGFzc3dvcmQsIG1lcmNoYW50TmFtZSkgPT4ge1xyXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduVXAoe1xyXG4gICAgICBlbWFpbCxcclxuICAgICAgcGFzc3dvcmQsXHJcbiAgICAgIG9wdGlvbnM6IHtcclxuICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICBtZXJjaGFudF9uYW1lOiBtZXJjaGFudE5hbWUsIC8vIFNlbmQgbWV0YWRhdGEgdG8gU3VwYWJhc2UgQXV0aFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG5cclxuICAgIHJldHVybiBkYXRhO1xyXG4gIH07XHJcblxyXG4gIC8vIExvZ2luXHJcbiAgY29uc3QgbG9naW4gPSBhc3luYyAoZW1haWwsIHBhc3N3b3JkKSA9PiB7XHJcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7IGVtYWlsLCBwYXNzd29yZCB9KTtcclxuICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICByZXR1cm4gZGF0YTtcclxuICB9O1xyXG5cclxuICAvLyBMb2dvdXRcclxuICBjb25zdCBsb2dvdXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKTtcclxuICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlclxyXG4gICAgICB2YWx1ZT17e1xyXG4gICAgICAgIHVzZXIsXHJcbiAgICAgICAgc2Vzc2lvbixcclxuICAgICAgICBtZXJjaGFudFNldHRpbmdzLFxyXG4gICAgICAgIGxvYWRpbmcsXHJcbiAgICAgICAgbG9naW4sXHJcbiAgICAgICAgcmVnaXN0ZXIsXHJcbiAgICAgICAgbG9nb3V0LFxyXG4gICAgICAgIGZldGNoTWVyY2hhbnRTZXR0aW5ncyxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHVzZUF1dGggPSAoKSA9PiB1c2VDb250ZXh0KEF1dGhDb250ZXh0KTsiXX0=