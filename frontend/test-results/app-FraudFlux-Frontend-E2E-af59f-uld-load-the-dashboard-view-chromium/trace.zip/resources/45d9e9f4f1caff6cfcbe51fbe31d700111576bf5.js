import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=51adfdae";
import Dashboard from "/src/Dashboard.jsx";
import Login from "/src/Login.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import LandingPage from "/src/LandingPage.jsx";
import Register from "/src/Register.jsx";
import MerchantSettings from "/src/MerchantSettings.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=51adfdae";
var _s = $RefreshSig$();
export default function App() {
	_s();
	const { user, logout, loading } = useAuth();
	const [authView, setAuthView] = useState("landing");
	const [activeTab, setActiveTab] = useState("dashboard");
	const [transactions, setTransactions] = useState([]);
	// New State for the ML Sandbox
	const [mlData, setMlData] = useState({
		amt: 1500,
		city_pop: 85e3,
		zip: 10001
	});
	const [predictionResult, setPredictionResult] = useState(null);
	const [isPredicting, setIsPredicting] = useState(false);
	// Fetch the live database data
	useEffect(() => {
		if (!user) return;
		const fetchTransactions = async () => {
			try {
				const response = await fetch("http://localhost:8000/api/v1/transactions");
				const data = await response.json();
				if (Array.isArray(data)) setTransactions(data);
			} catch (error) {
				console.error("Error fetching live transactions:", error);
			}
		};
		fetchTransactions();
	}, [user]);
	// Function to call the ML Model
	const handlePredict = async (e) => {
		e.preventDefault();
		setIsPredicting(true);
		setPredictionResult(null);
		try {
			const response = await fetch("http://localhost:8000/predict", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					amt: parseFloat(mlData.amt),
					city_pop: parseInt(mlData.city_pop),
					zip: parseInt(mlData.zip)
				})
			});
			const data = await response.json();
			setPredictionResult(data.is_fraud);
		} catch (error) {
			console.error("Error asking AI for prediction:", error);
		} finally {
			setIsPredicting(false);
		}
	};
	// 1. Show Loading State while Supabase checks session
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "h-screen flex items-center justify-center bg-gray-50 text-[#21005D]",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-lg font-semibold animate-pulse",
				children: "Loading FraudFlux Session..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 7
		}, this);
	}
	// 2. Show Public Landing Page or Login Screen if User is NOT Authenticated
	if (!user) {
		if (authView === "login") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAuthView("landing"),
					className: "absolute top-6 left-6 text-white text-sm hover:underline z-10 bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-md",
					children: "← Back to Home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this);
		}
		if (authView === "register") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAuthView("landing"),
					className: "absolute top-6 left-6 text-white text-sm hover:underline z-10 bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-md",
					children: "← Back to Home"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Register, { onSwitchToLogin: () => setAuthView("login") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV(LandingPage, { onNavigate: (view) => setAuthView(view) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 12
		}, this);
	}
	// 3. Render Main Application if Authenticated
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen flex flex-col bg-gray-50 font-sans",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "bg-[#21005D] text-white h-14 flex items-center justify-between px-6 shrink-0 shadow-md",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-8 h-8 rounded-full bg-[#E8DEF8] text-[#21005D] flex items-center justify-center font-bold text-sm",
					children: "FF"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "font-semibold text-lg tracking-wide",
					children: "Fraud Flux"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-4",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs bg-[#6750A4] px-3 py-1 rounded-full text-white font-medium",
					children: user.email
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: logout,
					className: "text-xs bg-red-600 hover:bg-red-700 px-3 py-1.5 rounded font-medium transition-colors",
					children: "Sign Out"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 109,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-1 overflow-hidden",
			children: [/* @__PURE__ */ _jsxDEV("aside", {
				className: "w-64 bg-white border-r border-gray-200 p-6 shrink-0 flex flex-col",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-bold mb-6 text-gray-800",
					children: "Menu"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("nav", {
					className: "space-y-2 text-sm font-medium flex-1",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("dashboard"),
							className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "dashboard" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
							children: "Overview"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("operations"),
							className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "operations" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
							children: "Operations Desk"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("settings"),
							className: `w-full text-left px-4 py-3 rounded-md transition-colors ${activeTab === "settings" ? "bg-[#E8DEF8] text-[#21005D] border-l-4 border-[#6750A4]" : "text-gray-600 hover:bg-gray-50 hover:text-[#6750A4]"}`,
							children: "Risk Controls"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 overflow-y-auto",
				children: [
					activeTab === "dashboard" && /* @__PURE__ */ _jsxDEV(Dashboard, { transactions }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 13
					}, this),
					activeTab === "operations" && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-10 max-w-6xl mx-auto",
						children: [
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl font-bold mb-6 text-[#21005D]",
								children: "Operations Desk"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8",
								children: [
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-semibold text-gray-800 mb-4",
										children: "Live ML Prediction Sandbox"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handlePredict,
										className: "flex items-end space-x-4",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-medium text-gray-600",
													children: "Amount ($)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 174,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													step: "0.01",
													required: true,
													className: "border border-gray-300 rounded px-3 py-2 w-32 focus:outline-none focus:border-[#6750A4]",
													value: mlData.amt,
													onChange: (e) => setMlData({
														...mlData,
														amt: e.target.value
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 175,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 173,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-medium text-gray-600",
													children: "City Population"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 178,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													required: true,
													className: "border border-gray-300 rounded px-3 py-2 w-40 focus:outline-none focus:border-[#6750A4]",
													value: mlData.city_pop,
													onChange: (e) => setMlData({
														...mlData,
														city_pop: e.target.value
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 179,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 177,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-medium text-gray-600",
													children: "Zip Code"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 182,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													required: true,
													className: "border border-gray-300 rounded px-3 py-2 w-32 focus:outline-none focus:border-[#6750A4]",
													value: mlData.zip,
													onChange: (e) => setMlData({
														...mlData,
														zip: e.target.value
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 183,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 181,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												disabled: isPredicting,
												className: "bg-[#6750A4] text-white px-5 py-2 rounded font-medium hover:bg-[#533f85] transition-colors disabled:opacity-50",
												children: isPredicting ? "Analyzing..." : "Test AI Model"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 185,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 17
									}, this),
									predictionResult !== null && /* @__PURE__ */ _jsxDEV("div", {
										className: `mt-6 p-4 rounded-md border ${predictionResult === 1 ? "bg-red-50 border-red-200" : "bg-green-50 border-green-200"}`,
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: `font-bold text-lg ${predictionResult === 1 ? "text-red-700" : "text-green-700"}`,
											children: ["AI Decision: ", predictionResult === 1 ? "🚨 FRAUD DETECTED (1)" : "✅ NORMAL TRANSACTION (0)"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm text-gray-600 mt-1",
											children: "Based on XGBoost model evaluation of amount, population, and zip code."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-semibold text-gray-800 mb-4",
								children: "Recent Database Transactions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-left text-sm",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-[#E8DEF8] text-[#21005D]",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-4 font-semibold",
												children: "Transaction ID"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 207,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-4 font-semibold",
												children: "User Email"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 208,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-4 font-semibold",
												children: "Amount"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 209,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-4 font-semibold",
												children: "Risk Score"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 210,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-4 font-semibold",
												children: "Decision"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 211,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 205,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [transactions.map((tx, index) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-gray-100 hover:bg-gray-50",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-4 font-medium text-[#6750A4]",
												children: tx.transaction_id
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 217,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-4 text-gray-700",
												children: tx.customer_email
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 218,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-4 text-gray-700",
												children: ["$", tx.amount?.toFixed(2)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 219,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-4",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `px-2 py-1 rounded text-xs font-bold ${tx.risk_score >= .5 ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`,
													children: tx.risk_score
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 221,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 220,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-4 text-gray-700 font-medium",
												children: tx.decision
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 225,
												columnNumber: 25
											}, this)
										]
									}, tx.transaction_id || index, true, {
										fileName: _jsxFileName,
										lineNumber: 216,
										columnNumber: 23
									}, this)), transactions.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
										colSpan: "5",
										className: "p-8 text-center text-gray-500",
										children: "Loading live data or no transactions found..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 25
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 229,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 13
					}, this),
					activeTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-10 max-w-6xl mx-auto",
						children: /* @__PURE__ */ _jsxDEV(MerchantSettings, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 157,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 129,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 106,
		columnNumber: 5
	}, this);
}
_s(App, "FdwH1w/8sq10LgVzBsT/blqUjjQ=", false, function() {
	return [useAuth];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sZUFBZTtBQUN0QixPQUFPLFdBQVc7QUFDbEIsU0FBUyxlQUFlO0FBQ3hCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sY0FBYztBQUNyQixPQUFPLHNCQUFzQjs7OztBQUU3QixlQUFlLFNBQVMsTUFBTTs7Q0FDNUIsTUFBTSxFQUFFLE1BQU0sUUFBUSxZQUFZLFFBQVE7Q0FFMUMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLFNBQVM7Q0FDbEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsV0FBVztDQUN0RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxDQUFDLENBQUM7O0NBR25ELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUztFQUFFLEtBQUs7RUFBTSxVQUFVO0VBQU8sS0FBSztDQUFNLENBQUM7Q0FDL0UsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxJQUFJO0NBQzdELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7O0NBR3RELGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxvQkFBb0IsWUFBWTtHQUNwQyxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSwyQ0FBMkM7SUFDeEUsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0lBQ2pDLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxnQkFBZ0IsSUFBSTtHQUMvQyxTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0scUNBQXFDLEtBQUs7R0FDMUQ7RUFDRjtFQUNBLGtCQUFrQjtDQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDOztDQUdULE1BQU0sZ0JBQWdCLE9BQU8sTUFBTTtFQUNqQyxFQUFFLGVBQWU7RUFDakIsZ0JBQWdCLElBQUk7RUFDcEIsb0JBQW9CLElBQUk7RUFFeEIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0saUNBQWlDO0lBQzVELFFBQVE7SUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtJQUM5QyxNQUFNLEtBQUssVUFBVTtLQUNuQixLQUFLLFdBQVcsT0FBTyxHQUFHO0tBQzFCLFVBQVUsU0FBUyxPQUFPLFFBQVE7S0FDbEMsS0FBSyxTQUFTLE9BQU8sR0FBRztJQUMxQixDQUFDO0dBQ0gsQ0FBQztHQUNELE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxvQkFBb0IsS0FBSyxRQUFRO0VBQ25DLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxtQ0FBbUMsS0FBSztFQUN4RCxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjs7Q0FHQSxJQUFJLFNBQVM7RUFDWCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBc0M7R0FBK0I7Ozs7O0VBQy9FOzs7OztDQUVUOztDQUdBLElBQUksQ0FBQyxNQUFNO0VBQ1QsSUFBSSxhQUFhLFNBQVM7R0FDeEIsT0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLGVBQWUsWUFBWSxTQUFTO0tBQ3BDLFdBQVU7ZUFDWDtJQUVPOzs7O2NBQ1Isd0JBQUMsT0FBRCxDQUFROzs7O1lBQ0w7Ozs7OztFQUVUO0VBRUEsSUFBSSxhQUFhLFlBQVk7R0FDM0IsT0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLGVBQWUsWUFBWSxTQUFTO0tBQ3BDLFdBQVU7ZUFDWDtJQUVPOzs7O2NBQ1Isd0JBQUMsVUFBRCxFQUFVLHVCQUF1QixZQUFZLE9BQU8sRUFBSTs7OztZQUNyRDs7Ozs7O0VBRVQ7RUFFQSxPQUFPLHdCQUFDLGFBQUQsRUFBYSxhQUFhLFNBQVMsWUFBWSxJQUFJLEVBQUk7Ozs7O0NBQ2hFOztDQUdBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUdFLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO2FBQWxCLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQXNHO0lBQU87Ozs7Y0FDNUgsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBc0M7SUFBZ0I7Ozs7WUFDbkU7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2IsS0FBSztJQUNGOzs7O2NBQ04sd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7OztXQUNDOzs7OztZQUVSLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXVDO0lBQVE7Ozs7Y0FDN0Qsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsV0FBVztPQUN2QyxXQUFXLDJEQUEyRCxjQUFjLGNBQWMsNERBQTREO2lCQUMvSjtNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsWUFBWTtPQUN4QyxXQUFXLDJEQUEyRCxjQUFjLGVBQWUsNERBQTREO2lCQUNoSztNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsVUFBVTtPQUN0QyxXQUFXLDJEQUEyRCxjQUFjLGFBQWEsNERBQTREO2lCQUM5SjtNQUVPOzs7OztLQUNMOzs7OztZQUNBOzs7OzthQUdQLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBR0csY0FBYyxlQUNiLHdCQUFDLFdBQUQsRUFBeUIsYUFBZTs7Ozs7S0FJekMsY0FBYyxnQkFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF5QztPQUFtQjs7Ozs7T0FHMUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBMkM7U0FBOEI7Ozs7O1NBQ3ZGLHdCQUFDLFFBQUQ7VUFBTSxVQUFVO1VBQWUsV0FBVTtvQkFBekM7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFvQztZQUFpQjs7OztzQkFDdEUsd0JBQUMsU0FBRDthQUFPLE1BQUs7YUFBUyxNQUFLO2FBQU87YUFBUyxXQUFVO2FBQTBGLE9BQU8sT0FBTzthQUFLLFdBQVcsTUFBTSxVQUFVO2NBQUMsR0FBRztjQUFRLEtBQUssRUFBRSxPQUFPO2FBQUssQ0FBQztZQUFJOzs7O29CQUM3Tjs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBb0M7WUFBc0I7Ozs7c0JBQzNFLHdCQUFDLFNBQUQ7YUFBTyxNQUFLO2FBQVM7YUFBUyxXQUFVO2FBQTBGLE9BQU8sT0FBTzthQUFVLFdBQVcsTUFBTSxVQUFVO2NBQUMsR0FBRztjQUFRLFVBQVUsRUFBRSxPQUFPO2FBQUssQ0FBQztZQUFJOzs7O29CQUMzTjs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBb0M7WUFBZTs7OztzQkFDcEUsd0JBQUMsU0FBRDthQUFPLE1BQUs7YUFBUzthQUFTLFdBQVU7YUFBMEYsT0FBTyxPQUFPO2FBQUssV0FBVyxNQUFNLFVBQVU7Y0FBQyxHQUFHO2NBQVEsS0FBSyxFQUFFLE9BQU87YUFBSyxDQUFDO1lBQUk7Ozs7b0JBQ2pOOzs7Ozs7V0FDTCx3QkFBQyxVQUFEO1lBQVEsTUFBSztZQUFTLFVBQVU7WUFBYyxXQUFVO3NCQUNyRCxlQUFlLGlCQUFpQjtXQUMzQjs7Ozs7VUFDSjs7Ozs7O1NBR0wscUJBQXFCLFFBQ3BCLHdCQUFDLE9BQUQ7VUFBSyxXQUFXLDhCQUE4QixxQkFBcUIsSUFBSSw2QkFBNkI7b0JBQXBHLENBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVcscUJBQXFCLHFCQUFxQixJQUFJLGlCQUFpQjtxQkFBOUUsQ0FBa0csaUJBQ2xGLHFCQUFxQixJQUFJLDBCQUEwQiwwQkFDL0Q7Ozs7O29CQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE2QjtVQUF5RTs7OztrQkFDaEg7Ozs7OztRQUVKOzs7Ozs7T0FHTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMkM7T0FBZ0M7Ozs7O09BQ3pGLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNmLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBb0I7V0FBa0I7Ozs7O1dBQ3BELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFvQjtXQUFjOzs7OztXQUNoRCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBb0I7V0FBVTs7Ozs7V0FDNUMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW9CO1dBQWM7Ozs7O1dBQ2hELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFvQjtXQUFZOzs7OztVQUM1Qzs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFELGFBQ0csYUFBYSxLQUFLLElBQUksVUFDckIsd0JBQUMsTUFBRDtVQUFxQyxXQUFVO29CQUEvQztXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFrQyxHQUFHO1dBQW1COzs7OztXQUN0RSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBcUIsR0FBRztXQUFtQjs7Ozs7V0FDekQsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FBa0MsS0FBRSxHQUFHLFFBQVEsUUFBUSxDQUFDLENBQU07Ozs7OztXQUM5RCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxRQUFEO2FBQU0sV0FBVyx1Q0FBdUMsR0FBRyxjQUFjLEtBQU0sNEJBQTRCO3VCQUN4RyxHQUFHO1lBQ0E7Ozs7O1dBQ0o7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWlDLEdBQUc7V0FBYTs7Ozs7VUFDN0Q7WUFWSyxHQUFHLGtCQUFrQjs7OztnQkFVMUIsQ0FDTCxHQUNBLGFBQWEsV0FBVyxLQUN2Qix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtVQUFJLFNBQVE7VUFBSSxXQUFVO29CQUFnQztTQUV0RDs7OztrQkFDRjs7OztpQkFFRDs7OztpQkFDRjs7Ozs7O09BQ0o7Ozs7O01BQ0Y7Ozs7OztLQUlOLGNBQWMsY0FDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7S0FDaEI7Ozs7O0lBR0g7Ozs7O1dBQ0g7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgRGFzaGJvYXJkIGZyb20gJy4vRGFzaGJvYXJkJztcbmltcG9ydCBMb2dpbiBmcm9tICcuL0xvZ2luJzsgLy8gSW1wb3J0IExvZ2luIGNvbXBvbmVudFxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCc7IC8vIEltcG9ydCB1c2VBdXRoIGhvb2tcbmltcG9ydCBMYW5kaW5nUGFnZSBmcm9tICcuL0xhbmRpbmdQYWdlJztcbmltcG9ydCBSZWdpc3RlciBmcm9tICcuL1JlZ2lzdGVyJztcbmltcG9ydCBNZXJjaGFudFNldHRpbmdzIGZyb20gJy4vTWVyY2hhbnRTZXR0aW5ncyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQsIGxvYWRpbmcgfSA9IHVzZUF1dGgoKTsgLy8gQXV0aCBzdGF0ZVxuXG4gIGNvbnN0IFthdXRoVmlldywgc2V0QXV0aFZpZXddID0gdXNlU3RhdGUoJ2xhbmRpbmcnKTtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdkYXNoYm9hcmQnKTtcbiAgY29uc3QgW3RyYW5zYWN0aW9ucywgc2V0VHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcblxuICAvLyBOZXcgU3RhdGUgZm9yIHRoZSBNTCBTYW5kYm94XG4gIGNvbnN0IFttbERhdGEsIHNldE1sRGF0YV0gPSB1c2VTdGF0ZSh7IGFtdDogMTUwMCwgY2l0eV9wb3A6IDg1MDAwLCB6aXA6IDEwMDAxIH0pO1xuICBjb25zdCBbcHJlZGljdGlvblJlc3VsdCwgc2V0UHJlZGljdGlvblJlc3VsdF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2lzUHJlZGljdGluZywgc2V0SXNQcmVkaWN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBGZXRjaCB0aGUgbGl2ZSBkYXRhYmFzZSBkYXRhXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF1c2VyKSByZXR1cm47IC8vIE9ubHkgZmV0Y2ggaWYgdXNlciBpcyBsb2dnZWQgaW5cbiAgICBcbiAgICBjb25zdCBmZXRjaFRyYW5zYWN0aW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hcGkvdjEvdHJhbnNhY3Rpb25zJyk7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSBzZXRUcmFuc2FjdGlvbnMoZGF0YSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbGl2ZSB0cmFuc2FjdGlvbnM6XCIsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGZldGNoVHJhbnNhY3Rpb25zKCk7XG4gIH0sIFt1c2VyXSk7XG5cbiAgLy8gRnVuY3Rpb24gdG8gY2FsbCB0aGUgTUwgTW9kZWxcbiAgY29uc3QgaGFuZGxlUHJlZGljdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldElzUHJlZGljdGluZyh0cnVlKTtcbiAgICBzZXRQcmVkaWN0aW9uUmVzdWx0KG51bGwpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9wcmVkaWN0Jywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBhbXQ6IHBhcnNlRmxvYXQobWxEYXRhLmFtdCksXG4gICAgICAgICAgY2l0eV9wb3A6IHBhcnNlSW50KG1sRGF0YS5jaXR5X3BvcCksXG4gICAgICAgICAgemlwOiBwYXJzZUludChtbERhdGEuemlwKVxuICAgICAgICB9KVxuICAgICAgfSk7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgc2V0UHJlZGljdGlvblJlc3VsdChkYXRhLmlzX2ZyYXVkKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFza2luZyBBSSBmb3IgcHJlZGljdGlvbjpcIiwgZXJyb3IpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1ByZWRpY3RpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyAxLiBTaG93IExvYWRpbmcgU3RhdGUgd2hpbGUgU3VwYWJhc2UgY2hlY2tzIHNlc3Npb25cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTUwIHRleHQtWyMyMTAwNURdXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBhbmltYXRlLXB1bHNlXCI+TG9hZGluZyBGcmF1ZEZsdXggU2Vzc2lvbi4uLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyAyLiBTaG93IFB1YmxpYyBMYW5kaW5nIFBhZ2Ugb3IgTG9naW4gU2NyZWVuIGlmIFVzZXIgaXMgTk9UIEF1dGhlbnRpY2F0ZWRcbiAgaWYgKCF1c2VyKSB7XG4gICAgaWYgKGF1dGhWaWV3ID09PSAnbG9naW4nKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QXV0aFZpZXcoJ2xhbmRpbmcnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC02IGxlZnQtNiB0ZXh0LXdoaXRlIHRleHQtc20gaG92ZXI6dW5kZXJsaW5lIHotMTAgYmctd2hpdGUvMTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBiYWNrZHJvcC1ibHVyLW1kXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDihpAgQmFjayB0byBIb21lXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPExvZ2luIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoYXV0aFZpZXcgPT09ICdyZWdpc3RlcicpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBdXRoVmlldygnbGFuZGluZycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTYgbGVmdC02IHRleHQtd2hpdGUgdGV4dC1zbSBob3Zlcjp1bmRlcmxpbmUgei0xMCBiZy13aGl0ZS8xMCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJhY2tkcm9wLWJsdXItbWRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKGkCBCYWNrIHRvIEhvbWVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8UmVnaXN0ZXIgb25Td2l0Y2hUb0xvZ2luPXsoKSA9PiBzZXRBdXRoVmlldygnbG9naW4nKX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiA8TGFuZGluZ1BhZ2Ugb25OYXZpZ2F0ZT17KHZpZXcpID0+IHNldEF1dGhWaWV3KHZpZXcpfSAvPjtcbiAgfVxuXG4gIC8vIDMuIFJlbmRlciBNYWluIEFwcGxpY2F0aW9uIGlmIEF1dGhlbnRpY2F0ZWRcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImgtc2NyZWVuIGZsZXggZmxleC1jb2wgYmctZ3JheS01MCBmb250LXNhbnNcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBOYXZpZ2F0aW9uIEJhciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctWyMyMTAwNURdIHRleHQtd2hpdGUgaC0xNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBzaHJpbmstMCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLVsjRThERUY4XSB0ZXh0LVsjMjEwMDVEXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbVwiPkZGPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWxnIHRyYWNraW5nLXdpZGVcIj5GcmF1ZCBGbHV4PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVXNlciBJbmZvICYgTG9nb3V0IEJ1dHRvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTRcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLVsjNjc1MEE0XSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIHt1c2VyLmVtYWlsfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtsb2dvdXR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLXJlZC02MDAgaG92ZXI6YmctcmVkLTcwMCBweC0zIHB5LTEuNSByb3VuZGVkIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBTaWduIE91dFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNpZGViYXIgTmF2aWdhdGlvbiAqL31cbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInctNjQgYmctd2hpdGUgYm9yZGVyLXIgYm9yZGVyLWdyYXktMjAwIHAtNiBzaHJpbmstMCBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIG1iLTYgdGV4dC1ncmF5LTgwMFwiPk1lbnU8L2gyPlxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQtc20gZm9udC1tZWRpdW0gZmxleC0xXCI+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2Rhc2hib2FyZCcpfSBcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBweC00IHB5LTMgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyAke2FjdGl2ZVRhYiA9PT0gJ2Rhc2hib2FyZCcgPyAnYmctWyNFOERFRjhdIHRleHQtWyMyMTAwNURdIGJvcmRlci1sLTQgYm9yZGVyLVsjNjc1MEE0XScgOiAndGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnRleHQtWyM2NzUwQTRdJ31gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBPdmVydmlld1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ29wZXJhdGlvbnMnKX0gXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LWxlZnQgcHgtNCBweS0zIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgJHthY3RpdmVUYWIgPT09ICdvcGVyYXRpb25zJyA/ICdiZy1bI0U4REVGOF0gdGV4dC1bIzIxMDA1RF0gYm9yZGVyLWwtNCBib3JkZXItWyM2NzUwQTRdJyA6ICd0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1bIzY3NTBBNF0nfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIE9wZXJhdGlvbnMgRGVza1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignc2V0dGluZ3MnKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBweC00IHB5LTMgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyAke2FjdGl2ZVRhYiA9PT0gJ3NldHRpbmdzJyA/ICdiZy1bI0U4REVGOF0gdGV4dC1bIzIxMDA1RF0gYm9yZGVyLWwtNCBib3JkZXItWyM2NzUwQTRdJyA6ICd0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1bIzY3NTBBNF0nfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFJpc2sgQ29udHJvbHNcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICA8L2FzaWRlPlxuXG4gICAgICAgIHsvKiBNYWluIENvbnRlbnQgQXJlYSAqL31cbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0b1wiPlxuXG4gICAgICAgICAgey8qIFRBQiAxOiBPVkVSVklFVyAvIERBU0hCT0FSRCAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZGFzaGJvYXJkJyAmJiAoXG4gICAgICAgICAgICA8RGFzaGJvYXJkIHRyYW5zYWN0aW9ucz17dHJhbnNhY3Rpb25zfSAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDI6IE9QRVJBVElPTlMgREVTSyAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnb3BlcmF0aW9ucycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIG1heC13LTZ4bCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNiB0ZXh0LVsjMjEwMDVEXVwiPk9wZXJhdGlvbnMgRGVzazwvaDE+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7LyogLS0tIE1MIFBSRURJQ1RJT04gU0FOREJPWCAtLS0gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbWItOFwiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+TGl2ZSBNTCBQcmVkaWN0aW9uIFNhbmRib3g8L2gyPlxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVQcmVkaWN0fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBzcGFjZS14LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkFtb3VudCAoJCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHN0ZXA9XCIwLjAxXCIgcmVxdWlyZWQgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMiB3LTMyIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyM2NzUwQTRdXCIgdmFsdWU9e21sRGF0YS5hbXR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWxEYXRhKHsuLi5tbERhdGEsIGFtdDogZS50YXJnZXQudmFsdWV9KX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+Q2l0eSBQb3B1bGF0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiByZXF1aXJlZCBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtMyBweS0yIHctNDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzY3NTBBNF1cIiB2YWx1ZT17bWxEYXRhLmNpdHlfcG9wfSBvbkNoYW5nZT17KGUpID0+IHNldE1sRGF0YSh7Li4ubWxEYXRhLCBjaXR5X3BvcDogZS50YXJnZXQudmFsdWV9KX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+WmlwIENvZGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHJlcXVpcmVkIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC0zIHB5LTIgdy0zMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjNjc1MEE0XVwiIHZhbHVlPXttbERhdGEuemlwfSBvbkNoYW5nZT17KGUpID0+IHNldE1sRGF0YSh7Li4ubWxEYXRhLCB6aXA6IGUudGFyZ2V0LnZhbHVlfSl9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtpc1ByZWRpY3Rpbmd9IGNsYXNzTmFtZT1cImJnLVsjNjc1MEE0XSB0ZXh0LXdoaXRlIHB4LTUgcHktMiByb3VuZGVkIGZvbnQtbWVkaXVtIGhvdmVyOmJnLVsjNTMzZjg1XSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpc1ByZWRpY3RpbmcgPyAnQW5hbHl6aW5nLi4uJyA6ICdUZXN0IEFJIE1vZGVsJ31cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgICAgIHsvKiBEaXNwbGF5IE1MIFJlc3VsdCAqL31cbiAgICAgICAgICAgICAgICB7cHJlZGljdGlvblJlc3VsdCAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YG10LTYgcC00IHJvdW5kZWQtbWQgYm9yZGVyICR7cHJlZGljdGlvblJlc3VsdCA9PT0gMSA/ICdiZy1yZWQtNTAgYm9yZGVyLXJlZC0yMDAnIDogJ2JnLWdyZWVuLTUwIGJvcmRlci1ncmVlbi0yMDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPXtgZm9udC1ib2xkIHRleHQtbGcgJHtwcmVkaWN0aW9uUmVzdWx0ID09PSAxID8gJ3RleHQtcmVkLTcwMCcgOiAndGV4dC1ncmVlbi03MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIEFJIERlY2lzaW9uOiB7cHJlZGljdGlvblJlc3VsdCA9PT0gMSA/ICfwn5qoIEZSQVVEIERFVEVDVEVEICgxKScgOiAn4pyFIE5PUk1BTCBUUkFOU0FDVElPTiAoMCknfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgbXQtMVwiPkJhc2VkIG9uIFhHQm9vc3QgbW9kZWwgZXZhbHVhdGlvbiBvZiBhbW91bnQsIHBvcHVsYXRpb24sIGFuZCB6aXAgY29kZS48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogLS0tIERBVEFCQVNFIFRSQU5TQUNUSU9OUyBUQUJMRSAtLS0gKi99XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+UmVjZW50IERhdGFiYXNlIFRyYW5zYWN0aW9uczwvaDI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctWyNFOERFRjhdIHRleHQtWyMyMTAwNURdXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5UcmFuc2FjdGlvbiBJRDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBmb250LXNlbWlib2xkXCI+VXNlciBFbWFpbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBmb250LXNlbWlib2xkXCI+QW1vdW50PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5SaXNrIFNjb3JlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtc2VtaWJvbGRcIj5EZWNpc2lvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25zLm1hcCgodHgsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dHgudHJhbnNhY3Rpb25faWQgfHwgaW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtIHRleHQtWyM2NzUwQTRdXCI+e3R4LnRyYW5zYWN0aW9uX2lkfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtZ3JheS03MDBcIj57dHguY3VzdG9tZXJfZW1haWx9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1ncmF5LTcwMFwiPiR7dHguYW1vdW50Py50b0ZpeGVkKDIpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMSByb3VuZGVkIHRleHQteHMgZm9udC1ib2xkICR7dHgucmlza19zY29yZSA+PSAwLjUgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAnIDogJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4LnJpc2tfc2NvcmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtZ3JheS03MDAgZm9udC1tZWRpdW1cIj57dHguZGVjaXNpb259PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAge3RyYW5zYWN0aW9ucy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiNVwiIGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIExvYWRpbmcgbGl2ZSBkYXRhIG9yIG5vIHRyYW5zYWN0aW9ucyBmb3VuZC4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDM6IFJJU0sgQ09OVFJPTFMgKFNFVFRJTkdTKSAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnc2V0dGluZ3MnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xMCBtYXgtdy02eGwgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICA8TWVyY2hhbnRTZXR0aW5ncyAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICA8L21haW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXX0=