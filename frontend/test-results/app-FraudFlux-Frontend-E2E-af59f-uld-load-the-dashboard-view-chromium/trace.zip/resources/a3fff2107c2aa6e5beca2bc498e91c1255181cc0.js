import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Dashboard.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "/node_modules/.vite/deps/recharts.js?v=4f441ac6";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
var _s = $RefreshSig$();
export default function Dashboard({ transactions = [] }) {
	_s();
	const { user } = useAuth();
	const [days, setDays] = useState(30);
	const [downloading, setDownloading] = useState(false);
	// 1. Format Bar Chart Data (Transaction Volume)
	const chartData = transactions.map((tx) => ({
		name: tx.transaction_id,
		amount: tx.amount
	}));
	// 2. Calculate Dynamic Pie Chart Data from Live Database Records
	const totalCount = transactions.length;
	const approvedCount = transactions.filter((tx) => tx.decision && tx.decision.toUpperCase() === "APPROVE").length;
	const declinedCount = transactions.filter((tx) => tx.decision && tx.decision.toUpperCase() === "DECLINE").length;
	const pieData = [{
		name: "Approved",
		value: approvedCount,
		color: "#10B981"
	}, {
		name: "Declined",
		value: declinedCount,
		color: "#EF4444"
	}];
	// CSV Export Handler
	const handleExportCSV = async () => {
		if (!user?.id) {
			alert("Merchant session not found. Please sign in again.");
			return;
		}
		setDownloading(true);
		try {
			const response = await fetch(`http://localhost:8000/v1/transactions/export?merchant_id=${user.id}&days=${days}`);
			if (!response.ok) throw new Error("Failed to generate export report.");
			const blob = await response.blob();
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `fraudflux_report_${days}d.csv`;
			document.body.appendChild(a);
			a.click();
			a.remove();
			window.URL.revokeObjectURL(url);
		} catch (err) {
			console.error("Export error:", err);
			alert("Error exporting CSV report.");
		} finally {
			setDownloading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-10 bg-white flex-1 overflow-y-auto text-gray-900 font-sans",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-5xl mx-auto space-y-12",
			children: [
				/* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center mb-6",
						children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-3xl font-bold",
							children: "Fraud"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: days,
								onChange: (e) => setDays(Number(e.target.value)),
								className: "p-1.5 border border-gray-300 rounded-md text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-[#6750A4]",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: 7,
										children: "Last 7 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 83,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 30,
										children: "Last 30 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 84,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 90,
										children: "Last 90 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 85,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleExportCSV,
								disabled: downloading,
								className: "text-[#6750A4] text-sm font-medium flex items-center hover:underline disabled:opacity-50",
								children: downloading ? "Downloading..." : "Download report overview (CSV)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-3 gap-8 mb-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-blue-400 mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 17
								}, this), " Fraud disputes"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.06%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-[#E8DEF8] mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 17
								}, this), " Early fraud warnings"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.03%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center text-sm font-medium text-gray-700 mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 bg-[#21005D] mr-2 rounded-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 17
								}, this), " Fraud rate"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.08%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border border-gray-100 rounded-lg p-6 h-72 bg-white shadow-sm mb-8",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-semibold text-gray-700 mb-4",
							children: "Transaction Volume by ID"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ _jsxDEV(BarChart, {
								data: chartData,
								children: [
									/* @__PURE__ */ _jsxDEV(CartesianGrid, {
										strokeDasharray: "3 3",
										vertical: false,
										stroke: "#E5E7EB"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(XAxis, {
										dataKey: "name",
										axisLine: false,
										tickLine: false,
										tick: {
											fontSize: 12,
											fill: "#6B7280"
										},
										dy: 10
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(YAxis, {
										axisLine: false,
										tickLine: false,
										tick: {
											fontSize: 12,
											fill: "#6B7280"
										},
										tickFormatter: (value) => `$${value}`,
										dx: -10
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 127,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Tooltip, {
										cursor: { fill: "#F3F4F6" },
										contentStyle: {
											borderRadius: "8px",
											border: "none",
											boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)"
										},
										formatter: (value) => [`$${value}`, "Amount"]
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Bar, {
										dataKey: "amount",
										fill: "#6750A4",
										radius: [
											4,
											4,
											0,
											0
										],
										barSize: 40
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 133,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-6 items-center border border-gray-100 rounded-xl p-6 bg-gray-50/50 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "md:col-span-2 h-64",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-gray-800 mb-2",
									children: "Live Decision Status Breakdown"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-gray-500 mb-4",
									children: "Real-time ratio of approved vs. declined transactions recorded in your database."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
									width: "100%",
									height: "80%",
									children: /* @__PURE__ */ _jsxDEV(PieChart, { children: [
										/* @__PURE__ */ _jsxDEV(Pie, {
											data: pieData,
											cx: "50%",
											cy: "50%",
											innerRadius: 55,
											outerRadius: 80,
											paddingAngle: 5,
											dataKey: "value",
											children: pieData.map((entry, index) => /* @__PURE__ */ _jsxDEV(Cell, { fill: entry.color }, `cell-${index}`, false, {
												fileName: _jsxFileName,
												lineNumber: 158,
												columnNumber: 23
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 148,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(Tooltip, {
											formatter: (value) => [`${value} Transactions`, "Count"],
											contentStyle: {
												borderRadius: "8px",
												border: "none",
												boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)"
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 161,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(Legend, {
											verticalAlign: "bottom",
											height: 36
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 165,
											columnNumber: 19
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 147,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 border-t md:border-t-0 md:border-l border-gray-200 pt-4 md:pt-0 md:pl-6",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white p-3.5 rounded-lg border border-gray-200 shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-gray-500 block",
										children: "Total Recorded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl font-extrabold text-gray-900",
										children: [totalCount, " Transactions"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-emerald-50/60 p-3.5 rounded-lg border border-emerald-200 shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-emerald-700 block font-semibold",
										children: "Approved Count"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl font-extrabold text-emerald-700",
										children: [
											approvedCount,
											" ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-normal",
												children: [
													"(",
													totalCount > 0 ? (approvedCount / totalCount * 100).toFixed(0) : 0,
													"%)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 180,
												columnNumber: 35
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-red-50/60 p-3.5 rounded-lg border border-red-200 shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-red-700 block font-semibold",
										children: "Declined Count"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl font-extrabold text-red-700",
										children: [
											declinedCount,
											" ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-normal",
												children: [
													"(",
													totalCount > 0 ? (declinedCount / totalCount * 100).toFixed(0) : 0,
													"%)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 35
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 184,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("hr", { className: "border-gray-200" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold",
							children: "Fraud Prevention"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-gray-600 mt-1",
							children: "Understand trends in the volume of transactions blocked by the system."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-4 gap-6 mb-8",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Attempted transactions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "138,910"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Blocked"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "1,320"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Block rate"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "0.95%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm font-medium text-gray-700 mb-1",
								children: "Volume blocked"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[28px] font-semibold",
								children: "€150,000"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-sm text-gray-700",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-200",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/4",
									children: "Block Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 228,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Count"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Volume"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/6",
									children: "Block rate"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "pb-3 font-semibold text-gray-900 w-1/4",
									children: "Est. false positive rate"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-100",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4 font-medium text-[#6750A4]",
									children: "Flux - High risk score"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 237,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "924"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 238,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "€90,000"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.67%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 240,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.12%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-gray-100",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4 font-medium text-[#6750A4]",
									children: "Flux - Rules"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "396"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "€40,800"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "0.29%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 247,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-4",
									children: "1.94%"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
}
_s(Dashboard, "3wZA4LIX64hdnvND+tuFOo9nV3M=", false, function() {
	return [useAuth];
});
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/Dashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/Dashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLFVBQVUsS0FBSyxPQUFPLE9BQU8sZUFBZSxTQUFTLHFCQUNyRCxVQUFVLEtBQUssTUFBTSxjQUNoQjtBQUNQLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxLQUFLOztDQUN2RCxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBRXpCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7O0NBR3BELE1BQU0sWUFBWSxhQUFhLEtBQUksUUFBTztFQUN4QyxNQUFNLEdBQUc7RUFDVCxRQUFRLEdBQUc7Q0FDYixFQUFFOztDQUdGLE1BQU0sYUFBYSxhQUFhO0NBQ2hDLE1BQU0sZ0JBQWdCLGFBQWEsUUFDaEMsT0FBTyxHQUFHLFlBQVksR0FBRyxTQUFTLFlBQVksTUFBTSxTQUN2RCxDQUFDLENBQUM7Q0FDRixNQUFNLGdCQUFnQixhQUFhLFFBQ2hDLE9BQU8sR0FBRyxZQUFZLEdBQUcsU0FBUyxZQUFZLE1BQU0sU0FDdkQsQ0FBQyxDQUFDO0NBRUYsTUFBTSxVQUFVLENBQ2Q7RUFBRSxNQUFNO0VBQVksT0FBTztFQUFlLE9BQU87Q0FBVSxHQUMzRDtFQUFFLE1BQU07RUFBWSxPQUFPO0VBQWUsT0FBTztDQUFVLENBQzdEOztDQUdBLE1BQU0sa0JBQWtCLFlBQVk7RUFDbEMsSUFBSSxDQUFDLE1BQU0sSUFBSTtHQUNiLE1BQU0sbURBQW1EO0dBQ3pEO0VBQ0Y7RUFFQSxlQUFlLElBQUk7RUFFbkIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLDREQUE0RCxLQUFLLEdBQUcsUUFBUSxNQUM5RTtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sbUNBQW1DO0dBRXJFLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQzNDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxFQUFFLFdBQVcsb0JBQW9CLEtBQUs7R0FFdEMsU0FBUyxLQUFLLFlBQVksQ0FBQztHQUMzQixFQUFFLE1BQU07R0FDUixFQUFFLE9BQU87R0FDVCxPQUFPLElBQUksZ0JBQWdCLEdBQUc7RUFDaEMsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLGlCQUFpQixHQUFHO0dBQ2xDLE1BQU0sNkJBQTZCO0VBQ3JDLFVBQVU7R0FDUixlQUFlLEtBQUs7RUFDdEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsV0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXFCO01BQVM7Ozs7Z0JBRTVDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sUUFBUSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7UUFDL0MsV0FBVTtrQkFIWjtTQUtFLHdCQUFDLFVBQUQ7VUFBUSxPQUFPO29CQUFHO1NBQW1COzs7OztTQUNyQyx3QkFBQyxVQUFEO1VBQVEsT0FBTztvQkFBSTtTQUFvQjs7Ozs7U0FDdkMsd0JBQUMsVUFBRDtVQUFRLE9BQU87b0JBQUk7U0FBb0I7Ozs7O1FBQ2pDOzs7OztpQkFFUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFVBQVU7UUFDVixXQUFVO2tCQUVULGNBQWMsbUJBQW1CO09BQzVCOzs7O2VBQ0w7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQTRDOzs7O2tCQUFDLGlCQUMxRDs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7O2tCQUFDLHVCQUMzRDs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7O2tCQUFDLGFBQzNEOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBNEI7T0FBVTs7OztlQUNsRDs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMkM7TUFBNEI7Ozs7Z0JBQ3JGLHdCQUFDLHFCQUFEO09BQXFCLE9BQU07T0FBTyxRQUFPO2lCQUN2Qyx3QkFBQyxVQUFEO1FBQVUsTUFBTTtrQkFBaEI7U0FDRSx3QkFBQyxlQUFEO1VBQWUsaUJBQWdCO1VBQU0sVUFBVTtVQUFPLFFBQU87U0FBVzs7Ozs7U0FDeEUsd0JBQUMsT0FBRDtVQUFPLFNBQVE7VUFBTyxVQUFVO1VBQU8sVUFBVTtVQUFPLE1BQU07V0FBRSxVQUFVO1dBQUksTUFBTTtVQUFVO1VBQUcsSUFBSTtTQUFLOzs7OztTQUMxRyx3QkFBQyxPQUFEO1VBQU8sVUFBVTtVQUFPLFVBQVU7VUFBTyxNQUFNO1dBQUUsVUFBVTtXQUFJLE1BQU07VUFBVTtVQUFHLGdCQUFnQixVQUFVLElBQUk7VUFBUyxJQUFJLENBQUM7U0FBSzs7Ozs7U0FDbkksd0JBQUMsU0FBRDtVQUNFLFFBQVEsRUFBRSxNQUFNLFVBQVU7VUFDMUIsY0FBYztXQUFFLGNBQWM7V0FBTyxRQUFRO1dBQVEsV0FBVztVQUFvQztVQUNwRyxZQUFZLFVBQVUsQ0FBQyxJQUFJLFNBQVMsUUFBUTtTQUM3Qzs7Ozs7U0FDRCx3QkFBQyxLQUFEO1VBQUssU0FBUTtVQUFTLE1BQUs7VUFBVSxRQUFRO1dBQUM7V0FBRztXQUFHO1dBQUc7VUFBQztVQUFHLFNBQVM7U0FBSzs7Ozs7UUFDakU7Ozs7OztNQUNTOzs7O2NBQ2xCOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUdFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXVDO1FBQWtDOzs7OztRQUN2Rix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkI7UUFBbUY7Ozs7O1FBRTdILHdCQUFDLHFCQUFEO1NBQXFCLE9BQU07U0FBTyxRQUFPO21CQUN2Qyx3QkFBQyxVQUFEO1VBQ0Usd0JBQUMsS0FBRDtXQUNFLE1BQU07V0FDTixJQUFHO1dBQ0gsSUFBRztXQUNILGFBQWE7V0FDYixhQUFhO1dBQ2IsY0FBYztXQUNkLFNBQVE7cUJBRVAsUUFBUSxLQUFLLE9BQU8sVUFDbkIsd0JBQUMsTUFBRCxFQUE0QixNQUFNLE1BQU0sTUFBUSxHQUFyQyxRQUFROzs7O2tCQUE2QixDQUNqRDtVQUNFOzs7OztVQUNMLHdCQUFDLFNBQUQ7V0FDRSxZQUFZLFVBQVUsQ0FBQyxHQUFHLE1BQU0sZ0JBQWdCLE9BQU87V0FDdkQsY0FBYztZQUFFLGNBQWM7WUFBTyxRQUFRO1lBQVEsV0FBVztXQUFpQztVQUNsRzs7Ozs7VUFDRCx3QkFBQyxRQUFEO1dBQVEsZUFBYztXQUFTLFFBQVE7VUFBSzs7Ozs7U0FDcEM7Ozs7O1FBQ1M7Ozs7O09BQ2xCOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQThCO1NBQW9COzs7O21CQUNsRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBd0QsWUFBVyxlQUFtQjs7Ozs7aUJBQ25GOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErQztTQUFvQjs7OzttQkFDbkYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0c7V0FBYztXQUFDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQjthQUFzQzthQUFFLGFBQWEsS0FBTSxnQkFBZ0IsYUFBYyxJQUFHLEFBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSTthQUFFO1lBQVE7Ozs7OztVQUNqSTs7Ozs7aUJBQ0g7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTJDO1NBQW9COzs7O21CQUMvRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FDRztXQUFjO1dBQUMsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCO2FBQXNDO2FBQUUsYUFBYSxLQUFNLGdCQUFnQixhQUFjLElBQUcsQUFBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJO2FBQUU7WUFBUTs7Ozs7O1VBQ2pJOzs7OztpQkFDSDs7Ozs7O09BQ0Y7Ozs7O2NBRUY7Ozs7OztJQUNFOzs7OztJQUVULHdCQUFDLE1BQUQsRUFBSSxXQUFVLGtCQUFtQjs7Ozs7SUFHakMsd0JBQUMsV0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9CO01BQW9COzs7O2dCQUN0RCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBNkI7TUFFdkM7Ozs7Y0FDQTs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXlDO09BQTJCOzs7O2lCQUNuRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBNEI7T0FBWTs7OztlQUNwRDs7Ozs7T0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXlDO09BQVk7Ozs7aUJBQ3BFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE0QjtPQUFVOzs7O2VBQ2xEOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBeUM7T0FBZTs7OztpQkFDdkUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQVU7Ozs7ZUFDbEQ7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF5QztPQUFtQjs7OztpQkFDM0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTRCO09BQWE7Ozs7ZUFDckQ7Ozs7O01BQ0Y7Ozs7OztLQUVMLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUFjOzs7OztRQUNyRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUM7UUFBUzs7Ozs7UUFDaEUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlDO1FBQVU7Ozs7O1FBQ2pFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUFjOzs7OztRQUNyRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUM7UUFBNEI7Ozs7O09BQ2pGOzs7OztlQUNDOzs7O2dCQUNQLHdCQUFDLFNBQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFrQztRQUEwQjs7Ozs7UUFDMUUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBTzs7Ozs7UUFDNUIsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBVzs7Ozs7UUFDaEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBUzs7Ozs7UUFDOUIsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQU87UUFBUzs7Ozs7T0FDNUI7Ozs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWtDO1FBQWdCOzs7OztRQUNoRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFPOzs7OztRQUM1Qix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFXOzs7OztRQUNoQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFTOzs7OztRQUM5Qix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTztRQUFTOzs7OztPQUM1Qjs7Ozs7Y0FDQzs7OztjQUNGOzs7Ozs7SUFDQTs7Ozs7R0FDTjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFxyXG4gIEJhckNoYXJ0LCBCYXIsIFhBeGlzLCBZQXhpcywgQ2FydGVzaWFuR3JpZCwgVG9vbHRpcCwgUmVzcG9uc2l2ZUNvbnRhaW5lcixcclxuICBQaWVDaGFydCwgUGllLCBDZWxsLCBMZWdlbmQgXHJcbn0gZnJvbSAncmVjaGFydHMnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZCh7IHRyYW5zYWN0aW9ucyA9IFtdIH0pIHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBcclxuICBjb25zdCBbZGF5cywgc2V0RGF5c10gPSB1c2VTdGF0ZSgzMCk7XHJcbiAgY29uc3QgW2Rvd25sb2FkaW5nLCBzZXREb3dubG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIDEuIEZvcm1hdCBCYXIgQ2hhcnQgRGF0YSAoVHJhbnNhY3Rpb24gVm9sdW1lKVxyXG4gIGNvbnN0IGNoYXJ0RGF0YSA9IHRyYW5zYWN0aW9ucy5tYXAodHggPT4gKHtcclxuICAgIG5hbWU6IHR4LnRyYW5zYWN0aW9uX2lkLFxyXG4gICAgYW1vdW50OiB0eC5hbW91bnRcclxuICB9KSk7XHJcblxyXG4gIC8vIDIuIENhbGN1bGF0ZSBEeW5hbWljIFBpZSBDaGFydCBEYXRhIGZyb20gTGl2ZSBEYXRhYmFzZSBSZWNvcmRzXHJcbiAgY29uc3QgdG90YWxDb3VudCA9IHRyYW5zYWN0aW9ucy5sZW5ndGg7XHJcbiAgY29uc3QgYXBwcm92ZWRDb3VudCA9IHRyYW5zYWN0aW9ucy5maWx0ZXIoXHJcbiAgICAodHgpID0+IHR4LmRlY2lzaW9uICYmIHR4LmRlY2lzaW9uLnRvVXBwZXJDYXNlKCkgPT09ICdBUFBST1ZFJ1xyXG4gICkubGVuZ3RoO1xyXG4gIGNvbnN0IGRlY2xpbmVkQ291bnQgPSB0cmFuc2FjdGlvbnMuZmlsdGVyKFxyXG4gICAgKHR4KSA9PiB0eC5kZWNpc2lvbiAmJiB0eC5kZWNpc2lvbi50b1VwcGVyQ2FzZSgpID09PSAnREVDTElORSdcclxuICApLmxlbmd0aDtcclxuXHJcbiAgY29uc3QgcGllRGF0YSA9IFtcclxuICAgIHsgbmFtZTogJ0FwcHJvdmVkJywgdmFsdWU6IGFwcHJvdmVkQ291bnQsIGNvbG9yOiAnIzEwQjk4MScgfSwgLy8gRW1lcmFsZCBHcmVlblxyXG4gICAgeyBuYW1lOiAnRGVjbGluZWQnLCB2YWx1ZTogZGVjbGluZWRDb3VudCwgY29sb3I6ICcjRUY0NDQ0JyB9ICAvLyBDcmltc29uIFJlZFxyXG4gIF07XHJcblxyXG4gIC8vIENTViBFeHBvcnQgSGFuZGxlclxyXG4gIGNvbnN0IGhhbmRsZUV4cG9ydENTViA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghdXNlcj8uaWQpIHtcclxuICAgICAgYWxlcnQoXCJNZXJjaGFudCBzZXNzaW9uIG5vdCBmb3VuZC4gUGxlYXNlIHNpZ24gaW4gYWdhaW4uXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RG93bmxvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDo4MDAwL3YxL3RyYW5zYWN0aW9ucy9leHBvcnQ/bWVyY2hhbnRfaWQ9JHt1c2VyLmlkfSZkYXlzPSR7ZGF5c31gXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBnZW5lcmF0ZSBleHBvcnQgcmVwb3J0LicpO1xyXG5cclxuICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKTtcclxuICAgICAgY29uc3QgdXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgIGEuaHJlZiA9IHVybDtcclxuICAgICAgYS5kb3dubG9hZCA9IGBmcmF1ZGZsdXhfcmVwb3J0XyR7ZGF5c31kLmNzdmA7XHJcblxyXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xyXG4gICAgICBhLmNsaWNrKCk7XHJcbiAgICAgIGEucmVtb3ZlKCk7XHJcbiAgICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXhwb3J0IGVycm9yOicsIGVycik7XHJcbiAgICAgIGFsZXJ0KCdFcnJvciBleHBvcnRpbmcgQ1NWIHJlcG9ydC4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldERvd25sb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIGJnLXdoaXRlIGZsZXgtMSBvdmVyZmxvdy15LWF1dG8gdGV4dC1ncmF5LTkwMCBmb250LXNhbnNcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy01eGwgbXgtYXV0byBzcGFjZS15LTEyXCI+XHJcbiAgICAgICAgXHJcbiAgICAgICAgey8qIFNlY3Rpb24gMTogRnJhdWQgT3ZlcnZpZXcgSGVhZGVyICYgVG9wIEtQSXMgKi99XHJcbiAgICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGRcIj5GcmF1ZDwvaDE+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2RheXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERheXMoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzY3NTBBNF1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezd9Pkxhc3QgNyBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXszMH0+TGFzdCAzMCBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs5MH0+TGFzdCA5MCBEYXlzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydENTVn1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkb3dubG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWyM2NzUwQTRdIHRleHQtc20gZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgaG92ZXI6dW5kZXJsaW5lIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtkb3dubG9hZGluZyA/ICdEb3dubG9hZGluZy4uLicgOiAnRG93bmxvYWQgcmVwb3J0IG92ZXJ2aWV3IChDU1YpJ31cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogSGlzdG9yaWNhbCBOZXR3b3JrIEJlbmNobWFya3MgKFN0YXRpYykgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTggbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgYmctYmx1ZS00MDAgbXItMiByb3VuZGVkLXNtXCI+PC9zcGFuPiBGcmF1ZCBkaXNwdXRlc1xyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPjAuMDYlPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgYmctWyNFOERFRjhdIG1yLTIgcm91bmRlZC1zbVwiPjwvc3Bhbj4gRWFybHkgZnJhdWQgd2FybmluZ3NcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGRcIj4wLjAzJTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIGJnLVsjMjEwMDVEXSBtci0yIHJvdW5kZWQtc21cIj48L3NwYW4+IEZyYXVkIHJhdGVcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGRcIj4wLjA4JTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7LyogRHluYW1pYyBCYXIgQ2hhcnQ6IFRyYW5zYWN0aW9uIFZvbHVtZSBieSBJRCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLWxnIHAtNiBoLTcyIGJnLXdoaXRlIHNoYWRvdy1zbSBtYi04XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi00XCI+VHJhbnNhY3Rpb24gVm9sdW1lIGJ5IElEPC9oMz5cclxuICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgIDxCYXJDaGFydCBkYXRhPXtjaGFydERhdGF9PlxyXG4gICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgdmVydGljYWw9e2ZhbHNlfSBzdHJva2U9XCIjRTVFN0VCXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibmFtZVwiIGF4aXNMaW5lPXtmYWxzZX0gdGlja0xpbmU9e2ZhbHNlfSB0aWNrPXt7IGZvbnRTaXplOiAxMiwgZmlsbDogJyM2QjcyODAnIH19IGR5PXsxMH0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyBheGlzTGluZT17ZmFsc2V9IHRpY2tMaW5lPXtmYWxzZX0gdGljaz17eyBmb250U2l6ZTogMTIsIGZpbGw6ICcjNkI3MjgwJyB9fSB0aWNrRm9ybWF0dGVyPXsodmFsdWUpID0+IGAkJHt2YWx1ZX1gfSBkeD17LTEwfSAvPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgXHJcbiAgICAgICAgICAgICAgICAgIGN1cnNvcj17eyBmaWxsOiAnI0YzRjRGNicgfX1cclxuICAgICAgICAgICAgICAgICAgY29udGVudFN0eWxlPXt7IGJvcmRlclJhZGl1czogJzhweCcsIGJvcmRlcjogJ25vbmUnLCBib3hTaGFkb3c6ICcwIDRweCA2cHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMSknIH19XHJcbiAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PiBbYCQke3ZhbHVlfWAsICdBbW91bnQnXX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJhbW91bnRcIiBmaWxsPVwiIzY3NTBBNFwiIHJhZGl1cz17WzQsIDQsIDAsIDBdfSBiYXJTaXplPXs0MH0gLz5cclxuICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRHluYW1pYyBEZWNpc2lvbiBTdGF0dXMgUGllIENoYXJ0ICYgU3VtbWFyeSBDYXJkcyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBpdGVtcy1jZW50ZXIgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLXhsIHAtNiBiZy1ncmF5LTUwLzUwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIFBpZSBDaGFydCBDb2x1bW4gKFNwYW5zIDIgY29sdW1ucykgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMiBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPkxpdmUgRGVjaXNpb24gU3RhdHVzIEJyZWFrZG93bjwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG1iLTRcIj5SZWFsLXRpbWUgcmF0aW8gb2YgYXBwcm92ZWQgdnMuIGRlY2xpbmVkIHRyYW5zYWN0aW9ucyByZWNvcmRlZCBpbiB5b3VyIGRhdGFiYXNlLjwvcD5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCI4MCVcIj5cclxuICAgICAgICAgICAgICAgIDxQaWVDaGFydD5cclxuICAgICAgICAgICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e3BpZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICBpbm5lclJhZGl1cz17NTV9XHJcbiAgICAgICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXM9ezgwfVxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdBbmdsZT17NX1cclxuICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PVwidmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3BpZURhdGEubWFwKChlbnRyeSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17YGNlbGwtJHtpbmRleH1gfSBmaWxsPXtlbnRyeS5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgICAgIDxUb29sdGlwIFxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PiBbYCR7dmFsdWV9IFRyYW5zYWN0aW9uc2AsICdDb3VudCddfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnRTdHlsZT17eyBib3JkZXJSYWRpdXM6ICc4cHgnLCBib3JkZXI6ICdub25lJywgYm94U2hhZG93OiAnMCA0cHggNnB4IC0xcHggcmdiYSgwLDAsMCwwLjEpJyB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8TGVnZW5kIHZlcnRpY2FsQWxpZ249XCJib3R0b21cIiBoZWlnaHQ9ezM2fSAvPlxyXG4gICAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFF1aWNrIFN0YXQgU3VtbWFyeSBDYXJkcyBDb2x1bW4gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIGJvcmRlci10IG1kOmJvcmRlci10LTAgbWQ6Ym9yZGVyLWwgYm9yZGVyLWdyYXktMjAwIHB0LTQgbWQ6cHQtMCBtZDpwbC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTMuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgYmxvY2tcIj5Ub3RhbCBSZWNvcmRlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTkwMFwiPnt0b3RhbENvdW50fSBUcmFuc2FjdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MC82MCBwLTMuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC03MDAgYmxvY2sgZm9udC1zZW1pYm9sZFwiPkFwcHJvdmVkIENvdW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LWVtZXJhbGQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHthcHByb3ZlZENvdW50fSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsXCI+KHt0b3RhbENvdW50ID4gMCA/ICgoYXBwcm92ZWRDb3VudCAvIHRvdGFsQ291bnQpICogMTAwKS50b0ZpeGVkKDApIDogMH0lKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAvNjAgcC0zLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC0yMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTcwMCBibG9jayBmb250LXNlbWlib2xkXCI+RGVjbGluZWQgQ291bnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtcmVkLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZGVjbGluZWRDb3VudH0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbFwiPih7dG90YWxDb3VudCA+IDAgPyAoKGRlY2xpbmVkQ291bnQgLyB0b3RhbENvdW50KSAqIDEwMCkudG9GaXhlZCgwKSA6IDB9JSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgPGhyIGNsYXNzTmFtZT1cImJvcmRlci1ncmF5LTIwMFwiIC8+XHJcblxyXG4gICAgICAgIHsvKiBTZWN0aW9uIDI6IEZyYXVkIFByZXZlbnRpb24gT3ZlcnZpZXcgKi99XHJcbiAgICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCI+RnJhdWQgUHJldmVudGlvbjwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgVW5kZXJzdGFuZCB0cmVuZHMgaW4gdGhlIHZvbHVtZSBvZiB0cmFuc2FjdGlvbnMgYmxvY2tlZCBieSB0aGUgc3lzdGVtLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5BdHRlbXB0ZWQgdHJhbnNhY3Rpb25zPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LXNlbWlib2xkXCI+MTM4LDkxMDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+QmxvY2tlZDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZFwiPjEsMzIwPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5CbG9jayByYXRlPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LXNlbWlib2xkXCI+MC45NSU8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlZvbHVtZSBibG9ja2VkPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LXNlbWlib2xkXCI+4oKsMTUwLDAwMDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInBiLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS80XCI+QmxvY2sgVHlwZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicGItMyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdy0xLzZcIj5Db3VudDwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicGItMyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdy0xLzZcIj5Wb2x1bWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInBiLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS82XCI+QmxvY2sgcmF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicGItMyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdy0xLzRcIj5Fc3QuIGZhbHNlIHBvc2l0aXZlIHJhdGU8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBmb250LW1lZGl1bSB0ZXh0LVsjNjc1MEE0XVwiPkZsdXggLSBIaWdoIHJpc2sgc2NvcmU8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTRcIj45MjQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTRcIj7igqw5MCwwMDA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTRcIj4wLjY3JTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNFwiPjAuMTIlPC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IGZvbnQtbWVkaXVtIHRleHQtWyM2NzUwQTRdXCI+Rmx1eCAtIFJ1bGVzPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+Mzk2PC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+4oKsNDAsODAwPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00XCI+MC4yOSU8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTRcIj4xLjk0JTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn0iXX0=