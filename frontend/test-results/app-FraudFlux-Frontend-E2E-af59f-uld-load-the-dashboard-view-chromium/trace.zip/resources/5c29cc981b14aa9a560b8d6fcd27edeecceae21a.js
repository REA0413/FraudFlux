import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/LandingPage.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f441ac6";
var _jsxFileName = "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f441ac6";
export default function LandingPage({ onNavigate }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#1a103c] text-white flex flex-col font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "flex items-center justify-between px-8 py-5 border-b border-white/10 max-w-7xl mx-auto w-full",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-3 cursor-pointer",
					onClick: () => onNavigate("landing"),
					children: /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xl font-bold tracking-tight",
						children: "FraudFlux"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2 sm:space-x-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("pricing"),
							className: "text-sm font-medium text-gray-300 hover:text-white px-3 py-2 transition-colors",
							children: "Pricing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 18,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("login"),
							className: "text-sm font-medium text-gray-300 hover:text-white px-3 py-2 transition-colors",
							children: "Sign In"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("register"),
							className: "text-sm font-medium bg-[#6750A4] hover:bg-[#533f85] text-white px-5 py-2.5 rounded-lg shadow-lg transition-all",
							children: "Get Started"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 flex flex-col items-center justify-center text-center px-6 max-w-4xl mx-auto my-12",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs uppercase tracking-widest bg-[#6750A4]/30 text-[#e0d7f5] px-4 py-1.5 rounded-full font-semibold mb-6 border border-[#6750A4]/40",
						children: "AI-Powered Risk Intelligence"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl text-gray-200 sm:text-6xl font-extrabold tracking-tight leading-tight mb-6",
						children: [
							"Real-Time Transaction",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 32
							}, this),
							"Fraud Detection"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-lg text-gray-300 mb-10 max-w-2xl leading-relaxed",
						children: "FraudFlux leverages Machine Learning and real-time database streaming to identify high-risk payments, mitigate financial fraud, and empower operations analysis."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row gap-4 w-full sm:w-auto",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("login"),
							className: "bg-[#6750A4] hover:bg-[#533f85] text-white font-medium px-8 py-3.5 rounded-xl text-base shadow-xl transition-all",
							children: "Access Operations Console"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 text-left w-full",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "⚡ Instant ML Scoring"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Evaluate transaction amounts, zip codes, and population density using automated XGBoost model."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "📊 Live Dashboard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 71,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Track key merchant transaction metrics, risk distributions, and live flag statuses effortlessly."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 72,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-lg mb-2 text-[#e0d7f5]",
									children: "🔒 Secure Data Handle"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-gray-400",
									children: "Enterprise-grade secure row-level security and authentication provided by Supabase."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "py-6 border-t border-white/10 text-center text-xs text-gray-500",
				children: "© 2026 FraudFlux Academic Project. Built with React, Fast API & Supabase."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = LandingPage;
var _c;
$RefreshReg$(_c, "LandingPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/LandingPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/NON OFFICE/Important Doc/Ireland Doc/NCI/Academic/Project Module/FraudFlux/frontend/src/LandingPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsZUFBZSxTQUFTLFlBQVksRUFBRSxjQUFjO0NBQ2xELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQ0UsV0FBVTtLQUNWLGVBQWUsV0FBVyxTQUFTO2VBRW5DLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFtQztLQUFlOzs7OztJQUMvRDs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxXQUFXLFNBQVM7T0FDbkMsV0FBVTtpQkFDWDtNQUVPOzs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFdBQVcsT0FBTztPQUNqQyxXQUFVO2lCQUNYO01BRU87Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsV0FBVyxVQUFVO09BQ3BDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBMEk7S0FFcEo7Ozs7O0tBRU4sd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FBb0c7T0FDN0Usd0JBQUMsTUFBRCxDQUFJOzs7OztPQUFDO01BQ3hCOzs7Ozs7S0FFSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBd0Q7S0FFbEU7Ozs7O0tBRUgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsV0FBVyxPQUFPO09BQ2pDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdDO1FBQXdCOzs7O2tCQUM5RSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBd0I7UUFBaUc7Ozs7Z0JBQ25JOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF3QztRQUFxQjs7OztrQkFDM0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXdCO1FBQW1HOzs7O2dCQUNySTs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBd0M7UUFBeUI7Ozs7a0JBQy9FLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF3QjtRQUFzRjs7OztnQkFDeEg7Ozs7OztNQUNGOzs7Ozs7SUFDRDs7Ozs7O0dBR04sd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBa0U7R0FFNUU7Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhbmRpbmdQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGFuZGluZ1BhZ2UoeyBvbk5hdmlnYXRlIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyMxYTEwM2NdIHRleHQtd2hpdGUgZmxleCBmbGV4LWNvbCBmb250LXNhbnNcIj5cclxuICAgICAgXHJcbiAgICAgIHsvKiBUb3AgTmF2aWdhdGlvbiBCYXIgKi99XHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTggcHktNSBib3JkZXItYiBib3JkZXItd2hpdGUvMTAgbWF4LXctN3hsIG14LWF1dG8gdy1mdWxsXCI+XHJcbiAgICAgICAgPGRpdiBcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdsYW5kaW5nJyl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5GcmF1ZEZsdXg8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHNtOnNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgey8qIFByaWNpbmcgTGluayAqL31cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgncHJpY2luZycpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBweC0zIHB5LTIgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBQcmljaW5nXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdsb2dpbicpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBweC0zIHB5LTIgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTaWduIEluXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ3JlZ2lzdGVyJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gYmctWyM2NzUwQTRdIGhvdmVyOmJnLVsjNTMzZjg1XSB0ZXh0LXdoaXRlIHB4LTUgcHktMi41IHJvdW5kZWQtbGcgc2hhZG93LWxnIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgR2V0IFN0YXJ0ZWRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L25hdj5cclxuXHJcbiAgICAgIHsvKiBIZXJvIFNlY3Rpb24gKi99XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWNlbnRlciBweC02IG1heC13LTR4bCBteC1hdXRvIG15LTEyXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IGJnLVsjNjc1MEE0XS8zMCB0ZXh0LVsjZTBkN2Y1XSBweC00IHB5LTEuNSByb3VuZGVkLWZ1bGwgZm9udC1zZW1pYm9sZCBtYi02IGJvcmRlciBib3JkZXItWyM2NzUwQTRdLzQwXCI+XHJcbiAgICAgICAgICBBSS1Qb3dlcmVkIFJpc2sgSW50ZWxsaWdlbmNlXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LWdyYXktMjAwIHNtOnRleHQtNnhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctdGlnaHQgbWItNlwiPlxyXG4gICAgICAgICAgUmVhbC1UaW1lIFRyYW5zYWN0aW9uPGJyLz5GcmF1ZCBEZXRlY3Rpb25cclxuICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIHRleHQtZ3JheS0zMDAgbWItMTAgbWF4LXctMnhsIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgRnJhdWRGbHV4IGxldmVyYWdlcyBNYWNoaW5lIExlYXJuaW5nIGFuZCByZWFsLXRpbWUgZGF0YWJhc2Ugc3RyZWFtaW5nIHRvIGlkZW50aWZ5IGhpZ2gtcmlzayBwYXltZW50cywgbWl0aWdhdGUgZmluYW5jaWFsIGZyYXVkLCBhbmQgZW1wb3dlciBvcGVyYXRpb25zIGFuYWx5c2lzLlxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC00IHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnbG9naW4nKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyM2NzUwQTRdIGhvdmVyOmJnLVsjNTMzZjg1XSB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHB4LTggcHktMy41IHJvdW5kZWQteGwgdGV4dC1iYXNlIHNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEFjY2VzcyBPcGVyYXRpb25zIENvbnNvbGVcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRmVhdHVyZSBIaWdobGlnaHRzIEdyaWQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IG10LTE2IHRleHQtbGVmdCB3LWZ1bGxcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvNSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHAtNiByb3VuZGVkLTJ4bCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyBtYi0yIHRleHQtWyNlMGQ3ZjVdXCI+4pqhIEluc3RhbnQgTUwgU2NvcmluZzwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPkV2YWx1YXRlIHRyYW5zYWN0aW9uIGFtb3VudHMsIHppcCBjb2RlcywgYW5kIHBvcHVsYXRpb24gZGVuc2l0eSB1c2luZyBhdXRvbWF0ZWQgWEdCb29zdCBtb2RlbC48L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvNSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHAtNiByb3VuZGVkLTJ4bCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyBtYi0yIHRleHQtWyNlMGQ3ZjVdXCI+8J+TiiBMaXZlIERhc2hib2FyZDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPlRyYWNrIGtleSBtZXJjaGFudCB0cmFuc2FjdGlvbiBtZXRyaWNzLCByaXNrIGRpc3RyaWJ1dGlvbnMsIGFuZCBsaXZlIGZsYWcgc3RhdHVzZXMgZWZmb3J0bGVzc2x5LjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZS81IGJvcmRlciBib3JkZXItd2hpdGUvMTAgcC02IHJvdW5kZWQtMnhsIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIG1iLTIgdGV4dC1bI2UwZDdmNV1cIj7wn5SSIFNlY3VyZSBEYXRhIEhhbmRsZTwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMFwiPkVudGVycHJpc2UtZ3JhZGUgc2VjdXJlIHJvdy1sZXZlbCBzZWN1cml0eSBhbmQgYXV0aGVudGljYXRpb24gcHJvdmlkZWQgYnkgU3VwYWJhc2UuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgIHsvKiBGb290ZXIgKi99XHJcbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwicHktNiBib3JkZXItdCBib3JkZXItd2hpdGUvMTAgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgwqkgMjAyNiBGcmF1ZEZsdXggQWNhZGVtaWMgUHJvamVjdC4gQnVpbHQgd2l0aCBSZWFjdCwgRmFzdCBBUEkgJiBTdXBhYmFzZS5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19